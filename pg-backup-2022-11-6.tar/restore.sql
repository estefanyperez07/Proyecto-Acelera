--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.5 (Ubuntu 14.5-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: contabilidad; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA contabilidad;


ALTER SCHEMA contabilidad OWNER TO postgres;

--
-- Name: seguridad; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA seguridad;


ALTER SCHEMA seguridad OWNER TO postgres;

--
-- Name: ty_libro_diario_enca; Type: TYPE; Schema: contabilidad; Owner: postgres
--

CREATE TYPE contabilidad.ty_libro_diario_enca AS (
	id_libro_diario_enca bigint,
	id_estado integer,
	descripcion character varying,
	fecha date,
	monto_debe numeric,
	monto_haber numeric,
	id_usuario integer,
	nombre_usuario character varying
);


ALTER TYPE contabilidad.ty_libro_diario_enca OWNER TO postgres;

--
-- Name: ty_detalle_factura; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ty_detalle_factura AS (
	secuencia_det bigint,
	secuencia_enc bigint,
	id_articulo integer,
	id_modo_pedido integer,
	precio numeric,
	cantidad integer,
	id_impuesto integer,
	total_impuesto numeric,
	total numeric
);


ALTER TYPE public.ty_detalle_factura OWNER TO postgres;

--
-- Name: ty_encabezado_compras; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ty_encabezado_compras AS (
	secuencia_enc bigint,
	id_socio_negocio integer,
	fecha date,
	referencia character varying,
	monto_total numeric,
	monto_impuesto_total numeric,
	creado_por character varying,
	fecha_creacion date,
	modificado_por character varying,
	fecha_modificacion date,
	id_usuario integer,
	id_centro_costo integer,
	estado character(1)
);


ALTER TYPE public.ty_encabezado_compras OWNER TO postgres;

--
-- Name: ty_encabezado_factura; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ty_encabezado_factura AS (
	secuencia_enc bigint,
	id_sucursal integer,
	cod_sucursal character varying,
	fecha date,
	numero_cuenta integer,
	venta_grabada_15 numeric,
	venta_grabada_18 numeric,
	venta_exenta numeric,
	impuesto_15 numeric,
	impuesto_18 numeric,
	venta_total numeric,
	cai character varying,
	correlativo integer,
	rtn character varying,
	nombre_cliente character varying,
	id_usuario integer,
	id_pos integer,
	no_factura character varying
);


ALTER TYPE public.ty_encabezado_factura OWNER TO postgres;

--
-- Name: ty_test; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.ty_test AS (
	a integer,
	b integer
);


ALTER TYPE public.ty_test OWNER TO postgres;

--
-- Name: d_delete_catalogo_cuenta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_catalogo_cuenta(p_id_cuenta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_catalogo_cuenta 
WHERE 
  id_cuenta = p_id_cuenta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_catalogo_cuenta(p_id_cuenta integer) OWNER TO postgres;

--
-- Name: d_delete_categoria(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_categoria(p_id_categoria integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_categoria 
WHERE 
  id_categoria = p_id_categoria
;
  return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_categoria(p_id_categoria integer) OWNER TO postgres;

--
-- Name: d_delete_destino_cuenta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_destino_cuenta(p_id_destino_cuenta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_destino_cuenta 
WHERE 
  id_destino_cuenta = p_id_destino_cuenta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_destino_cuenta(p_id_destino_cuenta integer) OWNER TO postgres;

--
-- Name: d_delete_estado(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_estado(p_id_estado integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
 DELETE FROM 
  contabilidad.tbl_estado
WHERE 
  id_estado = p_id_estado
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_estado(p_id_estado integer) OWNER TO postgres;

--
-- Name: d_delete_informe_financiero(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_informe_financiero(p_id_informe_financiero integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_informe_financiero 
WHERE 
  id_informe_financiero = p_id_informe_financiero
;
  return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_informe_financiero(p_id_informe_financiero integer) OWNER TO postgres;

--
-- Name: d_delete_libro_diario_detalle(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_libro_diario_detalle(p_id_libro_diario_deta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_libro_diario_detalle 
WHERE 
  id_libro_diario_deta = p_id_libro_diario_deta
;
  return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_libro_diario_detalle(p_id_libro_diario_deta integer) OWNER TO postgres;

--
-- Name: d_delete_libro_diario_encabezado(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_libro_diario_encabezado(p_id_libro_diario_enca integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_libro_diario_encabezado 
WHERE 
  id_libro_diario_enca = p_id_libro_diario_enca;
  return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_libro_diario_encabezado(p_id_libro_diario_enca integer) OWNER TO postgres;

--
-- Name: d_delete_libro_mayor(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_libro_mayor(p_id_libro_mayor integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
  DELETE FROM 
  contabilidad.tbl_libro_mayor 
WHERE 
  id_libro_mayor = p_id_libro_mayor
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_libro_mayor(p_id_libro_mayor integer) OWNER TO postgres;

--
-- Name: d_delete_periodo_contable(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_periodo_contable(p_id_periodo_contable integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  contabilidad.tbl_periodo_contable 
WHERE 
  id_periodo_contable = p_id_periodo_contable
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_periodo_contable(p_id_periodo_contable integer) OWNER TO postgres;

--
-- Name: d_delete_subcuenta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.d_delete_subcuenta(p_id_subcuenta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
 DELETE FROM 
  contabilidad.tbl_subcuenta 
WHERE 
  id_subcuenta = p_id_subcuenta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.d_delete_subcuenta(p_id_subcuenta integer) OWNER TO postgres;

--
-- Name: fcn_diario_insert(json); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_diario_insert(pdiario json) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

declare vdiario BIGINT = nextval('contabilidad.tbl_libro_diario_id_libro_diario_seq'::regclass);
declare vfecha date;
declare vid_periodo_contable integer;
begin

insert into public.my_table (entrada,salida,jsonfile) values(1,2,pdiario);
	select 	contabilidad.fcn_get_periodo(r.fecha) into vid_periodo_contable
		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r ;
		
		select 	r.fecha into vfecha
		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r limit 1;
	if (contabilidad.fcn_valida_fecha_periodo(vfecha)) then
		--INSERTA ENCABEZADO
		insert into contabilidad.tbl_libro_diario_encabezado(
			id_libro_diario_enca,
			id_estado,
			descripcion,
			fecha,
			id_usuario,
			id_periodo_contable

			) 

		select 		
			vdiario,
			r.id_estado,
			r.descripcion,
			r.fecha,
			r.id_usuario,
			vid_periodo_contable

		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r ;

		--INSERTA DETALLE
		insert into contabilidad.tbl_libro_diario_detalle(
			id_libro_diario_enca,
			id_subcuenta,
			monto_debe,
			monto_haber,
			sinopsis,
			id_sucursal,
			id_centro_costo
			) 
		select 		vdiario,
					(d.detalle ->'id_subcuenta')::text::integer as id_subcuenta,
					(d.detalle ->'monto_debe')::text::numeric as monto_debe,
					(d.detalle ->'monto_haber')::text::numeric as monto_haber,
					(d.detalle ->>'sinopsis')::text::varchar as sinopsis,
					(d.detalle ->>'id_sucursal')::text::integer as sucursal,
					(d.detalle ->>'id_centro_costo')::text::integer as centro_costo
		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json)
		cross join 	json_array_elements( pdiario::json -> 'detalle') as d(detalle)	;
		return 'Succes';
	else
		return 'ERROR: El periodo no esta activo o no esta abierto';	
	end if;
end;	
$$;


ALTER FUNCTION contabilidad.fcn_diario_insert(pdiario json) OWNER TO postgres;

--
-- Name: fcn_diario_mayorizar(integer, character varying, date); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_diario_mayorizar(pid_periodo integer, pdescripcion character varying, pfecha date) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

begin
	delete from contabilidad.tbl_libro_mayor 
	where id_periodo_contable=pid_periodo;
	insert into contabilidad.tbl_libro_mayor(
		id_periodo_contable,
		descripcion,
		fecha,
		id_cuenta,
		id_subcuenta,
		monto_debe,
		monto_haber
	)
	
	select     a.id_periodo_contable
				,pdescripcion
			  ,pfecha
			  ,e.id_cuenta
			  ,d.id_subcuenta
			  ,sum(d.monto_debe)
			  ,sum(d.monto_haber)
			  
		from     contabilidad.tbl_libro_diario_encabezado a
		inner join   contabilidad.tbl_libro_diario_detalle d on a.id_libro_diario_enca=d.id_libro_diario_enca
		inner join   contabilidad.tbl_estado c on a.id_estado=c.id_estado
		inner join  contabilidad.tbl_subcuenta e on d.id_subcuenta=e.id_subcuenta
		where a.id_periodo_contable=pid_periodo
		group by a.id_periodo_contable
			  ,a.fecha
			  ,e.id_cuenta
			  ,d.id_subcuenta;
	return 'Success';
	
end;	
$$;


ALTER FUNCTION contabilidad.fcn_diario_mayorizar(pid_periodo integer, pdescripcion character varying, pfecha date) OWNER TO postgres;

--
-- Name: fcn_diario_update(json); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_diario_update(pdiario json) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

declare vfecha date;
declare vid_libro_diario_enca bigint;
begin

insert into public.my_table (jsonfile) values(pdiario);
	--TRAE FECHA DEL DOCUMENTO
	select 	r.fecha into vfecha
	from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r ;
	
	select 	r.id_libro_diario_enca into vid_libro_diario_enca
	from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r ;
	
	if (contabilidad.fcn_valida_fecha_periodo(vfecha)) then
		--ACTUALIZA ENCABEZADO
		UPDATE contabilidad.tbl_libro_diario_encabezado SET
			id_estado=r.id_estado,
			descripcion=r.descripcion,
			fecha=r.fecha,
			id_usuario=r.id_usuario

		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json) as r 
		where		contabilidad.tbl_libro_diario_encabezado.id_libro_diario_enca=vid_libro_diario_enca;
		
		--BORRA DETALLE
		delete from contabilidad.tbl_libro_diario_detalle where id_libro_diario_enca=vid_libro_diario_enca;
		
		--INSERTA DETALLE
		insert into contabilidad.tbl_libro_diario_detalle(
			id_libro_diario_enca,
			id_subcuenta,
			monto_debe,
			monto_haber,
			sinopsis,
			id_sucursal,
			id_centro_costo
			) 
		select 		vid_libro_diario_enca,
					(d.detalle ->'id_subcuenta')::text::integer as id_subcuenta,
					(d.detalle ->'monto_debe')::text::numeric as monto_debe,
					(d.detalle ->'monto_haber')::text::numeric as monto_haber,
					(d.detalle ->>'sinopsis')::text::varchar as sinopsis,
					(d.detalle ->>'id_sucursal')::text::int as sucursal,
					(d.detalle ->>'id_centro_costo')::text::int as centro_costo
		from 		json_populate_record(null::contabilidad.ty_libro_diario_enca,pdiario::json)
		cross join 	json_array_elements( pdiario::json -> 'detalle') as d(detalle)	;
	return 'Success';
		
	else
		return 'ERROR: El periodo no esta activo o no esta abierto';	
	end if;
end;	
$$;


ALTER FUNCTION contabilidad.fcn_diario_update(pdiario json) OWNER TO postgres;

--
-- Name: fcn_get_periodo(date); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_get_periodo(pfecha date) RETURNS integer
    LANGUAGE plpgsql
    AS $$

declare vperiodo_activo int;

begin
	
	select id_periodo_contable  into vperiodo_activo from contabilidad.tbl_periodo_contable where pfecha >= fecha_inicial
	and pfecha<=fecha_final and estado_periodo='A' limit 1;
	return vperiodo_activo;
end;	
$$;


ALTER FUNCTION contabilidad.fcn_get_periodo(pfecha date) OWNER TO postgres;

--
-- Name: fcn_saldo_cuenta_update(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_saldo_cuenta_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
--declare vsaldo decimal;
begin
	--select saldo into vsaldo from contabilidad.tbl_catalogo_cuenta where id_cuenta = new.id_cuenta;
	--update contabilidad.tbl_catalogo_cuenta set
	--saldo = saldo + new.saldo
    --where id_cuenta=new.id_cuenta;
	
	RETURN NEW;
end;
$$;


ALTER FUNCTION contabilidad.fcn_saldo_cuenta_update() OWNER TO postgres;

--
-- Name: fcn_saldo_subcuenta_update(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_saldo_subcuenta_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare vid_cuenta integer;

begin
	select id_cuenta into vid_cuenta from contabilidad.tbl_subcuenta where id_subcuenta = new.id_subcuenta LIMIT 1;
	update contabilidad.tbl_subcuenta set
	saldo = saldo + new.monto_debe + new.monto_haber
    where id_subcuenta = new.id_subcuenta;
	
	update contabilidad.tbl_catalogo_cuenta set
	saldo = saldo + new.monto_debe + new.monto_haber
    where id_cuenta=vid_cuenta;
	
	RETURN NEW;
end;
$$;


ALTER FUNCTION contabilidad.fcn_saldo_subcuenta_update() OWNER TO postgres;

--
-- Name: fcn_saldo_update(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_saldo_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

begin
	update contabilidad.tbl_subcuenta set
	saldo = saldo + new.saldo
    where id_subcuenta = new.id_subcuenta
	and id_cuenta=new.id_cuenta;
	
	RETURN NEW;
end;
$$;


ALTER FUNCTION contabilidad.fcn_saldo_update() OWNER TO postgres;

--
-- Name: fcn_valida_fecha_periodo(date); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.fcn_valida_fecha_periodo(pfecha date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

declare vperiodo_activo int;

begin
	select count(*) into vperiodo_activo from contabilidad.tbl_periodo_contable where pfecha >= fecha_inicial
	and pfecha<=fecha_final and estado_periodo='A';
	if(vperiodo_activo >= 1) then
	return true;
	else return false;
	end if;
end;	
$$;


ALTER FUNCTION contabilidad.fcn_valida_fecha_periodo(pfecha date) OWNER TO postgres;

--
-- Name: ft_actualizar_catalogo(integer, character varying, character varying, integer, integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_catalogo(v_id_cuenta integer, v_codigo_cuenta character varying, v_nombre_cuenta character varying, v_id_categoria integer, v_id_destino_cuenta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_catalogo_cuenta 
SET 
  codigo_cuenta = v_codigo_cuenta,
  nombre_cuenta = v_nombre_cuenta,
  id_categoria = v_id_categoria,
  id_destino_cuenta = v_id_destino_cuenta
WHERE 
  id_cuenta = v_id_cuenta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_catalogo(v_id_cuenta integer, v_codigo_cuenta character varying, v_nombre_cuenta character varying, v_id_categoria integer, v_id_destino_cuenta integer) OWNER TO postgres;

--
-- Name: ft_actualizar_categoria(integer, character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_categoria(v_id_categoria integer, v_nombre_categoria character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_categoria 
SET 
  nombre_categoria = v_nombre_categoria
WHERE 
  id_categoria = v_id_categoria
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_categoria(v_id_categoria integer, v_nombre_categoria character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_destino_cuenta(integer, integer, integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_destino_cuenta(v_id_destino_cuenta integer, v_id_cuenta integer, v_id_informe_financiero integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_destino_cuenta 
SET 
  id_cuenta = v_id_cuenta,
  id_informe_financiero = v_id_informe_financiero
WHERE 
  id_destino_cuenta = v_id_destino_cuenta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_destino_cuenta(v_id_destino_cuenta integer, v_id_cuenta integer, v_id_informe_financiero integer) OWNER TO postgres;

--
-- Name: ft_actualizar_estado(integer, character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_estado(v_id_estado integer, v_tipo_estado character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_estado 
SET 
  tipo_estado = v_tipo_estado
WHERE 
  id_estado = v_id_estado
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_estado(v_id_estado integer, v_tipo_estado character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_informe_financiero(integer, character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_informe_financiero(v_id_informe_financiero integer, v_descripcion character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_informe_financiero 
SET 
  descripcion = v_descripcion
WHERE 
  id_informe_financiero = v_id_informe_financiero
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_informe_financiero(v_id_informe_financiero integer, v_descripcion character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_libro_diario_detalle(integer, integer, integer, numeric, numeric, numeric, character varying, integer, integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_libro_diario_detalle(v_id_libro_diario_deta integer, v_id_subcuenta integer, v_id_estado integer, v_parcial numeric, v_monto_debe numeric, v_monto_haber numeric, v_sinopsis character varying, v_id_sucursal integer, v_id_centro_costo integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_libro_diario_detalle 
SET 
  id_subcuenta = v_id_subcuenta,
  id_estado = v_id_estado,
  parcial = v_parcial,
  monto_debe = v_monto_debe,
  monto_haber = v_monto_haber,
  sinopsis = v_sinopsis,
  sucursal = v_id_sucursal,
  centro_costo = v_id_centro_costo
WHERE 
  id_libro_diario_deta = v_id_libro_diario_deta
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_libro_diario_detalle(v_id_libro_diario_deta integer, v_id_subcuenta integer, v_id_estado integer, v_parcial numeric, v_monto_debe numeric, v_monto_haber numeric, v_sinopsis character varying, v_id_sucursal integer, v_id_centro_costo integer) OWNER TO postgres;

--
-- Name: ft_actualizar_libro_diario_encabezado(integer, integer, date, numeric, numeric); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_libro_diario_encabezado(v_id_libro_diario_enca integer, v_id_estado integer, v_fecha date, v_monto_debe numeric, v_monto_haber numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_libro_diario_encabezado 
SET 
  id_estado = v_id_estado,
  fecha = v_fecha,
  monto_debe = v_monto_debe,
  monto_haber = v_monto_haber
WHERE 
  id_libro_diario_enca = v_id_libro_diario_enca
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_libro_diario_encabezado(v_id_libro_diario_enca integer, v_id_estado integer, v_fecha date, v_monto_debe numeric, v_monto_haber numeric) OWNER TO postgres;

--
-- Name: ft_actualizar_libro_mayor(integer, integer, date, integer, integer, numeric, numeric); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_libro_mayor(v_id_libro_mayor integer, v_id_periodo_contable integer, v_fecha date, v_id_cuenta integer, v_id_subcuenta integer, v_monto_debe numeric, v_monto_haber numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  contabilidad.tbl_libro_mayor 
SET 
  id_periodo_contable = v_id_periodo_contable,
  fecha = v_fecha,
  id_cuenta = v_id_cuenta,
  id_subcuenta = v_id_subcuenta,
  monto_debe = v_monto_debe,
  monto_haber = v_monto_haber
WHERE 
  id_libro_mayor = v_id_libro_mayor
;
return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_libro_mayor(v_id_libro_mayor integer, v_id_periodo_contable integer, v_fecha date, v_id_cuenta integer, v_id_subcuenta integer, v_monto_debe numeric, v_monto_haber numeric) OWNER TO postgres;

--
-- Name: ft_actualizar_periodo_contable(integer, character varying, date, date, timestamp without time zone, integer, character, character); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_periodo_contable(v_id_periodo_contable integer, v_descripcion_periodo character varying, v_fecha_inicial date, v_fecha_final date, v_fecha_creacion timestamp without time zone, v_id_usuario integer, v_tipo_periodo character, v_estado_periodo character) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
UPDATE 
  contabilidad.tbl_periodo_contable 
SET 
  descripcion_periodo = v_descripcion_periodo,
  fecha_inicial = v_fecha_inicial,
  fecha_final = v_fecha_final,
  fecha_creacion = v_fecha_creacion,
  id_usuario = v_id_usuario,
  tipo_periodo = v_tipo_periodo,
  estado_periodo = v_estado_periodo
WHERE 
  id_periodo_contable = v_id_periodo_contable;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_periodo_contable(v_id_periodo_contable integer, v_descripcion_periodo character varying, v_fecha_inicial date, v_fecha_final date, v_fecha_creacion timestamp without time zone, v_id_usuario integer, v_tipo_periodo character, v_estado_periodo character) OWNER TO postgres;

--
-- Name: ft_actualizar_subcuenta(integer, integer, character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_actualizar_subcuenta(v_id_subcuenta integer, v_id_cuenta integer, v_nombre_subcuenta character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
UPDATE 
  contabilidad.tbl_subcuenta 
SET 
  id_cuenta = v_id_cuenta,
  nombre_subcuenta = v_nombre_subcuenta
WHERE 
  id_subcuenta = v_id_subcuenta
;return true;
END;
$$;


ALTER FUNCTION contabilidad.ft_actualizar_subcuenta(v_id_subcuenta integer, v_id_cuenta integer, v_nombre_subcuenta character varying) OWNER TO postgres;

--
-- Name: ft_fechak(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_fechak() RETURNS TABLE(id_periodo_contable integer, fecha_inicial date, fecha_final date)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
 SELECT 
a.id_periodo_contable,
a.fecha_inicial,
a.fecha_final
FROM 
  contabilidad.tbl_periodo_contable a ;
END;
$$;


ALTER FUNCTION contabilidad.ft_fechak() OWNER TO postgres;

--
-- Name: ft_get_detalles(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_get_detalles(v_id_libro_diario_enca integer DEFAULT 0) RETURNS TABLE(id_libro_diario_deta bigint, id_libro_diario_enca bigint, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select 
b.id_libro_diario_deta,
a.id_libro_diario_enca,
a.descripcion
from contabilidad.tbl_libro_diario_encabezado a
right join contabilidad.tbl_libro_diario_detalle b on a.id_libro_diario_enca =b.id_libro_diario_enca
where a.id_libro_diario_enca=v_id_libro_diario_enca;
END;
$$;


ALTER FUNCTION contabilidad.ft_get_detalles(v_id_libro_diario_enca integer) OWNER TO postgres;

--
-- Name: ft_getone_catalago_cuenta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_catalago_cuenta(v_id_cuenta integer DEFAULT 0) RETURNS TABLE(id_cuenta integer, nombre_usuario character varying, codigo_cuenta character varying, nombre_cuenta character varying, nombre_categoria character varying, descripcion character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
Select
a.id_cuenta,
c.nombre_usuario,
a.codigo_cuenta,
a.nombre_cuenta,
b.nombre_categoria,
f.descripcion,
a.saldo
from contabilidad.tbl_catalogo_cuenta a
left join contabilidad.tbl_categoria b on a.id_categoria=b.id_categoria
left join seguridad.tbl_ms_usuario c on a.id_usuario=c.id_usuario
left join contabilidad.tbl_destino_cuenta d on a.id_destino_cuenta=d.id_cuenta
left join contabilidad.tbl_informe_financiero f on d.id_informe_financiero=f.id_informe_financiero
where a.id_cuenta = v_id_cuenta;
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_catalago_cuenta(v_id_cuenta integer) OWNER TO postgres;

--
-- Name: ft_getone_libro_diario_deta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_libro_diario_deta(v_id_libro_diario_deta integer DEFAULT 0) RETURNS TABLE(id_libro_diario_deta bigint, id_libro_diario_enca bigint, nombre_subcuenta character varying, tipo_estado character varying, parcial numeric, monto_debe numeric, monto_haber numeric, sinopsis character varying, sucursal character varying, centro_costo character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
Select
a.id_libro_diario_deta,
b.id_libro_diario_enca,
c.nombre_subcuenta,
d.tipo_estado,
a.parcial,
a.monto_debe,
a.monto_haber,
a.sinopsis,
a.sucursal,
a.centro_costo
from contabilidad.tbl_libro_diario_detalle a
left join contabilidad.tbl_libro_diario_encabezado b on a.id_libro_diario_enca =b.id_libro_diario_enca
left join contabilidad.tbl_subcuenta c on a.id_subcuenta =c.id_subcuenta
left join contabilidad.tbl_estado d on a.id_estado =d.id_estado
where a.id_libro_diario_deta= v_id_libro_diario_deta;

END;
$$;


ALTER FUNCTION contabilidad.ft_getone_libro_diario_deta(v_id_libro_diario_deta integer) OWNER TO postgres;

--
-- Name: ft_getone_libro_diario_detalle2(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_libro_diario_detalle2(v_id_libro_diario_enca integer DEFAULT 0) RETURNS TABLE(id_libro_diario_deta bigint, id_libro_diario_enca bigint, id_subcuenta bigint, id_estado bigint, parcial numeric, monto_debe numeric, monto_haber numeric, sinopsis character varying, sucursal character varying, centro_costo character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
select  a.id_libro_diario_deta, b.id_libro_diario_enca, a.id_subcuenta, d.tipo_estado, a.parcial, a.monto_debe, a.monto_haber, a.sinopsis, a.sucursal, a.centro_costo
from contabilidad.tbl_libro_diario_detalle a 
left join contabilidad.tbl_libro_diario_encabezado b ON a.id_libro_diario_enca = b.id_libro_diario_enca
left join contabilidad.tbl_estado d ON a.id_estado = d.id_estado
where a.id_libro_diario_enca= v_id_libro_diario_enca;
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_libro_diario_detalle2(v_id_libro_diario_enca integer) OWNER TO postgres;

--
-- Name: ft_getone_libro_diario_enca(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_libro_diario_enca(v_id_libro_diario_enca integer DEFAULT 0) RETURNS TABLE(id_libro_diario_enca bigint, tipo_estado character varying, descripcion character varying, fecha date, monto_debe numeric, monto_haber numeric, nombre_usuario character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
Select
a.id_libro_diario_enca,
b.tipo_estado,
a.descripcion,
a.fecha,
a.monto_debe,
a.monto_haber,
c.nombre_usuario
from contabilidad.tbl_libro_diario_encabezado a
left join contabilidad.tbl_estado b on a.id_estado =b.id_estado
left join seguridad.tbl_ms_usuario c on a.id_usuario =c.id_usuario
where a.id_libro_diario_enca = v_id_libro_diario_enca;
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_libro_diario_enca(v_id_libro_diario_enca integer) OWNER TO postgres;

--
-- Name: ft_getone_libro_mayor(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_libro_mayor(v_id_libro_mayor integer DEFAULT 0) RETURNS TABLE(id_libro_mayor integer, id_periodo_contable integer, fecha date, nombre_cuenta character varying, nombre_subcuenta character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
SELECT a.id_libro_mayor, c.id_periodo_contable, a.fecha, b.nombre_cuenta,d.nombre_subcuenta, d.saldo FROM 
  contabilidad.tbl_libro_mayor a
  left JOIN contabilidad.tbl_catalogo_cuenta b ON a.id_cuenta = b.id_cuenta
  left JOIN contabilidad.tbl_periodo_contable c ON a.id_periodo_contable = c.id_periodo_contable
  left JOIN contabilidad.tbl_subcuenta d ON a.id_subcuenta = d.id_subcuenta
  where a.id_libro_mayor = v_id_libro_mayor;
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_libro_mayor(v_id_libro_mayor integer) OWNER TO postgres;

--
-- Name: ft_getone_periodo_contable(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_periodo_contable(id_periodo integer) RETURNS TABLE(id_periodo_contable integer, descripcion_periodo character varying, fecha_inicial date, fecha_final date, fecha_creacion timestamp without time zone, id_usuario integer, nombre_usuario character varying, tipo_periodo character, estado_periodo character)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT a.id_periodo_contable, a.descripcion_periodo, a.fecha_inicial, a.fecha_final, a.fecha_creacion,
		a.id_usuario, b.nombre_usuario, a.tipo_periodo, a.estado_periodo FROM 
  contabilidad.tbl_periodo_contable a
  LEFT JOIN seguridad.tbl_ms_usuario b ON
  a.id_usuario = b.id_usuario
  WHERE a.id_periodo_contable = id_periodo;
  
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_periodo_contable(id_periodo integer) OWNER TO postgres;

--
-- Name: ft_getone_subcuenta(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_getone_subcuenta(v_id_subcuenta integer DEFAULT 0) RETURNS TABLE(id_subcuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
Select
a.id_subcuenta,
b.nombre_cuenta,
a.nombre_subcuenta,
a.saldo
from contabilidad.tbl_subcuenta a
left join contabilidad.tbl_catalogo_cuenta b on a.id_cuenta = b.id_cuenta
where a.id_subcuenta = v_id_subcuenta;
END;
$$;


ALTER FUNCTION contabilidad.ft_getone_subcuenta(v_id_subcuenta integer) OWNER TO postgres;

--
-- Name: ft_json_diario(bigint); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_json_diario(pid_libro_diario_enca bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_diario json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_diario result
from (
    select 
        jsonb_build_object(
            'id_libro_diario_enca', s.id_libro_diario_enca, 
			'id_estado', s.id_libro_diario_enca, 
            'tipo_estado', c.tipo_estado, 
			'descripcion',s.descripcion,
			'fecha',s.fecha ,
			'id_usuario',s.id_usuario ,
			'usuario',b.usuario ,
			'id_periodo_contable',s.id_periodo_contable ,
			'descripcion_periodo',d.descripcion_periodo ,
            'detalle', contabilidad.ft_json_diario_detalle(s.id_libro_diario_enca)
			
        ) js_object
    from contabilidad.tbl_libro_diario_encabezado s
	left join	seguridad.tbl_ms_usuario b on s.id_usuario=b.id_usuario
	inner join 	contabilidad.tbl_estado c on c.id_estado = s.id_estado
	inner join 	contabilidad.tbl_periodo_contable d on d.id_periodo_contable = s.id_periodo_contable
	where s.id_libro_diario_enca=pid_libro_diario_enca
    group by s.id_libro_diario_enca, 
	s.id_libro_diario_enca, 
	c.tipo_estado,
	s.descripcion,
	s.fecha ,
	s.id_usuario ,
	b.usuario ,
	s.id_periodo_contable ,
	d.descripcion_periodo
    ) s;
return json_diario;
END;
$$;


ALTER FUNCTION contabilidad.ft_json_diario(pid_libro_diario_enca bigint) OWNER TO postgres;

--
-- Name: ft_json_diario_detalle(bigint); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_json_diario_detalle(pid_libro_diario_enca bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_diario_detalle json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle)) into json_diario_detalle result
from (
select 
           jsonb_build_object(
					'id_libro_diario_deta', d.id_libro_diario_deta, 
					'id_libro_diario_enca', d.id_libro_diario_enca, 
					'id_subcuenta', d.id_subcuenta, 
			   		'nombre_subcuenta', f.nombre_subcuenta,
			   		'monto_debe',d.monto_debe,
					'monto_haber', d.monto_haber,
			   		'sinopsis',d.sinopsis,
			   		'id_sucursal',d.id_sucursal,
			   		'descripcion_sucursal',g.descripcion,
			   		'id_centro_costo', d.id_centro_costo,
			   		'descripcion_centro_costo', h.descripcion
					
				) detalle
        from contabilidad.tbl_libro_diario_encabezado e
        inner join contabilidad.tbl_libro_diario_detalle d on d.id_libro_diario_enca = e.id_libro_diario_enca
		inner join contabilidad.tbl_subcuenta f on f.id_subcuenta = d.id_subcuenta
		left join public.tbl_sucursal g on g.id_sucursal = d.id_sucursal
		left join public.tbl_centro_costo h on h.id_centro_costo = d.id_centro_costo
		
		where e.id_libro_diario_enca=pid_libro_diario_enca
)a;
return json_diario_detalle;
END;

$$;


ALTER FUNCTION contabilidad.ft_json_diario_detalle(pid_libro_diario_enca bigint) OWNER TO postgres;

--
-- Name: ft_resta_totales(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_resta_totales() RETURNS TABLE(total numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
  Select 

contabilidad.ft_total_ingresos() - contabilidad.ft_total_gastos() as total;
END;
$$;


ALTER FUNCTION contabilidad.ft_resta_totales() OWNER TO postgres;

--
-- Name: ft_select_activo(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_activo() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
return query
Select a.id_destino_cuenta
	,c.nombre_cuenta
	, d.nombre_subcuenta
	, e.nombre_categoria
	, d.saldo 
	from 
contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=1 and c.id_categoria = 1 ;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_activo() OWNER TO postgres;

--
-- Name: ft_select_balance_general(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_balance_general() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, nombre_categoria character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
Select a.id_destino_cuenta, c.nombre_cuenta, d.nombre_subcuenta, b.descripcion, e.nombre_categoria, d.saldo from 
contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=1;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_balance_general() OWNER TO postgres;

--
-- Name: ft_select_catalogo_cuenta(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_catalogo_cuenta() RETURNS TABLE(id_cuenta integer, nombre_usuario character varying, codigo_cuenta character varying, nombre_cuenta character varying, nombre_categoria character varying, descripcion character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
Select a.id_cuenta, c.nombre_usuario, a.codigo_cuenta, a.nombre_cuenta, b.nombre_categoria, e.descripcion
from contabilidad.tbl_catalogo_cuenta a
left join contabilidad.tbl_categoria b on a.id_categoria=b.id_categoria
left join seguridad.tbl_ms_usuario c on a.id_usuario=c.id_usuario
left join contabilidad.tbl_destino_cuenta d on a.id_destino_cuenta=d.id_destino_cuenta
left join contabilidad.tbl_informe_financiero e on d.id_informe_financiero = e.id_informe_financiero;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_catalogo_cuenta() OWNER TO postgres;

--
-- Name: ft_select_categoria(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_categoria() RETURNS TABLE(id_categoria integer, nombre_categoria character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT * FROM contabilidad.tbl_categoria ;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_categoria() OWNER TO postgres;

--
-- Name: ft_select_destino_cuenta(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_destino_cuenta() RETURNS TABLE(id_destino_cuenta integer, descripcion_informe_financiero character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
SELECT 

  a.id_destino_cuenta,
case a.id_destino_cuenta
					when '1' then 'BALANCE GENERAL'
					WHEN '12' THEN 'ESTADO DE RESULTADO'
					WHEN '11' THEN 'INGRESOS Y GASTOS'
					end::varchar descripcion_informe_financiero

FROM contabilidad.tbl_destino_cuenta a 
where a.id_destino_cuenta = 1 or a.id_destino_cuenta = 12 or a.id_destino_cuenta = 11;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_destino_cuenta() OWNER TO postgres;

--
-- Name: ft_select_diario_detalle(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_diario_detalle() RETURNS TABLE(id_libro_diario_deta bigint, id_libro_diario_enca bigint, nombre_subcuenta character varying, tipo_estado character varying, parcial numeric, monto_debe numeric, monto_haber numeric, sinopsis character varying, id_sucursal integer, id_centro_costo integer)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
Select
a.id_libro_diario_deta,
b.id_libro_diario_enca,
c.nombre_subcuenta,
d.tipo_estado,
a.parcial,
a.monto_debe,
a.monto_haber,
a.sinopsis,
a.id_sucursal,
a.id_centro_costo
from contabilidad.tbl_libro_diario_detalle a
left join contabilidad.tbl_libro_diario_encabezado b on a.id_libro_diario_enca =b.id_libro_diario_enca
left join contabilidad.tbl_subcuenta c on a.id_subcuenta =c.id_subcuenta
left join contabilidad.tbl_estado d on a.id_estado =d.id_estado;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_diario_detalle() OWNER TO postgres;

--
-- Name: ft_select_estado(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_estado() RETURNS TABLE(id_estado integer, tipo_estado character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
SELECT * FROM contabilidad.tbl_estado ;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_estado() OWNER TO postgres;

--
-- Name: ft_select_estado_resultados(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_estado_resultados() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, nombre_categoria character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
  Select a.id_destino_cuenta, c.nombre_cuenta, d.nombre_subcuenta, b.descripcion, e.nombre_categoria, d.saldo   from 
contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=2;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_estado_resultados() OWNER TO postgres;

--
-- Name: ft_select_gastos(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_gastos() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, nombre_categoria character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
return query
  Select 
 a.id_destino_cuenta,
 c.nombre_cuenta,
 d.nombre_subcuenta,
 b.descripcion,
 e.nombre_categoria,
 c.saldo
  from contabilidad.tbl_destino_cuenta a
  left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
  left join contabilidad.tbl_catalogo_cuenta c on a.id_cuenta =c.id_cuenta
  left join contabilidad.tbl_subcuenta d on c.id_cuenta =d.id_cuenta
  left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
	where a.id_informe_financiero=3 and c.id_cuenta=12;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_gastos() OWNER TO postgres;

--
-- Name: ft_select_informe_financiero(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_informe_financiero() RETURNS TABLE(id_informe_financiero integer, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
 SELECT * FROM contabilidad.tbl_informe_financiero ;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_informe_financiero() OWNER TO postgres;

--
-- Name: ft_select_ingresos(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_ingresos() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, nombre_categoria character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
  Select 
 a.id_destino_cuenta,
 c.nombre_cuenta,
 d.nombre_subcuenta,
 b.descripcion,
 e.nombre_categoria,
 c.saldo*(-1)
  from contabilidad.tbl_destino_cuenta a
  left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
  left join contabilidad.tbl_catalogo_cuenta c on a.id_cuenta =c.id_cuenta
  left join contabilidad.tbl_subcuenta d on c.id_cuenta =d.id_cuenta
  left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
	where a.id_informe_financiero=3 and c.id_cuenta=11;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_ingresos() OWNER TO postgres;

--
-- Name: ft_select_libro_diario_detalle(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_libro_diario_detalle(pid_libro_diario_enca integer) RETURNS TABLE(id_libro_diario_deta bigint, id_libro_diario_enca bigint, id_subcuenta integer, nombre_subcuenta character varying, monto_debe numeric, monto_haber numeric, sinopsis character varying, id_sucursal integer, centro_costo integer)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
		select 		b.id_libro_diario_deta
					,a.id_libro_diario_enca
					,b.id_subcuenta
					,f.nombre_subcuenta
					,b.monto_debe
					,b.monto_haber	
                    ,b.sinopsis			
                    ,b.id_sucursal
					,b.id_centro_costo


		from 		contabilidad.tbl_libro_diario_encabezado a
		inner join 	contabilidad.tbl_libro_diario_detalle b on a.id_libro_diario_enca=b.id_libro_diario_enca
		inner join	contabilidad.tbl_estado c on a.id_estado=c.id_estado
		inner join 	contabilidad.tbl_periodo_contable d on a.id_periodo_contable=d.id_periodo_contable
		left join 	seguridad.tbl_ms_usuario e on a.id_usuario=e.id_usuario
		inner join	contabilidad.tbl_subcuenta f on b.id_subcuenta=f.id_subcuenta
		where		a.id_libro_diario_enca=pid_libro_diario_enca;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_libro_diario_detalle(pid_libro_diario_enca integer) OWNER TO postgres;

--
-- Name: ft_select_libro_diario_encabezado(integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_libro_diario_encabezado(pid_periodo integer) RETURNS TABLE(id_libro_diario_enca bigint, id_estado integer, tipo_estado character varying, descripcion character varying, fecha character varying, monto_debe numeric, monto_haber numeric, id_usuario integer, usuario character varying, id_periodo_contable integer, descripcion_periodo character varying, fecha_inicial character varying, fecha_final character varying, tipo_periodo character, descripcion_tipo_periodo character varying, estado_periodo character, descripcion_estado_periodo character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
		select 		a.id_libro_diario_enca
					,a.id_estado
					,c.tipo_estado
					,a.descripcion
					,a.fecha::VARCHAR
					,0::numeric monto_debe
					,0::numeric monto_haber
					,a.id_usuario
					,e.usuario
					,a.id_periodo_contable
					,d.descripcion_periodo
					,d.fecha_inicial::VARCHAR
					,d.fecha_final::VARCHAR
					,d.tipo_periodo
					,case d.tipo_periodo
					WHEN 'M' THEN 'MENSUAL'
					END::varchar descripcion_tipo_periodo
					,d.estado_periodo
					,case d.estado_periodo
					when 'A' then 'ABIERTO'
					WHEN 'C' THEN 'CERRADO'
					WHEN 'M' THEN 'MAYORIZADO'
					end::varchar descripcion_estado_periodo
		from 		contabilidad.tbl_libro_diario_encabezado a

		inner join	contabilidad.tbl_estado c on a.id_estado=c.id_estado
		inner join 	contabilidad.tbl_periodo_contable d on a.id_periodo_contable=d.id_periodo_contable
		left join 	seguridad.tbl_ms_usuario e on a.id_usuario=e.id_usuario
		where		a.id_periodo_contable=pid_periodo;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_libro_diario_encabezado(pid_periodo integer) OWNER TO postgres;

--
-- Name: ft_select_libro_mayor(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_libro_mayor() RETURNS TABLE(id_periodo_contable integer, descripcion character varying, fecha date, nombre_cuenta character varying, nombre_subcuenta character varying, monto_debe numeric, monto_haber numeric, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
SELECT  
c.id_periodo_contable, 
f.descripcion,
a.fecha, 
b.nombre_cuenta,
d.nombre_subcuenta, 
e.monto_debe,
e.monto_haber,
d.saldo 
FROM contabilidad.tbl_libro_mayor a
  left JOIN contabilidad.tbl_catalogo_cuenta b ON a.id_cuenta = b.id_cuenta
  left JOIN contabilidad.tbl_periodo_contable c ON a.id_periodo_contable = c.id_periodo_contable
  left JOIN contabilidad.tbl_subcuenta d ON a.id_subcuenta = d.id_subcuenta
  left JOIN contabilidad.tbl_libro_diario_detalle  e on a.id_subcuenta = e.id_subcuenta
  left JOIN contabilidad.tbl_libro_diario_encabezado f on e.id_libro_diario_enca =f.id_libro_diario_enca;
END;
$$;


ALTER FUNCTION contabilidad.ft_select_libro_mayor() OWNER TO postgres;

--
-- Name: ft_select_pasivo(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_pasivo() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
Select a.id_destino_cuenta
		,c.nombre_cuenta
	, d.nombre_subcuenta
	, e.nombre_categoria
	, d.saldo from 
contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=1 and c.id_categoria = 2 ;

END;
$$;


ALTER FUNCTION contabilidad.ft_select_pasivo() OWNER TO postgres;

--
-- Name: ft_select_patrimonio(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_patrimonio() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, descripcion character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
Select a.id_destino_cuenta
	,c.nombre_cuenta
	, d.nombre_subcuenta
	, e.nombre_categoria
	, d.saldo from 
contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=1 and c.id_categoria = 3 ;

END;
$$;


ALTER FUNCTION contabilidad.ft_select_patrimonio() OWNER TO postgres;

--
-- Name: ft_select_periodo_contable(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_periodo_contable() RETURNS TABLE(id_periodo_contable integer, descripcion_periodo character varying, fecha_inicial character varying, fecha_final character varying, fecha_creacion character varying, id_usuario integer, nombre_usuario character varying, tipo_periodo character, estado_periodo character)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY
SELECT a.id_periodo_contable, a.descripcion_periodo, a.fecha_inicial::VARCHAR, a.fecha_final::VARCHAR, a.fecha_creacion::VARCHAR, 
		a.id_usuario, b.nombre_usuario, a.tipo_periodo, a.estado_periodo FROM 
  contabilidad.tbl_periodo_contable a
  LEFT JOIN seguridad.tbl_ms_usuario b ON
  a.id_usuario = b.id_usuario;
  
END;
$$;


ALTER FUNCTION contabilidad.ft_select_periodo_contable() OWNER TO postgres;

--
-- Name: ft_select_subcuenta(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_select_subcuenta() RETURNS TABLE(id_subcuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
Select
a.id_subcuenta,
b.nombre_cuenta,
a.nombre_subcuenta,
a.saldo
from contabilidad.tbl_subcuenta a
left join contabilidad.tbl_catalogo_cuenta b on a.id_cuenta = b.id_cuenta;

END;
$$;


ALTER FUNCTION contabilidad.ft_select_subcuenta() OWNER TO postgres;

--
-- Name: ft_total(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total() RETURNS TABLE(id_destino_cuenta integer, nombre_cuenta character varying, nombre_subcuenta character varying, nombre_categoria character varying, saldo numeric, sumtotal numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
return query
Select 
a.id_destino_cuenta,
c.nombre_cuenta,
d.nombre_subcuenta,
e.nombre_categoria,
d.saldo,
sum(d.saldo) OVER () AS sumtotal 
from contabilidad.tbl_destino_cuenta a
left join contabilidad.tbl_informe_financiero b on a.id_informe_financiero =b.id_informe_financiero
left join contabilidad.tbl_catalogo_cuenta c on a.id_destino_cuenta = c.id_destino_cuenta 
left join contabilidad.tbl_subcuenta d on c.id_cuenta = d.id_cuenta
left join contabilidad.tbl_categoria e on e.id_categoria = c.id_categoria
where b.id_informe_financiero=1 and c.id_categoria = 1 
group by 
a.id_destino_cuenta,
c.nombre_cuenta,
d.nombre_subcuenta,
e.nombre_categoria,
d.saldo;
END;
$$;


ALTER FUNCTION contabilidad.ft_total() OWNER TO postgres;

--
-- Name: ft_total_activo(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_activo() RETURNS TABLE(sumtotal numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select sum(saldo) as sumtotal_activo from contabilidad.ft_select_activo();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_activo() OWNER TO postgres;

--
-- Name: ft_total_gastos(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_gastos() RETURNS TABLE(sumtotal_gastos numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select sum(saldo) as sumtotal_gastos from contabilidad.ft_select_gastos();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_gastos() OWNER TO postgres;

--
-- Name: ft_total_ingresos(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_ingresos() RETURNS TABLE(sumtotal_ingresos numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select sum(saldo) as sumtotal_ingresos from contabilidad.ft_select_ingresos();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_ingresos() OWNER TO postgres;

--
-- Name: ft_total_ingresos_gastos(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_ingresos_gastos() RETURNS TABLE(sumtotal_ingresos numeric, sumtotal_gastos numeric, total_ingreso_gasto numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select (sumtotal_ingresos-sumtotal_gastos) as total_ingreso_gasto
from contabilidad.ft_total_ingresos(), contabilidad.ft_total_gastos();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_ingresos_gastos() OWNER TO postgres;

--
-- Name: ft_total_pasivo(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_pasivo() RETURNS TABLE(sumtotal_pasivo numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select sum(saldo) as sumtotal_pasivo from contabilidad.ft_select_pasivo();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_pasivo() OWNER TO postgres;

--
-- Name: ft_total_patrimonio(); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.ft_total_patrimonio() RETURNS TABLE(sumtotal_patrimonio numeric)
    LANGUAGE plpgsql
    AS $$

BEGIN
return query
select sum(saldo) as sumtotal_patrimonio from contabilidad.ft_select_patrimonio();
END;
$$;


ALTER FUNCTION contabilidad.ft_total_patrimonio() OWNER TO postgres;

--
-- Name: prc_libro_diario_enca_insert(integer, date, numeric, numeric, integer, character varying); Type: PROCEDURE; Schema: contabilidad; Owner: postgres
--

CREATE PROCEDURE contabilidad.prc_libro_diario_enca_insert(IN pid_estado integer, IN pfecha date, IN pmonto_debe numeric, IN pmonto_haber numeric, IN pid_usuario integer, IN pnombre_usuario character varying)
    LANGUAGE sql
    AS $$
insert into contabilidad.tbl_libro_diario_encabezado(
	id_estado ,
	fecha ,
	monto_debe ,
	monto_haber ,
	id_usuario ,
	nombre_usuario 
	) 
values (
	pid_estado ,
	pfecha ,
	pmonto_debe ,
	pmonto_haber ,
	pid_usuario ,
	pnombre_usuario 
	)
$$;


ALTER PROCEDURE contabilidad.prc_libro_diario_enca_insert(IN pid_estado integer, IN pfecha date, IN pmonto_debe numeric, IN pmonto_haber numeric, IN pid_usuario integer, IN pnombre_usuario character varying) OWNER TO postgres;

--
-- Name: sp_insert_catalogo_cuenta(integer, character varying, character varying, integer, integer, numeric); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_catalogo_cuenta(v_id_usuario integer, v_codigo_cuenta character varying, v_nombre_cuenta character varying, v_id_categoria integer, v_id_destino_cuenta integer, v_saldo numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
 INSERT INTO 
  contabilidad.tbl_catalogo_cuenta
(
  id_usuario,
  codigo_cuenta,
  nombre_cuenta,
  id_categoria,
  id_destino_cuenta,
  saldo
)
VALUES (
  v_id_usuario,
  v_codigo_cuenta,
  v_nombre_cuenta,
  v_id_categoria,
  v_id_destino_cuenta,
  v_saldo
);

END;
$$;


ALTER FUNCTION contabilidad.sp_insert_catalogo_cuenta(v_id_usuario integer, v_codigo_cuenta character varying, v_nombre_cuenta character varying, v_id_categoria integer, v_id_destino_cuenta integer, v_saldo numeric) OWNER TO postgres;

--
-- Name: sp_insert_categoria(character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_categoria(v_nombre_categoria character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  contabilidad.tbl_categoria
(
  nombre_categoria
)
VALUES (
  v_nombre_categoria
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_categoria(v_nombre_categoria character varying) OWNER TO postgres;

--
-- Name: sp_insert_destino_cuenta(integer, integer); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_destino_cuenta(v_id_cuenta integer, v_id_informe_financiero integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
INSERT INTO 
  contabilidad.tbl_destino_cuenta
(
  id_cuenta,
  id_informe_financiero
)
VALUES (
  v_id_cuenta,
  v_id_informe_financiero
);

END;
$$;


ALTER FUNCTION contabilidad.sp_insert_destino_cuenta(v_id_cuenta integer, v_id_informe_financiero integer) OWNER TO postgres;

--
-- Name: sp_insert_estado(character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_estado(v_tipo_estado character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN

INSERT INTO 
  contabilidad.tbl_estado
(
  tipo_estado
)
VALUES (
  v_tipo_estado
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_estado(v_tipo_estado character varying) OWNER TO postgres;

--
-- Name: sp_insert_informe_financiero(character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_informe_financiero(v_descripcion character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  contabilidad.tbl_informe_financiero
(
  descripcion
)
VALUES (
  v_descripcion
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_informe_financiero(v_descripcion character varying) OWNER TO postgres;

--
-- Name: sp_insert_libro_mayor(integer, date, integer, integer, numeric, numeric); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_libro_mayor(v_id_periodo_contable integer, v_fecha date, v_id_cuenta integer, v_id_subcuenta integer, v_monto_debe numeric, v_monto_haber numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  contabilidad.tbl_libro_mayor
(
  id_periodo_contable,
  fecha,
  id_cuenta,
  id_subcuenta,
  monto_debe,
  monto_haber
)
VALUES (
  v_id_periodo_contable,
  v_fecha,
  v_id_cuenta,
  v_id_subcuenta,
  v_monto_debe,
  v_monto_haber
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_libro_mayor(v_id_periodo_contable integer, v_fecha date, v_id_cuenta integer, v_id_subcuenta integer, v_monto_debe numeric, v_monto_haber numeric) OWNER TO postgres;

--
-- Name: sp_insert_periodo_contable(character varying, date, date, timestamp without time zone, integer, character, character); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_periodo_contable(v_descripcion_periodo character varying, v_fecha_inicial date, v_fecha_final date, v_fecha_creacion timestamp without time zone, v_id_usuario integer, v_tipo_periodo character, v_estado_periodo character) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  contabilidad.tbl_periodo_contable
(
  descripcion_periodo,
  fecha_inicial,
  fecha_final,
  fecha_creacion,
  id_usuario,
  tipo_periodo,
  estado_periodo
)
VALUES (
  v_descripcion_periodo,
  v_fecha_inicial,
  v_fecha_final,
  v_fecha_creacion,
  v_id_usuario,
  v_tipo_periodo,
  v_estado_periodo
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_periodo_contable(v_descripcion_periodo character varying, v_fecha_inicial date, v_fecha_final date, v_fecha_creacion timestamp without time zone, v_id_usuario integer, v_tipo_periodo character, v_estado_periodo character) OWNER TO postgres;

--
-- Name: sp_insert_subcuenta(integer, character varying); Type: FUNCTION; Schema: contabilidad; Owner: postgres
--

CREATE FUNCTION contabilidad.sp_insert_subcuenta(v_id_cuenta integer, v_nombre_subcuenta character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
INSERT INTO 
  contabilidad.tbl_subcuenta
(
  id_cuenta,
  nombre_subcuenta
)
VALUES (
  v_id_cuenta,
  v_nombre_subcuenta
);
END;
$$;


ALTER FUNCTION contabilidad.sp_insert_subcuenta(v_id_cuenta integer, v_nombre_subcuenta character varying) OWNER TO postgres;

--
-- Name: fcn_compras_anular(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_compras_anular(psecuencia_enc bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE f record;
declare venmano numeric;
declare vvalorenmano numeric;
declare vid_centro_costo integer;
begin
	select id_centro_costo into vid_centro_costo from public.tbl_compras_enc where secuencia_enc = psecuencia_enc;
	
	
		for f in select 	b.id_centro_costo,
							a.id_articulo,
							a.cantidad,
							a.precio_unit
					from 		public.tbl_compras_det a 
					inner join 	public.tbl_compras_enc b on b.secuencia_enc=a.secuencia_enc
					where		b.secuencia_enc = psecuencia_enc
					and			b.estado='1'
			loop
				select en_mano into venmano from public.tbl_articulo_bodega where id_centro_costo=f.id_centro_costo and id_articulo=f.id_articulo;
				if (venmano-f.cantidad)=0 then
					update		public.tbl_articulo_bodega set
					en_mano=en_mano-f.cantidad,
					precio=0
					where id_centro_costo=f.id_centro_costo
					and id_articulo=f.id_articulo;
				else
					update		public.tbl_articulo_bodega set
					en_mano=en_mano-f.cantidad,
					precio=((en_mano*precio)-(f.cantidad*f.precio_unit))/(en_mano-f.cantidad)
					where id_centro_costo=f.id_centro_costo
					and id_articulo=f.id_articulo;
				end if;
			end loop;
			
			update public.tbl_compras_enc set estado='2' where secuencia_enc=psecuencia_enc and estado='1';
end;	
$$;


ALTER FUNCTION public.fcn_compras_anular(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: fcn_compras_enca_insert(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_compras_enca_insert(pcompras json) RETURNS json
    LANGUAGE plpgsql
    AS $$
declare vcompras json;
declare vsecuencia_enc bigint = nextval('contabilidad.tbl_libro_diario_id_libro_diario_seq'::regclass);
begin

--INSERTA ENCABEZADO
insert into public.tbl_compras_enc(
	secuencia_enc  ,
    id_socio_negocio ,
    fecha ,
    referencia  ,
    monto_total ,
    monto_impuesto_total ,
    creado_por  ,
    fecha_creacion ,
    modificado_por  ,
    fecha_modificacion ,
    id_usuario ,
    id_centro_costo 
    
	) 

select 		vsecuencia_enc ,
			r.id_socio_negocio,
			r.fecha,
			r.referencia,
			r.monto_total,
			r.monto_impuesto_total,
			r.creado_por,
			r.fecha_creacion,
			r.modificado_por,
			r.fecha_modificacion,
			r.id_usuario,
			r.id_centro_costo
from 		json_populate_record(null::public.ty_encabezado_compras,pcompras::json) as r ;

--INSERTA DETALLE
insert into tbl_compras_det(
	secuencia_enc ,
	id_articulo ,
	id_unidad_medida ,
	cantidad ,
	precio_unit ,
	id_impuesto ,
	monto_impuesto ,
	monto_total  
	) 
select 		vsecuencia_enc,
			(d.detalle ->'id_articulo')::text::int as id_articulo,
			(d.detalle ->'id_unidad_medida')::text::int as id_unidad_medida,
			(d.detalle ->'cantidad')::text::int as cantidad,
			(d.detalle ->'precio_unit')::text::numeric as precio_unit,
			(d.detalle ->'id_impuesto')::text::int as id_impuesto,
			(d.detalle ->'monto_impuesto')::text::numeric as monto_impuesto,
			(d.detalle ->'monto_total')::text::numeric as monto_total
from 		json_populate_record(null::public.ty_encabezado_compras,pcompras::json)
cross join 	json_array_elements( pcompras::json -> 'detalle') as d(detalle)	;

select public.ft_json_compras(vsecuencia_enc) into vcompras;
return vcompras;
end;	
$$;


ALTER FUNCTION public.fcn_compras_enca_insert(pcompras json) OWNER TO postgres;

--
-- Name: fcn_event_bitacora(timestamp without time zone, character varying, integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_event_bitacora(pfecha timestamp without time zone, pid_usuario character varying, pid_objeto integer, paccion character varying, pdescripcin character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

begin
	insert into seguridad.tbl_ms_bitacora(
		fecha,
		id_usuario,
		id_objeto,
		accion,
		descripcion
	)
	values(
		pfecha,
		pid_usuario,
		pid_objeto,
		paccion,
		pdescripcion
	);
	
end;
$$;


ALTER FUNCTION public.fcn_event_bitacora(pfecha timestamp without time zone, pid_usuario character varying, pid_objeto integer, paccion character varying, pdescripcin character varying) OWNER TO postgres;

--
-- Name: fcn_socio_negocio_insert_por_rtn(character varying, character varying, character varying, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_socio_negocio_insert_por_rtn(pdescripcion character varying, prtn character varying, pcreado_por character varying, pfecha_creacion timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare vcod varchar;

begin
	select 		coalesce(tipo,'C') ||coalesce(max(substr(cod_socio_negocio,2,5))::integer,0) + 1
	into 		vcod
	from 		public.tbl_socio_negocio
	where		tipo='C'
	group by 	tipo;
	insert into tbl_socio_negocio (
				cod_socio_negocio,
				tipo,
				descripcion,
				contacto,
				rtn,
				activo,
				creado_por,
				fecha_creacion
			)
			values (
				 vcod,
				 'C',
				 pdescripcion,
				 pdescripcion,
				 prtn,
				 '1',
				 pcreado_por,
				 pfecha_creacion
			);
	
end;	
$$;


ALTER FUNCTION public.fcn_socio_negocio_insert_por_rtn(pdescripcion character varying, prtn character varying, pcreado_por character varying, pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: fcn_socio_negocio_update_por_rtn(character varying, character varying, character varying, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_socio_negocio_update_por_rtn(pdescripcion character varying, prtn character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare vcod varchar;

begin
		select 		cod_socio_negocio into vcod
		from 		public.tbl_socio_negocio
		where		tipo='C'
		and			rtn=prtn
		and			descripcion=pdescripcion
		limit 1;
	update tbl_socio_negocio set
				descripcion = pdescripcion,
				rtn = prtn,
				modificado_por = pmodificado_por,
				fecha_modificacion = pfecha_modificacion

			where cod_socio_negocio = vcod;
	
end;	
$$;


ALTER FUNCTION public.fcn_socio_negocio_update_por_rtn(pdescripcion character varying, prtn character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: fcn_tgr_actualiza_en_mano_compras(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_tgr_actualiza_en_mano_compras() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare vid_centro_costo integer;
declare vestado character;
declare venmano numeric;
declare vvalorenmano numeric;
begin
	select id_centro_costo into vid_centro_costo from public.tbl_compras_enc where secuencia_enc = new.secuencia_enc;
	select estado into vestado from public.tbl_compras_enc where secuencia_enc = new.secuencia_enc;
	select en_mano into venmano from public.tbl_articulo_bodega where id_centro_costo=vid_centro_costo and id_articulo=new.id_articulo;
	select en_mano*precio into vvalorenmano from public.tbl_articulo_bodega where id_centro_costo=vid_centro_costo and id_articulo=new.id_articulo;
	
	if vestado = '1' then
		update public.tbl_articulo_bodega set
		en_mano=en_mano+new.cantidad,
		precio=(vvalorenmano+(new.cantidad*new.precio_unit))/(venmano+new.cantidad)
		where id_centro_costo=vid_centro_costo
		and id_articulo=new.id_articulo;
	
	end if;
	RETURN NEW;
end;
$$;


ALTER FUNCTION public.fcn_tgr_actualiza_en_mano_compras() OWNER TO postgres;

--
-- Name: fcn_tgr_actualiza_en_mano_ventas(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_tgr_actualiza_en_mano_ventas() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE f record;
declare vid_centro_costo integer;
declare vestado character;
declare venmano numeric;
declare vvalorenmano numeric;
begin
select estado into vestado from public.tbl_venta_encabezado where secuencia_enc = new.secuencia_enc;
	for f in select d.id_centro_costo,
			c.id_articulo_hijo,
			c.cantidad
			from public.tbl_venta_encabezado a
						inner join public.tbl_venta_detalle b on b.secuencia_enc = a.secuencia_enc
						inner join public.tbl_lista_materiales c on c.id_articulo_padre=b.id_articulo
						inner join public.tbl_sucursal d on d.id_sucursal = a.id_sucursal
						where a.secuencia_enc = new.secuencia_enc
	loop
		if vestado = '1' then
			update public.tbl_articulo_bodega set
			en_mano=en_mano-f.cantidad
			where id_centro_costo=f.id_centro_costo
			and id_articulo=f.id_articulo_hijo;

		end if;
	end loop;
	RETURN NEW;
end;
$$;


ALTER FUNCTION public.fcn_tgr_actualiza_en_mano_ventas() OWNER TO postgres;

--
-- Name: fcn_tgr_articulo_bodega_new_insert(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_tgr_articulo_bodega_new_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

DECLARE f record;

begin
	if new.tipo = 'I' then
		for f in select 	id_centro_costo
				from 		public.tbl_centro_costo 
		loop
			call public.prc_articulo_bodega_new_insert(f.id_centro_costo,new.id_articulo,new.inventario_maximo,new.inventario_minimo);
		end loop;
	end if;
	RETURN NEW;
end;
$$;


ALTER FUNCTION public.fcn_tgr_articulo_bodega_new_insert() OWNER TO postgres;

--
-- Name: fcn_update_password(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_update_password() RETURNS trigger
    LANGUAGE plpgsql
    AS $$


DECLARE vHist integer;
DECLARE vHistDel integer;

begin
	select count(*) into vHist from tbl_ms_hist_constrasena where old.id_usuario=1;

	
	if vHist = 10 then
		select min(id_hist) into vHistDel from tbl_ms_hist_constrasena where old.id_usuario=1;
		delete from TBL_MS_HIST_CONSTRASENA where old.id_usuario=1 and ID_HIST=vHistDel;
	end if;
	if new.contrasena <> old.contrasena then
		insert into TBL_MS_HIST_CONSTRASENA(id_usuario, contrasena) values(old.id_usuario, old.CONTRASENA);
	end if;
	RETURN NEW;
end;
$$;


ALTER FUNCTION public.fcn_update_password() OWNER TO postgres;

--
-- Name: fcn_venta_enca_insert(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_venta_enca_insert(pventa json) RETURNS json
    LANGUAGE plpgsql
    AS $$
declare vventa json;
declare vsecuencia_enc bigint;
declare vno_factura  varchar;
declare vid_pos integer;
declare vcorrelativo integer;
declare vcai varchar;
declare vfecha_limite date;
begin
select 		r.secuencia_enc into vsecuencia_enc from 		json_populate_record(null::ty_encabezado_factura,pventa::json) as r;
select 		r.id_pos into vid_pos from 		json_populate_record(null::ty_encabezado_factura,pventa::json) as r;
select a.sucursal_sar||'-'||a.terminal_sar||'-'||a.tipo_documento_sar||'-'||LPAD(a.correlativo_actual::character, 8, '0') into vno_factura from public.tbl_correlativo a where id_pos=vid_pos and activo='1';
select a.correlativo_actual into vcorrelativo from public.tbl_correlativo a where id_pos=vid_pos and activo='1';
select a.cai into vcai from public.tbl_correlativo a where id_pos=vid_pos and activo='1';
select a.fecha_vencimiento into vfecha_limite from public.tbl_correlativo a where id_pos=vid_pos and activo='1';

--INSERTA ENCABEZADO
insert into public.tbl_venta_encabezado(
	secuencia_enc,
	id_sucursal ,
	cod_sucursal ,
	fecha ,
	numero_cuenta ,
	venta_grabada_15 ,
	venta_grabada_18 ,
	venta_exenta ,
	impuesto_15 ,
	impuesto_18 ,
	venta_total ,
	cai ,
	correlativo ,
	rtn ,
	nombre_cliente ,
	id_usuario,
	id_pos,
	no_factura,
	fecha_limite_emision
	) 

select 		r.secuencia_enc ,
			r.id_sucursal,
			r.cod_sucursal,
			r.fecha,
			r.numero_cuenta,
			r.venta_grabada_15,
			r.venta_grabada_18,
			r.venta_exenta,
			r.impuesto_15,
			r.impuesto_18,
			r.venta_total,
			vcai,
			vcorrelativo,
			r.rtn,
			r.nombre_cliente,
			r.id_usuario,
			r.id_pos,
			vno_factura,
			vfecha_limite
			
			
from 		json_populate_record(null::ty_encabezado_factura,pventa::json) as r ;

--INSERTA DETALLE
insert into tbl_venta_detalle(
	secuencia_det,
	secuencia_enc ,
	id_articulo ,
	id_modo_pedido ,
	precio ,
	cantidad ,
	id_impuesto ,
	total_impuesto ,
	total  
	) 
select 		(d.detalle ->'secuencia_det')::text::bigint as secuencia_det,
			(d.detalle ->'secuencia_enc')::text::bigint as secuencia_enc,
			(d.detalle ->'id_articulo')::text::int as id_articulo,
			(d.detalle ->'id_modo_pedido')::text::int as id_modo_pedido,
			(d.detalle ->'precio')::text::numeric as precio,
			(d.detalle ->'cantidad')::text::int as cantidad,
			(d.detalle ->'id_impuesto')::text::int as id_impuesto,
			(d.detalle ->'total_impuesto')::text::numeric as total_impuesto,
			(d.detalle ->'total')::text::numeric as total
from 		json_populate_record(null::ty_encabezado_factura,pventa::json)
cross join 	json_array_elements( pventa::json -> 'detalle') as d(detalle)	;

--INSERTA DETALLE DE PAGO
insert into tbl_venta_detalle_pago(
	secuencia_enc ,
	id_metodo_pago ,
	monto 
	)
select 		(d.detalle_pago ->'secuencia_enc')::text::bigint as secuencia_enc,
			(d.detalle_pago ->'id_metodo_pago')::text::int as id_metodo_pago,
			(d.detalle_pago ->'monto')::text::numeric as monto
from 		json_populate_record(null::ty_encabezado_factura,pventa::json)
cross join 	json_array_elements( pventa::json -> 'detalle_pago') as d(detalle_pago);

--INSERTA DETALLE DE PROMOS
insert into tbl_venta_detalle_promo(
	secuencia_det ,
	id_articulo ,
	id_promo 
	) 
select 		(d.detalle_promo ->'secuencia_det')::text::bigint as secuencia_det,
			(d.detalle_promo ->'id_articulo')::text::int as id_articulo,
			(d.detalle_promo ->'id_promo')::text::int as id_promo
from 		json_populate_record(null::ty_encabezado_factura,pventa::json)
cross join 	json_array_elements( pventa::json -> 'detalle_promo') as d(detalle_promo);	

--INSERTA DETALLE DE DESCUENTOS
insert into tbl_venta_detalle_desc(
	secuencia_det ,
	id_articulo ,
	id_descuento ,
	monto 
	) 
select 		(d.detalle_desc ->'secuencia_det')::text::bigint as secuencia_det,
			(d.detalle_desc ->'id_articulo')::text::int as id_articulo,
			(d.detalle_desc ->'id_descuento')::text::int as id_descuento,
			(d.detalle_desc ->'monto')::text::numeric as monto
from 		json_populate_record(null::ty_encabezado_factura,pventa::json)
cross join 	json_array_elements( pventa::json -> 'detalle_desc') as d(detalle_desc);	
select public.ft_json_venta(vsecuencia_enc) into vventa;
update public.tbl_correlativo set correlativo_actual=correlativo_actual+1 where id_pos=vid_pos and activo='1';
return vventa;
end;	
$$;


ALTER FUNCTION public.fcn_venta_enca_insert(pventa json) OWNER TO postgres;

--
-- Name: fcn_ventas_anular(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fcn_ventas_anular(psecuencia_enc bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE f record;
declare vid_centro_costo integer;
begin
	select b.id_centro_costo into vid_centro_costo from public.tbl_venta_encabezado a
						inner join public.tbl_sucursal b on b.id_sucursal = a.id_sucursal
						where a.secuencia_enc = psecuencia_enc;
	
	
		for f in select d.id_centro_costo,
						c.id_articulo_hijo,
						c.cantidad
						from public.tbl_venta_encabezado a
						inner join public.tbl_venta_detalle b on b.secuencia_enc = a.secuencia_enc
						inner join public.tbl_lista_materiales c on c.id_articulo_padre=b.id_articulo
						inner join public.tbl_sucursal d on d.id_sucursal = a.id_sucursal
						where a.secuencia_enc = psecuencia_enc
						and			a.estado='1'
			loop
				update		public.tbl_articulo_bodega set
							en_mano=en_mano+f.cantidad
							where id_centro_costo=f.id_centro_costo
							and id_articulo=f.id_articulo_hijo;
			end loop;
			
			update public.tbl_venta_encabezado set estado='2' where secuencia_enc=psecuencia_enc and estado='1';
end;	
$$;


ALTER FUNCTION public.fcn_ventas_anular(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_articulo_getall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_articulo_getall() RETURNS TABLE(id_articulo integer, cod_articulo character varying, tipo character, descripcion_articulo character varying, descripcion_corta character varying, id_impuesto integer, cod_impuesto integer, descripcion_impuesto character varying, id_categoria integer, cod_categoria integer, descripcion_categoria character varying, precio numeric, inventario_minimo numeric, inventario_maximo numeric, codigo_barra character varying, id_unidad_medida integer, cod_unidad_medida character varying, descripcion_unidad_medida character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_articulo
			,a.cod_articulo
			,a.tipo
			,a.descripcion descripcion_articulo
			,a.descripcion_corta
			,a.id_impuesto
			,b.cod_impuesto
			,b.descripcion descripcion_impuesto
			,a.id_categoria
			,c.cod_categoria
			,c.descripcion descripcion_categoria
			,a.precio
			,a.inventario_minimo
			,a.inventario_maximo
			,a.codigo_barra
			,a.id_unidad_medida
			,g.cod_unidad_medida
			,g.descripcion descripcion_unidad_medida
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_articulo a	
left join	tbl_impuesto b on a.id_impuesto=b.id_impuesto
left join	tbl_categoria c on a.id_categoria=c.id_categoria

left join 	tbl_unidades_medida g on a.id_unidad_medida=g.id_unidad_medida 
;

END;
$$;


ALTER FUNCTION public.ft_articulo_getall() OWNER TO postgres;

--
-- Name: ft_articulo_getone(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_articulo_getone(pcod_articulo character varying DEFAULT 0) RETURNS TABLE(id_articulo integer, cod_articulo character varying, tipo character, descripcion_articulo character varying, descripcion_corta character varying, id_impuesto integer, cod_impuesto integer, descripcion_impuesto character varying, id_categoria integer, cod_categoria integer, descripcion_categoria character varying, precio numeric, inventario_minimo numeric, inventario_maximo numeric, codigo_barra character varying, id_unidad_medida integer, cod_unidad_medida character varying, descripcion_unidad_medida character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_articulo
			,a.cod_articulo
			,a.tipo
			,a.descripcion descripcion_articulo
			,a.descripcion_corta
			,a.id_impuesto
			,b.cod_impuesto
			,b.descripcion descripcion_impuesto
			,a.id_categoria
			,c.cod_categoria
			,c.descripcion descripcion_categoria
			,a.precio
			,a.inventario_minimo
			,a.inventario_maximo
			,a.codigo_barra
			,a.id_unidad_medida
			,g.cod_unidad_medida
			,g.descripcion descripcion_unidad_medida
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_articulo a	
left join	tbl_impuesto b on a.id_impuesto=b.id_impuesto
left join	tbl_categoria c on a.id_categoria=c.id_categoria

left join 	tbl_unidades_medida g on a.id_unidad_medida=g.id_unidad_medida 
where		a.cod_articulo=pcod_articulo;

END;
$$;


ALTER FUNCTION public.ft_articulo_getone(pcod_articulo character varying) OWNER TO postgres;

--
-- Name: ft_articulo_movimientos(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_articulo_movimientos(pid_centro_costo integer, pid_articulo integer) RETURNS TABLE(fecha date, tipo character varying, cantidad numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
	select 		a.fecha
			,'COMPRA' tipo
			,b.cantidad
from		public.tbl_compras_enc a
inner join	public.tbl_compras_det b on a.secuencia_enc = b.secuencia_enc
where		A.ID_CENTRO_COSTO=pid_centro_costo
AND			a.FECHA BETWEEN NOW() - INTERVAL '60 DAYS' AND NOW()
AND			b.id_articulo=pid_articulo
union 		all
select		a.fecha
			,case a.tipo
			when '1' then 'CONSUMO'
			WHEN '2' THEN 'SALIDA'
			WHEN '3' THEN 'ENTRADAS'
			END::varchar TIPO
			,B.CANTIDAD
from		public.tbl_movimiento_enc A
INNER JOIN	public.tbl_movimiento_det B ON A.SECUENCIA_ENC=B.SECUENCIA_ENC
WHERE		A.ID_CENTRO_COSTO=pid_centro_costo
AND			a.FECHA BETWEEN NOW() - INTERVAL '60 DAYS' AND NOW()
AND			B.ID_ARTICULO=pid_articulo;

END;
$$;


ALTER FUNCTION public.ft_articulo_movimientos(pid_centro_costo integer, pid_articulo integer) OWNER TO postgres;

--
-- Name: ft_articulo_por_bodega_getall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_articulo_por_bodega_getall() RETURNS TABLE(id_centro_costo integer, cod_centro_costo character varying, descripcion_centro_costo character varying, id_articulo integer, cod_articulo character varying, descripcion_articulo character varying, en_mano numeric, inventario_minimo numeric, inventario_maximo numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
	select 		a.id_centro_costo
				,c.cod_centro_costo
				,c.descripcion descripcion_centro_costo
				,a.id_articulo
				,b.cod_articulo
				,b.descripcion descripcion_articulo
				,a.en_mano
				,b.inventario_minimo
				,b.inventario_maximo
	from 		public.tbl_articulo_bodega a
	inner join 	public.tbl_articulo b on a.id_articulo=b.id_articulo
	inner join 	public.tbl_centro_costo c on a.id_centro_costo=c.id_centro_costo;

END;
$$;


ALTER FUNCTION public.ft_articulo_por_bodega_getall() OWNER TO postgres;

--
-- Name: ft_bitacora_getallbydate(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_bitacora_getallbydate(pfecha_inical date, pfecha_final date) RETURNS TABLE(id_bitacora integer, fecha timestamp without time zone, id_usuario integer, usuario character varying, nombre_usuario character varying, id_objeto integer, objeto character varying, descripcion_objeto character varying, tipo_objeto character varying, accion character varying)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_bitacora
			,a.fecha
			,a.id_usuario
			,b.usuario
			,b.nombre_usuario
			,a.id_objeto
			,c.objeto
			,c.descripcion descripcion_objeto
			,c.tipo_objeto
			,a.accion
from 		seguridad.tbl_ms_bitacora a	
inner join	seguridad.tbl_ms_usuario b on a.id_usuario=b.id_usuario
inner join 	seguridad.tbl_ms_objetos c on a.id_objeto=c.id_objeto
where		cast(a.fecha as date) between  pfecha_inical and pfecha_final
;

END;
$$;


ALTER FUNCTION public.ft_bitacora_getallbydate(pfecha_inical date, pfecha_final date) OWNER TO postgres;

--
-- Name: ft_compras_por_fecha(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_compras_por_fecha(pfecha_inicial date, pfecha_final date) RETURNS TABLE(secuencia_enc bigint, id_socio_negocio integer, cod_socio_negocio character varying, descripcion_socio_negocio character varying, fecha date, referencia character varying, monto_total numeric, monto_impuesto_total numeric, creado_por character varying, fecha_creacion date, modificado_por character varying, fecha_modificacion date, id_usuario integer, usuario character varying, nombre_usuario character varying, id_centro_costo integer, cod_centro_costo character varying, descripcion_centro_costo character varying, estado character, descripcion_estado character varying)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
select		a.secuencia_enc ,
			a.id_socio_negocio ,
			b.cod_socio_negocio ,
			b.descripcion descripcion_socio_negocio,
			a.fecha ,
			a.referencia ,
			a.monto_total ,
			a.monto_impuesto_total ,
			a.creado_por ,
			a.fecha_creacion ,
			a.modificado_por ,
			a.fecha_modificacion ,
			a.id_usuario ,
			d.usuario,
			d.nombre_usuario,
			a.id_centro_costo ,
			e.cod_centro_costo,
			e.descripcion descripcion_centro_costo,
			a.estado,
			case a.estado
			when '1' then 'CERRADA'
			when '2' then 'ANULADA'
			when '3' then 'CONTABILIZDA'
			END::varchar descripcion_estado
from		public.tbl_compras_enc a
inner join	public.tbl_socio_negocio b ON b.id_socio_negocio = a.id_socio_negocio

inner join 	seguridad.tbl_ms_usuario d ON d.id_usuario = a.id_usuario
inner join 	public.tbl_centro_costo e ON e.id_centro_costo = a.id_centro_costo

where		a.fecha between pfecha_inicial and pfecha_final
;

END;
$$;


ALTER FUNCTION public.ft_compras_por_fecha(pfecha_inicial date, pfecha_final date) OWNER TO postgres;

--
-- Name: ft_conteo_inventario(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_conteo_inventario(pid_centro_costo integer) RETURNS TABLE(id_centro_costo integer, cod_centro_costo character varying, descripcion_centro_costo character varying, id_articulo integer, cod_articulo character varying, descripcion_articulo character varying, cod_unidad_medida character varying, en_mano numeric, fisico numeric, diferencia numeric, precio numeric, total numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
	select		a.id_centro_costo
			,b.cod_centro_costo cod_centro_costo
			,b.descripcion descripcion_centro_costo
			,a.id_articulo
			,c.cod_articulo
			,c.descripcion descripcion_articulo
			,d.cod_unidad_medida
			,a.en_mano
			,0 "fisico"
			,0 "diferencia"
			,a.precio
			,0 "total"
from		public.tbl_articulo_bodega a
inner join	public.tbl_centro_costo b on b.id_centro_costo = a.id_centro_costo
inner join	public.tbl_articulo c on c.id_articulo = a.id_articulo
inner join	public.tbl_unidades_medida d on d.id_unidad_medida = c.id_unidad_medida
where		a.id_centro_costo=pid_centro_costo
				;

END;
$$;


ALTER FUNCTION public.ft_conteo_inventario(pid_centro_costo integer) OWNER TO postgres;

--
-- Name: ft_correlativo_getall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_correlativo_getall() RETURNS TABLE(id_correlativo integer, id_pos integer, cod_pos character varying, descripcion_pos character varying, cai character varying, sucursal_sar character varying, terminal_sar character varying, tipo_documento_sar character varying, correlativo_inicial integer, correlativo_final integer, correlativo_actual integer, fecha_vencimiento character varying, activo character, siguiente character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_correlativo
			,a.id_pos 
			,b.cod_pos
			,b.descripcion descripcion_pos
			,a.cai
			,a.sucursal_sar
			,a.terminal_sar
			,a.tipo_documento_sar
			,a.correlativo_inicial
			,a.correlativo_final
			,a.correlativo_actual
			,a.fecha_vencimiento::varchar
			,a.activo
			,a.siguiente
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_correlativo a	
left join	tbl_pos b on a.id_pos=b.id_pos
;

END;
$$;


ALTER FUNCTION public.ft_correlativo_getall() OWNER TO postgres;

--
-- Name: ft_correlativo_getone(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_correlativo_getone(pid_correlativo integer DEFAULT 0) RETURNS TABLE(id_correlativo integer, id_pos integer, cod_pos character varying, descripcion_pos character varying, cai character varying, sucursal_sar character varying, terminal_sar character varying, tipo_documento_sar character varying, correlativo_inicial integer, correlativo_final integer, correlativo_actual integer, fecha_vencimiento date, activo character, siguiente character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_correlativo
			,a.id_pos 
			,b.cod_pos
			,b.descripcion descripcion_pos
			,a.cai
			,a.sucursal_sar
			,a.terminal_sar
			,a.tipo_documento_sar
			,a.correlativo_inicial
			,a.correlativo_final
			,a.correlativo_actual
			,a.fecha_vencimiento
			,a.activo
			,a.siguiente
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_correlativo a	
left join	tbl_pos b on a.id_pos=b.id_pos
where		a.id_correlativo = pid_correlativo
;

END;
$$;


ALTER FUNCTION public.ft_correlativo_getone(pid_correlativo integer) OWNER TO postgres;

--
-- Name: ft_facturas_por_fecha(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_facturas_por_fecha(pfecha_inicial date, pfecha_final date) RETURNS TABLE(secuencia_enc bigint, id_sucursal integer, cod_sucursal character varying, fecha date, numero_cuenta integer, venta_grabada_15 numeric, venta_grabada_18 numeric, venta_exenta numeric, impuesto_15 numeric, impuesto_18 numeric, venta_total numeric, cai character varying, correlativo integer, rtn character varying, nombre_cliente character varying, id_usuario integer, usuario character varying, nombre_usuario character varying, id_pos integer, cod_pos character varying, descripcion_pos character varying, estado character, descripcion_estado character varying)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
select		a.secuencia_enc ,
			a.id_sucursal ,
			a.cod_sucursal ,
			a.fecha ,
			a.numero_cuenta ,
			a.venta_grabada_15 ,
			a.venta_grabada_18 ,
			a.venta_exenta ,
			a.impuesto_15 ,
			a.impuesto_18 ,
			a.venta_total ,
			a.cai ,
			a.correlativo ,
			a.rtn ,
			a.nombre_cliente ,
			a.id_usuario,
			b.usuario,
			b.nombre_usuario,
			a.id_pos,
			c.cod_pos,
			c.descripcion descripcion_pos,
			a.estado,
			case a.estado
			when '1' then 'CERRADA'
			when '2' then 'ANULADA'
			when '3' then 'CONTABILIZDA'
			END::varchar descripcion_estado
from		public.tbl_venta_encabezado a
inner join	seguridad.tbl_ms_usuario b on a.id_usuario=b.id_usuario
inner join  public.tbl_pos c ON c.id_pos = a.id_pos
where		a.fecha between pfecha_inicial and pfecha_final
;

END;
$$;


ALTER FUNCTION public.ft_facturas_por_fecha(pfecha_inicial date, pfecha_final date) OWNER TO postgres;

--
-- Name: ft_json_arqueo(integer, date, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_arqueo(pid_sucursal integer, pfecha date, pid_usuario integer, pid_pos integer) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_arqueo json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_arqueo result
from (
    select 
        jsonb_build_object(
			'fecha',s.fecha	
           	,'id_subcuenta',s.id_subcuenta
			,'descripcion_cuenta',s.descripcion_cuenta
			,'monto_debe',s.monto_debe
			,'monto_haber',s.monto_haber
        ) js_object
    from (			
			select 		a.fecha
						,1 "id_subcuenta"
						,'CAJA' "descripcion_cuenta"
						,COALESCE(sum(a.venta_total),0) "monto_debe"
						,0 "monto_haber"
			from 		public.tbl_venta_encabezado a
			inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
			inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			and			c.tipo='E'
			group by	a.fecha
			union all
			select 		a.fecha
						,17 "id_subcuenta"
						,'DESCUENTOS SOBRE VENTAS' "descripcion_cuenta"
						,COALESCE(sum(c.monto),0) "monto_debe"
						,0 "monto_haber"
			from 		public.tbl_venta_encabezado a
			inner join	public.tbl_venta_detalle b on a.secuencia_enc = b.secuencia_enc
			inner join	public.tbl_venta_detalle_desc c on b.secuencia_det = c.secuencia_det
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			group by	a.fecha
			union all
			select 		a.fecha
						,2 "id_subcuenta"
						,'CLIENTES' "descripcion_cuenta"
						,COALESCE(sum(a.venta_total),0) "monto_debe"
						,0 "monto_haber"
			from 		public.tbl_venta_encabezado a
			inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
			inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			and			c.tipo='C'
			group by	a.fecha
			union all
			select 		a.fecha
						,46 "id_subcuenta"
						,'CUENTAS POR COBRAR TARJETA CREDITO' "descripcion_cuenta"
						,COALESCE(sum(a.venta_total),0) "monto_debe"
						,0 "monto_haber"
			from 		public.tbl_venta_encabezado a
			inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
			inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			and			c.tipo='T'
			group by	a.fecha
			union all
			select 		a.fecha
						,11 "id_subcuenta"
						,'VENTAS' "descripcion_cuenta"
						,0 "monto_debe"
						,sum(a.venta_GRABADA_15+A.VENTA_GRABADA_18+A.VENTA_EXENTA)*-1 "monto_haber"
			from 		public.tbl_venta_encabezado a
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			group by	a.fecha
			union all
			select 		a.fecha
						,11 "id_subcuenta"
						,'VENTAS (DESCUENTOS)' "descripcion_cuenta"
						,0 "monto_debe"
						,COALESCE(sum(c.monto),0)*-1 "monto_haber"
			from 		public.tbl_venta_encabezado a
			inner join	public.tbl_venta_detalle b on a.secuencia_enc = b.secuencia_enc
			inner join	public.tbl_venta_detalle_desc c on b.secuencia_det = c.secuencia_det
			where		a.id_sucursal=pid_sucursal
			and			a.fecha=pfecha
			and			a.id_usuario=pid_usuario
			and			a.id_pos=pid_pos
			group by	a.fecha
			UNION ALL
			select 		a.fecha
						,6 "id_subcuenta"
						,'IMPUESTOS POR PAGAR' "descripcion_cuenta"
						,0 "monto_debe"
						,COALESCE(sum(a.IMPUESTO_15+A.IMPUESTO_18),0)*-1 "monto_haber"
			from 		public.tbl_venta_encabezado a
			group by	a.fecha
			union all
			select		pfecha
						,48 "sub_cuenta"
						,'SOBRANTE DE CAJA' "descripcion_cuenta"
						,0 "monto_debe"
						,0 "monto_haber"
			union all
			select		pfecha
						,47 "sub_cuenta"
						,'FALTANTE DE CAJA' "descripcion_cuenta"
						,0 "monto_debe"
						,0 "monto_haber"
			union all
			select		pfecha
						,49 "sub_cuenta"
						,'CUENTAS POR COBRAR EMPLEADOS' "descripcion_cuenta"
						,0 "monto_debe"
						,0 "monto_haber"
			) s

	
    ) s;
return json_arqueo;
END;
$$;


ALTER FUNCTION public.ft_json_arqueo(pid_sucursal integer, pfecha date, pid_usuario integer, pid_pos integer) OWNER TO postgres;

--
-- Name: ft_json_compras(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_compras(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_compras json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_compras result
from (
    select 
        jsonb_build_object(
            'secuencia_enc', a.secuencia_enc, 
			'id_socio_negocio', a.id_socio_negocio, 
			'cod_socio_negocio',b.cod_socio_negocio ,
			'descripcion_socio_negocio',b.descripcion ,
            'fecha',a.fecha,
			'referencia',a.referencia ,
			'monto_total',a.monto_total ,
			'monto_impuesto_total',a.monto_impuesto_total ,
			'creado_por',a.creado_por ,
			'fecha_creacion',a.fecha_creacion ,
			'modificado_por',a.modificado_por ,
			'fecha_modificacion',a.fecha_modificacion ,
			'id_usuario',a.id_usuario,
			'usuario',d.usuario,
			'nombre_usuario',d.nombre_usuario,
			'id_centro_costo',a.id_centro_costo,
			'cod_centro_costo',e.cod_centro_costo,
			'descripcion_centro_costo',e.descripcion ,
			'estado',a.estado,
			'descripcion_estado',case a.estado
			when '1' then 'CERRADA'
			when '2' then 'ANULADA'
			when '3' then 'CONTABILIZDA'
			END::varchar ,
            'detalle', public.ft_json_compras_detalle(a.secuencia_enc)
        ) js_object
    from		public.tbl_compras_enc a
inner join	public.tbl_socio_negocio b ON b.id_socio_negocio = a.id_socio_negocio
inner join 	public.tbl_compras_det c ON c.secuencia_enc = a.secuencia_enc
inner join 	seguridad.tbl_ms_usuario d ON d.id_usuario = a.id_usuario
inner join 	public.tbl_centro_costo e ON e.id_centro_costo = a.id_centro_costo

	where a.secuencia_enc=psecuencia_enc
    group by a.secuencia_enc, 
			a.id_socio_negocio, 
			b.cod_socio_negocio ,
			b.descripcion ,
            a.fecha,
			a.referencia ,
			a.monto_total ,
			a.monto_impuesto_total ,
			a.creado_por ,
			a.fecha_creacion ,
			a.modificado_por ,
			a.fecha_modificacion ,
			a.id_usuario,
			d.usuario,
			d.nombre_usuario,
			a.id_centro_costo,
			e.cod_centro_costo,
			e.descripcion ,
			a.estado,
			case a.estado
			when '1' then 'CERRADA'
			when '2' then 'ANULADA'
			when '3' then 'CONTABILIZDA'
			END::varchar
    ) s;
return json_compras;
END;
$$;


ALTER FUNCTION public.ft_json_compras(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_compras_asiento(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_compras_asiento(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_compras_asiento json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_compras_asiento result
from (
    select 
        jsonb_build_object(
           'id_subcuenta',s.id_subcuenta
			,'descripcion_cuenta',s.descripcion_cuenta
			,'monto_debe',s.monto_debe
			,'monto_haber',s.monto_haber
        ) js_object
    from (			
						select 		a.fecha
						,50 "id_subcuenta"
						,'INVENTARIO' "descripcion_cuenta"
						,COALESCE(sum(a.monto_total-a.monto_impuesto_total),0) "monto_debe"
						,0 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		secuencia_enc = 2
			group by	a.fecha
			union all
			select 		a.fecha
						,51 "id_subcuenta"
						,'IMPUESTOS POR COBRAR' "descripcion_cuenta"
						,COALESCE(sum(a.monto_impuesto_total),0) "monto_debe"
						,0 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		a.secuencia_enc = 2
			group by	a.fecha
			union all
			select 		a.fecha
						,1 "id_subcuenta"
						,'CAJA' "descripcion_cuenta"
						,0 "monto_debe"
						,COALESCE(sum(a.monto_total),0)*-1 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		a.secuencia_enc = 2
			group by	a.fecha
			) s

	
    ) s;
return json_compras_asiento;
END;
$$;


ALTER FUNCTION public.ft_json_compras_asiento(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_compras_asiento_anular(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_compras_asiento_anular(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_compras_asiento json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_compras_asiento result
from (
    select 
        jsonb_build_object(
           'id_subcuenta',s.id_subcuenta
			,'descripcion_cuenta',s.descripcion_cuenta
			,'monto_debe',s.monto_debe
			,'monto_haber',s.monto_haber
        ) js_object
    from (			
						select 		a.fecha
						,52 "id_subcuenta"
						,'INVENTARIO' "descripcion_cuenta"
						,COALESCE(sum(a.monto_total-a.monto_impuesto_total),0) "monto_debe"
						,0 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		secuencia_enc = 2
			group by	a.fecha
			union all
			select 		a.fecha
						,50 "id_subcuenta"
						,'IMPUESTOS POR COBRAR' "descripcion_cuenta"
						,COALESCE(sum(a.monto_impuesto_total),0) "monto_debe"
						,0 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		a.secuencia_enc = 2
			group by	a.fecha
			union all
			select 		a.fecha
						,1 "id_subcuenta"
						,'CAJA' "descripcion_cuenta"
						,0 "monto_debe"
						,COALESCE(sum(a.monto_total),0)*-1 "monto_haber"
						
			from 		public.tbl_compras_enc a
			where		a.secuencia_enc = 2
			group by	a.fecha
			) s

	
    ) s;
return json_compras_asiento;
END;
$$;


ALTER FUNCTION public.ft_json_compras_asiento_anular(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_compras_detalle(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_compras_detalle(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_compras_detalle json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle)) into json_compras_detalle result
from (
select 
           jsonb_build_object(
					'secuencia_det', d.secuencia_det, 
					'secuencia_enc', d.secuencia_enc, 
					'id_articulo', d.id_articulo, 
			   		'cod_articulo', f.cod_articulo,
			   		'descripcion_articulo',f.descripcion,
					'id_unidad_medida', d.id_unidad_medida,
			   		'cod_unidad_medida',g.cod_unidad_medida,
			   		'descripcion_unidad_medida',g.descripcion,
			   		'cantidad', d.cantidad,
			   		'precio_unit', d.precio_unit,
			   		'id_impuesto',d.id_impuesto,
			   		'cod_impuesto',h.cod_impuesto,
			   		'descripcion_impuesto',h.descripcion,
			   		'monto_impuesto', d.monto_impuesto,
			   		'monto_total', d.monto_total
					
				) detalle
        from public.tbl_compras_enc e
        inner join public.tbl_compras_det d on d.secuencia_enc = e.secuencia_enc
		inner join public.tbl_articulo f ON f.id_articulo = d.id_articulo
		inner join public.tbl_impuesto h on h.id_impuesto = f.id_impuesto
		inner join public.tbl_unidades_medida g ON g.id_unidad_medida = d.id_unidad_medida
		where e.secuencia_enc=psecuencia_enc)a;
return json_compras_detalle;
END;
$$;


ALTER FUNCTION public.ft_json_compras_detalle(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_rango(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_rango(pid_pos integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

DECLARE
vrango varchar;
BEGIN

select 
           a.sucursal_sar||'-'||a.terminal_sar||'-'||a.tipo_documento_sar||'-'||LPAD(a.correlativo_inicial::varchar, 8, '0')||' al ' ||a.sucursal_sar||'-'||a.terminal_sar||'-'||a.tipo_documento_sar||'-'||LPAD(a.correlativo_final::varchar, 8, '0')
			into vrango					
					
			
        from public.tbl_correlativo a where id_pos=pid_pos and activo='1';
return vrango;
END;

$$;


ALTER FUNCTION public.ft_json_rango(pid_pos integer) OWNER TO postgres;

--
-- Name: ft_json_venta(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_venta(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_venta json;
BEGIN
select jsonb_pretty(jsonb_agg(js_object)) into json_venta result
from (
    select 
        jsonb_build_object(
            'secuencia_enc', s.secuencia_enc, 
			'id_sucursal', s.id_sucursal, 
            'cod_sucursal', s.cod_sucursal, 
			'fecha',s.fecha,
			'numero_cuenta',s.numero_cuenta ,
			'venta_grabada_15',s.venta_grabada_15 ,
			'venta_grabada_18',s.venta_grabada_18 ,
			'venta_exenta',s.venta_exenta ,
			'impuesto_15',s.impuesto_15 ,
			'impuesto_18',s.impuesto_18 ,
			'venta_total',s.venta_total ,
			'cai',s.cai ,
			'correlativo',s.correlativo ,
			'rtn',s.rtn ,
			'nombre_cliente',s.nombre_cliente ,
			'id_usuario',s.id_usuario,
			'usuario',b.usuario,
			'nombre_usuario',b.nombre_usuario,
			'id_pos',s.id_pos,
			'cod_pos',c.cod_pos,
			'descripcion_pos',c.descripcion ,
			'no_factura',s.no_factura,
			'fecha_limite_emision',s.fecha_limite_emision,
			'rango', public.ft_json_rango(s.id_pos),
			'estado',s.estado,
			'descripcion_estado',case s.estado
			when '1' then 'CERRADA'
			when '2' then 'ANULADA'
			when '3' then 'CONTABILIZDA'
			END::varchar,
            'detalle', public.ft_json_venta_detalle(s.secuencia_enc),
			'detalle_pago', public.ft_json_venta_detalle_pago(s.secuencia_enc),
			'detalle_promo', public.ft_json_venta_detalle_promo(s.secuencia_enc),
			'detalle_desc', public.ft_json_venta_detalle_desc(s.secuencia_enc)
        ) js_object
    from public.tbl_venta_encabezado s
	inner join	seguridad.tbl_ms_usuario b on s.id_usuario=b.id_usuario
	inner join  public.tbl_pos c ON c.id_pos = s.id_pos

	where s.secuencia_enc=psecuencia_enc
    group by s.secuencia_enc, 
	s.id_sucursal, 
	s.cod_sucursal,
	s.fecha,
	s.numero_cuenta ,
	s.venta_grabada_15 ,
	s.venta_grabada_18 ,
	s.venta_exenta ,
	s.impuesto_15 ,
	s.impuesto_18 ,
	s.venta_total ,
	s.cai ,
	s.correlativo ,
	s.rtn ,
	s.nombre_cliente ,
	s.id_usuario,
	b.usuario,
	b.nombre_usuario,
	s.id_pos,
	c.cod_pos,
	c.descripcion,
	s.no_factura,
	s.fecha_limite_emision,
	s.estado,
	case s.estado
	when '1' then 'CERRADA'
	when '2' then 'ANULADA'
	when '3' then 'CONTABILIZDA'
	END::varchar
    ) s;
return json_venta;
END;
$$;


ALTER FUNCTION public.ft_json_venta(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_venta_detalle(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_venta_detalle(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_venta_detalle json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle)) into json_venta_detalle result
from (
select 
           jsonb_build_object(
					'secuencia_det', d.secuencia_det, 
					'secuencia_enc', d.secuencia_enc, 
					'id_articulo', d.id_articulo, 
			   		'cod_articulo', f.cod_articulo,
			   		'descripcion_articulo',f.descripcion,
					'id_modo_pedido', d.id_modo_pedido,
			   		'cod_modo_pedido',g.cod_modo_pedido,
			   		'descripcion_modo_pedido',g.descripcion,
			   		'precio',d.precio,
			   		'cantidad', d.cantidad,
			   		'id_impuesto', d.id_impuesto,
			   		'cod_impuesto',h.cod_impuesto,
			   		'descripcion_impuesto',h.descripcion,
			   		'cod_descuento',j.cod_descuento,
			   		'descripcion_descuento',j.descripcion,
			   		'monto_descuento',i.monto,
			   		'total_impuesto', d.total_impuesto,
			   		'total', d.total
					
				) detalle
        from public.tbl_venta_encabezado e
        inner join public.tbl_venta_detalle d on d.secuencia_enc = e.secuencia_enc
		left join  public.tbl_venta_detalle_desc i on i.secuencia_det = d.secuencia_det
		left join  public.tbl_descuento j on i.id_descuento = j.id_descuento 
		inner join public.tbl_articulo f ON f.id_articulo = d.id_articulo
		inner join public.tbl_modo_pedido g on g.id_modo_pedido = d.id_modo_pedido
		inner join public.tbl_impuesto h on h.id_impuesto = f.id_impuesto
		where e.secuencia_enc=psecuencia_enc)a;
return json_venta_detalle;
END;

$$;


ALTER FUNCTION public.ft_json_venta_detalle(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_venta_detalle_desc(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_venta_detalle_desc(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_venta_detalle_desc json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle_desc)) into json_venta_detalle_desc result
from (
select 
           jsonb_build_object(
					'secuencia_det', f.secuencia_det, 
					'id_articulo', f.id_articulo, 
					'id_descuento', f.id_descuento,
			   		'monto', f.monto
					
				) detalle_desc
        from public.tbl_venta_encabezado e
        inner join public.tbl_venta_detalle d on d.secuencia_enc = e.secuencia_enc
		inner join public.tbl_venta_detalle_desc f on f.secuencia_det=d.secuencia_det
		where e.secuencia_enc=psecuencia_enc)a;
return json_venta_detalle_desc;
END;
$$;


ALTER FUNCTION public.ft_json_venta_detalle_desc(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_venta_detalle_pago(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_venta_detalle_pago(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_venta_detalle_pago json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle_pago)) into json_venta_detalle_pago result
from (
select 
           jsonb_build_object(
					'secuencia_pag', p.secuencia_pag, 
					'secuencia_enc', p.secuencia_enc, 
					'id_metodo_pago', p.id_metodo_pago, 
					'monto', p.monto
					
				) detalle_pago 
        from public.tbl_venta_encabezado e
        inner join public.tbl_venta_detalle_pago p on p.secuencia_enc = e.secuencia_enc
		where e.secuencia_enc=psecuencia_enc)a;
return json_venta_detalle_pago;
END;
$$;


ALTER FUNCTION public.ft_json_venta_detalle_pago(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_json_venta_detalle_promo(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_json_venta_detalle_promo(psecuencia_enc bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$

DECLARE
json_venta_detalle_promo json;
BEGIN
select jsonb_pretty(jsonb_agg(detalle_promo)) into json_venta_detalle_promo result
from (
select 
           jsonb_build_object(
					'secuencia_det', f.secuencia_det, 
					'id_articulo', f.id_articulo, 
					'id_promo', f.id_promo
					
				) detalle_promo
        from public.tbl_venta_encabezado e
        inner join public.tbl_venta_detalle d on d.secuencia_enc = e.secuencia_enc
		inner join public.tbl_venta_detalle_promo f on f.secuencia_det=d.secuencia_det
		where e.secuencia_enc=psecuencia_enc)a;
return json_venta_detalle_promo;
END;
$$;


ALTER FUNCTION public.ft_json_venta_detalle_promo(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_lista_materiales_getone(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_lista_materiales_getone(pid_id_articulo_padre integer DEFAULT 0, pid_id_articulo_hijo integer DEFAULT 0) RETURNS TABLE(id_articulo_padre integer, cod_articulo_padre character varying, descripcion_articulo_padre character varying, id_articulo_hijo integer, cod_articulo_hijo character varying, descripcion_articulo_hijo character varying, cantidad numeric, comentario character varying, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_articulo_padre
			,b.cod_articulo cod_articulo_padre
			,b.descripcion descripcion_articulo_padre
			,a.id_articulo_hijo
			,c.cod_articulo cod_articulo_hijo
			,c.descripcion descripcion_articulo_hijo
			,a.cantidad
			,a.comentario
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_lista_materiales a	
left join	tbl_articulo b on a.id_articulo_padre=b.id_articulo
left join	tbl_articulo c on a.id_articulo_hijo=c.id_articulo
where		a.id_articulo_padre = pid_id_articulo_padre
and			a.id_articulo_hijo = pid_id_articulo_hijo;

END;
$$;


ALTER FUNCTION public.ft_lista_materiales_getone(pid_id_articulo_padre integer, pid_id_articulo_hijo integer) OWNER TO postgres;

--
-- Name: ft_lista_materiales_padre_getall(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_lista_materiales_padre_getall(pid_id_articulo_padre integer DEFAULT 0) RETURNS TABLE(id_articulo_padre integer, cod_articulo_padre character varying, descripcion_articulo_padre character varying, id_articulo_hijo integer, cod_articulo_hijo character varying, descripcion_articulo_hijo character varying, cantidad numeric, comentario character varying, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_articulo_padre
			,b.cod_articulo cod_articulo_padre
			,b.descripcion descripcion_articulo_padre
			,a.id_articulo_hijo
			,c.cod_articulo cod_articulo_hijo
			,c.descripcion descripcion_articulo_hijo
			,a.cantidad
			,a.comentario
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_lista_materiales a	
left join	tbl_articulo b on a.id_articulo_padre=b.id_articulo
left join	tbl_articulo c on a.id_articulo_hijo=c.id_articulo
where		a.id_articulo_padre = pid_id_articulo_padre
;

END;
$$;


ALTER FUNCTION public.ft_lista_materiales_padre_getall(pid_id_articulo_padre integer) OWNER TO postgres;

--
-- Name: ft_monto_anuladas_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_anuladas_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		COALESCE(sum(a.venta_total),0) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.secuencia_enc=psecuencia_enc
	
	and			a.estado in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_anuladas_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_clientes_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_clientes_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		COALESCE(sum(b.monto),0) into v_monto
	from		public.tbl_venta_encabezado a
	inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
	inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
	where		a.secuencia_enc=psecuencia_enc
	and			a.estado not in ('2')
	and			c.tipo='C'
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_clientes_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_cuentas_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_cuentas_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		count(*) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.secuencia_enc=psecuencia_enc
	
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_cuentas_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_descuento_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_descuento_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(c.monto) into v_monto 
	from		public.tbl_venta_encabezado a
	inner join	public.tbl_venta_detalle b on a.secuencia_enc = b.secuencia_enc
	inner join	public.tbl_venta_detalle_desc c on b.secuencia_det = c.secuencia_det
	where		a.secuencia_enc=psecuencia_enc
	
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_descuento_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_efectivo_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_efectivo_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(b.monto) into v_monto
	from		public.tbl_venta_encabezado a
	inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
	inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
	where		a.secuencia_enc=psecuencia_enc
	and			a.estado not in ('2')
	and			c.tipo='E'
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_efectivo_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_impuestos_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_impuestos_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(a.impuesto_15+a.impuesto_18) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.secuencia_enc=psecuencia_enc
	
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_impuestos_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_tarjeta_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_tarjeta_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(b.monto) into v_monto
	from		public.tbl_venta_encabezado a
	inner join	public.tbl_venta_detalle_pago b on a.secuencia_enc = b.secuencia_enc
	inner join 	public.tbl_metodo_pago c on b.id_metodo_pago = c.id_metodo_pago
	where		a.secuencia_enc=psecuencia_enc
	and			a.estado not in ('2')
	and			c.tipo='T'
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_tarjeta_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_venta_actual_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_venta_actual_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(a.venta_total) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.secuencia_enc=psecuencia_enc
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_venta_actual_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_monto_venta_actual_resumen(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_venta_actual_resumen(pid_sucursal integer, pfecha date) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(a.venta_total) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.id_sucursal=pid_sucursal
	and			a.fecha=pfecha
	
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_venta_actual_resumen(pid_sucursal integer, pfecha date) OWNER TO postgres;

--
-- Name: ft_monto_venta_neta_resumen(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_monto_venta_neta_resumen(psecuencia_enc bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$

DECLARE
v_monto numeric;
BEGIN

	select		sum(a.venta_grabada_15+a.venta_grabada_18+a.venta_exenta) into v_monto
	from		public.tbl_venta_encabezado a
	where		a.secuencia_enc=psecuencia_enc
	and			a.estado not in ('2')
;
return v_monto;
END;
$$;


ALTER FUNCTION public.ft_monto_venta_neta_resumen(psecuencia_enc bigint) OWNER TO postgres;

--
-- Name: ft_pos_getall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_pos_getall() RETURNS TABLE(id_pos integer, cod_pos character varying, descripcion_pos character varying, id_sucursal integer, cod_sucursal character varying, descripcion_sucursal character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_pos
			,a.cod_pos
			,a.descripcion descripcion_pos
			,a.id_sucursal
			,b.cod_sucursal
			,b.descripcion descripcion_sucursal
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_pos a	
left join	tbl_sucursal b on a.id_sucursal=b.id_sucursal;

END;
$$;


ALTER FUNCTION public.ft_pos_getall() OWNER TO postgres;

--
-- Name: ft_pos_getone(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_pos_getone(pcod_pos character varying DEFAULT 0) RETURNS TABLE(id_pos integer, cod_pos character varying, descripcion_pos character varying, id_sucursal integer, cod_sucursal character varying, descripcion_sucursal character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_pos
			,a.cod_pos
			,a.descripcion descripcion_pos
			,a.id_sucursal
			,b.cod_sucursal
			,b.descripcion descripcion_sucursal
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_pos a	
left join	tbl_sucursal b on a.id_sucursal=b.id_sucursal
where		a.cod_pos = pcod_pos;

END;
$$;


ALTER FUNCTION public.ft_pos_getone(pcod_pos character varying) OWNER TO postgres;

--
-- Name: ft_secuencia_det_compras_getone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_secuencia_det_compras_getone() RETURNS bigint
    LANGUAGE plpgsql
    AS $$

DECLARE
declare vsecuencia_det bigint = nextval('public.tbl_compras_det_secuencia_det_seq'::regclass);
BEGIN
RETURN vsecuencia_det;
END;
$$;


ALTER FUNCTION public.ft_secuencia_det_compras_getone() OWNER TO postgres;

--
-- Name: ft_secuencia_det_getone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_secuencia_det_getone() RETURNS bigint
    LANGUAGE plpgsql
    AS $$

DECLARE
declare vsecuencia_det bigint = nextval('public.tbl_venta_detalle_secuencia_det_seq'::regclass);
BEGIN
RETURN vsecuencia_det;
END;
$$;


ALTER FUNCTION public.ft_secuencia_det_getone() OWNER TO postgres;

--
-- Name: ft_secuencia_enc_compras_getone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_secuencia_enc_compras_getone() RETURNS bigint
    LANGUAGE plpgsql
    AS $$

DECLARE
declare vsecuencia_enc bigint = nextval('public.tbl_compras_enc_secuencia_enc_seq'::regclass);
BEGIN
RETURN vsecuencia_enc;
END;
$$;


ALTER FUNCTION public.ft_secuencia_enc_compras_getone() OWNER TO postgres;

--
-- Name: ft_secuencia_enc_getone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_secuencia_enc_getone() RETURNS bigint
    LANGUAGE plpgsql
    AS $$

DECLARE
declare vsecuencia_enc bigint = nextval('public.tbl_venta_encabezado_secuencia_enc_seq'::regclass);
BEGIN
RETURN vsecuencia_enc;
END;
$$;


ALTER FUNCTION public.ft_secuencia_enc_getone() OWNER TO postgres;

--
-- Name: ft_select_catalogo_cuenta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_select_catalogo_cuenta() RETURNS TABLE(id_cuenta integer, nombre_usuario character varying, codigo_cuenta character varying, nombre_cuenta character varying, nombre_categoria character varying, descripcion character varying, saldo numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
 RETURN QUERY
Select
a.id_cuenta,
c.nombre_usuario,
a.codigo_cuenta,
a.nombre_cuenta,
b.nombre_categoria,
f.descripcion,
a.saldo
from contabilidad.tbl_catalogo_cuenta a
left join contabilidad.tbl_categoria b on a.id_categoria=b.id_categoria
left join seguridad.tbl_ms_usuario c on a.id_usuario=c.id_usuario
left join contabilidad.tbl_destino_cuenta d on a.id_destino_cuenta=d.id_cuenta
left join contabilidad.tbl_informe_financiero f on d.id_informe_financiero=f.id_informe_financiero;

END;
$$;


ALTER FUNCTION public.ft_select_catalogo_cuenta() OWNER TO postgres;

--
-- Name: ft_sucursal_getall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_sucursal_getall() RETURNS TABLE(id_sucursal integer, cod_sucursal character varying, descripcion_sucursal character varying, direccion character varying, telefono character varying, rtn character varying, id_centro_costo integer, cod_centro_costo character varying, descripcion_centro_costo character varying, id_mapa integer, cod_mapa integer, descripcion_mapa character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_sucursal
			,a.cod_sucursal
			,a.descripcion descripcion_sucursal
			,a.direccion
			,a.telefono
			,a.rtn
			,a.id_centro_costo
			,b.cod_centro_costo
			,b.descripcion descripcion_centro_costo
			,a.id_mapa
			,c.cod_mapa
			,c.descripcion descripcion_mapa
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_sucursal a	
left join	tbl_centro_costo b on a.id_centro_costo=b.id_centro_costo
left join	tbl_mapa c on a.id_mapa=c.id_mapa;

END;
$$;


ALTER FUNCTION public.ft_sucursal_getall() OWNER TO postgres;

--
-- Name: ft_sucursal_getone(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_sucursal_getone(pcod_sucursal character varying DEFAULT 0) RETURNS TABLE(id_sucursal integer, cod_sucursal character varying, descripcion_sucursal character varying, direccion character varying, telefono character varying, rtn character varying, id_centro_costo integer, cod_centro_costo character varying, descripcion_centro_costo character varying, id_mapa integer, cod_mapa integer, descripcion_mapa character varying, activo character, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
SELECT 		a.id_sucursal
			,a.cod_sucursal
			,a.descripcion descripcion_sucursal
			,a.direccion
			,a.telefono
			,a.rtn
			,a.id_centro_costo
			,b.cod_centro_costo
			,b.descripcion descripcion_centro_costo
			,a.id_mapa
			,c.cod_mapa
			,c.descripcion descripcion_mapa
			,a.activo
			,a.creado_por
			,a.fecha_creacion
			,a.modificado_por
			,a.fecha_modificacion
from 		tbl_sucursal a	
left join	tbl_centro_costo b on a.id_centro_costo=b.id_centro_costo
left join	tbl_mapa c on a.id_mapa=c.id_mapa
where		a.cod_sucursal = pcod_sucursal;

END;
$$;


ALTER FUNCTION public.ft_sucursal_getone(pcod_sucursal character varying) OWNER TO postgres;

--
-- Name: ft_venta_por_articulos(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_venta_por_articulos(pid_sucursal integer, fecha_inicial date, fecha_final date) RETURNS TABLE(id_sucursal integer, cod_sucursal character varying, categoria character varying, cod_articulo character varying, descripcion character varying, precio numeric, cantidad numeric, venta_neta numeric, venta_total numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
	select		a.id_sucursal
				,a.cod_sucursal
				,d.descripcion categoria
				,c.cod_articulo
				,c.descripcion
				,b.precio
				,sum(b.cantidad)cantidad
				,sum(b.total-b.total_impuesto) venta_neta
				,sum(b.total) venta_total
	from		public.tbl_venta_encabezado	a
	inner join	public.tbl_venta_detalle b on a.secuencia_enc=b.secuencia_enc
	inner join	public.tbl_articulo c on c.id_articulo=c.id_articulo
	left join	public.tbl_categoria d on d.id_categoria=c.id_categoria
	where		a.id_sucursal=pid_sucursal
	and			a.fecha between fecha_inicial and fecha_final
	group by	a.id_sucursal
				,a.cod_sucursal
				,d.descripcion
				,c.cod_articulo
				,c.descripcion
				,b.precio
				
				;

END;
$$;


ALTER FUNCTION public.ft_venta_por_articulos(pid_sucursal integer, fecha_inicial date, fecha_final date) OWNER TO postgres;

--
-- Name: ft_venta_remumen(integer, date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_venta_remumen(pid_sucursal integer, pfecha_inicial date, pfecha_final date) RETURNS TABLE(cod_sucursal character varying, descripcion character varying, monto numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
select 		a.cod_sucursal
			,'VENTA BRUTA'::varchar descripcion
			,sum(a.venta_total)+sum(public.ft_monto_descuento_resumen(a.secuencia_enc)) 
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(-)ANULADAS'::varchar descripcion
			,sum(public.ft_monto_anuladas_resumen(a.secuencia_enc)) 
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(-)DESCUENTOS'::varchar descripcion
			,sum(public.ft_monto_descuento_resumen(a.secuencia_enc)) descuentos
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(=)VENTA ACTUAL'::varchar descripcion
			,sum(public.ft_monto_venta_actual_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'(-)IMPUESTO'::varchar descripcion
			,sum(public.ft_monto_impuestos_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'(=)VENTA NETA'::varchar descripcion
			,sum(public.ft_monto_venta_neta_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'CUENTAS'::varchar descripcion
			,sum(public.ft_monto_cuentas_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'EFECTIVO'::varchar descripcion
			,sum(public.ft_monto_efectivo_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'TARJETA'::varchar descripcion
			,sum(public.ft_monto_tarjeta_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'CLIENTES'::varchar descripcion
			,sum(public.ft_monto_clientes_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
group by	a.cod_sucursal
			
;

END;
$$;


ALTER FUNCTION public.ft_venta_remumen(pid_sucursal integer, pfecha_inicial date, pfecha_final date) OWNER TO postgres;

--
-- Name: ft_venta_remumen_usuario(integer, date, date, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ft_venta_remumen_usuario(pid_sucursal integer, pfecha_inicial date, pfecha_final date, p_id_usuario integer) RETURNS TABLE(cod_sucursal character varying, descripcion character varying, monto numeric)
    LANGUAGE plpgsql
    AS $$

DECLARE

BEGIN
RETURN QUERY
select 		a.cod_sucursal
			,'VENTA BRUTA'::varchar descripcion
			,sum(a.venta_total)+sum(public.ft_monto_descuento_resumen(a.secuencia_enc)) 
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(-)ANULADAS'::varchar descripcion
			,sum(public.ft_monto_anuladas_resumen(a.secuencia_enc)) 
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(-)DESCUENTOS'::varchar descripcion
			,sum(public.ft_monto_descuento_resumen(a.secuencia_enc)) descuentos
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all	
select 		a.cod_sucursal
			,'(=)VENTA ACTUAL'::varchar descripcion
			,sum(public.ft_monto_venta_actual_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'(-)IMPUESTO'::varchar descripcion
			,sum(public.ft_monto_impuestos_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'(=)VENTA NETA'::varchar descripcion
			,sum(public.ft_monto_venta_neta_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'CUENTAS'::varchar descripcion
			,sum(public.ft_monto_cuentas_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'EFECTIVO'::varchar descripcion
			,sum(public.ft_monto_efectivo_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'TARJETA'::varchar descripcion
			,sum(public.ft_monto_tarjeta_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			
union all
select 		a.cod_sucursal
			,'CLIENTES'::varchar descripcion
			,sum(public.ft_monto_clientes_resumen(a.secuencia_enc))
from		public.tbl_venta_encabezado a
where		a.id_sucursal=pid_sucursal
and			a.fecha between pfecha_inicial and pfecha_final
and			a.id_usuario=p_id_usuario
group by	a.cod_sucursal
			;

END;
$$;


ALTER FUNCTION public.ft_venta_remumen_usuario(pid_sucursal integer, pfecha_inicial date, pfecha_final date, p_id_usuario integer) OWNER TO postgres;

--
-- Name: insert_rol(character varying, character varying, character varying, timestamp without time zone, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_rol(IN prol character varying, IN pdescripcion character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_ms_roles(rol ,descripcion ,creado_por ,fecha_creacion ,modificado_por ,fecha_modificacion ) values (prol ,    pdescripcion ,    pcreado_por,    pfecha_creacion,    pmodificado_por, pfecha_modificacion)
$$;


ALTER PROCEDURE public.insert_rol(IN prol character varying, IN pdescripcion character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: insert_usuario(character varying, character varying, character varying, character varying, bigint, timestamp without time zone, bigint, bigint, date, character varying, character varying, timestamp without time zone, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_usuario(IN pusuario character varying, IN pnombre_usuario character varying, IN pestado_usuario character varying, IN pcontrasena character varying, IN pid_rol bigint, IN pfecha_ultima_conexion timestamp without time zone, IN ppreguntas_contestadas bigint, IN pprimer_ingreso bigint, IN pfecha_vencimiento date, IN pcorreo_electronico character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_ms_usuario(
    USUARIO ,
    NOMBRE_USUARIO ,
    ESTADO_USUARIO ,
    CONTRASENA ,
    ID_ROL  ,
    FECHA_ULTIMA_CONEXION ,
    PREGUNTAS_CONTESTADAS ,
    PRIMER_INGRESO ,
    FECHA_VENCIMIENTO ,
    CORREO_ELECTRONICO ,
    CREADO_POR ,
    FECHA_CREACION ,
    MODIFICADO_POR ,
    FECHA_MODIFICACION  ) values (
	pUSUARIO ,
    pNOMBRE_USUARIO ,
    pESTADO_USUARIO ,
    pCONTRASENA ,
    pID_ROL  ,
    pFECHA_ULTIMA_CONEXION ,
    pPREGUNTAS_CONTESTADAS ,
    pPRIMER_INGRESO ,
    pFECHA_VENCIMIENTO ,
    pCORREO_ELECTRONICO ,
    pCREADO_POR ,
    pFECHA_CREACION ,
    pMODIFICADO_POR ,
    pFECHA_MODIFICACION)
$$;


ALTER PROCEDURE public.insert_usuario(IN pusuario character varying, IN pnombre_usuario character varying, IN pestado_usuario character varying, IN pcontrasena character varying, IN pid_rol bigint, IN pfecha_ultima_conexion timestamp without time zone, IN ppreguntas_contestadas bigint, IN pprimer_ingreso bigint, IN pfecha_vencimiento date, IN pcorreo_electronico character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_articulo_bodega_new_insert(integer, integer, numeric, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_articulo_bodega_new_insert(IN pid_centro_costo integer, IN pid_articulo integer, IN pmaximo numeric, IN pminimo numeric)
    LANGUAGE sql
    AS $$
insert into public.tbl_articulo_bodega(
	id_centro_costo,
	id_articulo,
	minimo,
	maximo	
)
values(
	pid_centro_costo,
	pid_articulo,
	pminimo,
	pmaximo	
)

$$;


ALTER PROCEDURE public.prc_articulo_bodega_new_insert(IN pid_centro_costo integer, IN pid_articulo integer, IN pmaximo numeric, IN pminimo numeric) OWNER TO postgres;

--
-- Name: prc_articulo_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_articulo_delete(IN pcod_articulo character varying)
    LANGUAGE sql
    AS $$
delete from tbl_articulo 
where cod_articulo = pcod_articulo
$$;


ALTER PROCEDURE public.prc_articulo_delete(IN pcod_articulo character varying) OWNER TO postgres;

--
-- Name: prc_articulo_insert(character varying, character, character varying, character varying, integer, integer, numeric, integer, integer, character varying, integer, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_articulo_insert(IN pcod_articulo character varying, IN ptipo character, IN pdescripcion character varying, IN pdescripcion_corta character varying, IN pid_impuesto integer, IN pid_categoria integer, IN pprecio numeric, IN pinventario_minimo integer, IN pinventario_maximo integer, IN pcodigo_barra character varying, IN pid_unidad_medida integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_articulo(
	cod_articulo,
    tipo,
    descripcion,
    descripcion_corta,
    id_impuesto,
    id_categoria,
    precio,
    inventario_minimo,
    inventario_maximo,
    codigo_barra,
    id_unidad_medida,
	activo,
    creado_por,
    fecha_creacion
    
) values (
	pcod_articulo,
    ptipo,
    pdescripcion,
    pdescripcion_corta,
    pid_impuesto,
    pid_categoria,
    pprecio,
    pinventario_minimo,
    pinventario_maximo,
    pcodigo_barra,
    pid_unidad_medida,
	pactivo,
    pcreado_por,
    pfecha_creacion
    
)
$$;


ALTER PROCEDURE public.prc_articulo_insert(IN pcod_articulo character varying, IN ptipo character, IN pdescripcion character varying, IN pdescripcion_corta character varying, IN pid_impuesto integer, IN pid_categoria integer, IN pprecio numeric, IN pinventario_minimo integer, IN pinventario_maximo integer, IN pcodigo_barra character varying, IN pid_unidad_medida integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_articulo_update(character varying, character, character varying, character varying, integer, integer, numeric, numeric, numeric, character varying, integer, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_articulo_update(IN pcod_articulo character varying, IN ptipo character, IN pdescripcion character varying, IN pdescripcion_corta character varying, IN pid_impuesto integer, IN pid_categoria integer, IN pprecio numeric, IN pinventario_minimo numeric, IN pinventario_maximo numeric, IN pcodigo_barra character varying, IN pid_unidad_medida integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_articulo set
	tipo 				= ptipo,
    descripcion 		= pdescripcion,
    descripcion_corta 	= pdescripcion_corta,
    id_impuesto 		= pid_impuesto,
    id_categoria 		= pid_categoria,
    precio 				= pprecio,
    inventario_minimo 	= pinventario_minimo,
    inventario_maximo 	= pinventario_maximo,
    codigo_barra 		= pcodigo_barra,
    id_unidad_medida 	= pid_unidad_medida,
	activo 				= pactivo,
    modificado_por 		= pmodificado_por,
    fecha_modificacion 	= pfecha_modificacion
    
where cod_articulo = pcod_articulo
$$;


ALTER PROCEDURE public.prc_articulo_update(IN pcod_articulo character varying, IN ptipo character, IN pdescripcion character varying, IN pdescripcion_corta character varying, IN pid_impuesto integer, IN pid_categoria integer, IN pprecio numeric, IN pinventario_minimo numeric, IN pinventario_maximo numeric, IN pcodigo_barra character varying, IN pid_unidad_medida integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_bitacora_delete(timestamp without time zone, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_bitacora_delete(IN pfecha_inicio timestamp without time zone, IN pfecha_final timestamp without time zone)
    LANGUAGE sql
    AS $$
delete from  seguridad.tbl_ms_bitacora
where cast(fecha as date) between pfecha_inicio and pfecha_final

$$;


ALTER PROCEDURE public.prc_bitacora_delete(IN pfecha_inicio timestamp without time zone, IN pfecha_final timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_bitacora_insert(timestamp without time zone, integer, integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_bitacora_insert(IN pfecha timestamp without time zone, IN pid_usuario integer, IN pid_objeto integer, IN paccion character varying, IN pdescripcion character varying)
    LANGUAGE sql
    AS $$
insert into seguridad.tbl_ms_bitacora(
	fecha,
	id_usuario,
	id_objeto,
	accion,
	descripcion
)
values(
	pfecha,
	pid_usuario,
	pid_objeto,
	paccion,
	pdescripcion
)

$$;


ALTER PROCEDURE public.prc_bitacora_insert(IN pfecha timestamp without time zone, IN pid_usuario integer, IN pid_objeto integer, IN paccion character varying, IN pdescripcion character varying) OWNER TO postgres;

--
-- Name: prc_categoria_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_categoria_delete(IN pcod_categoria integer)
    LANGUAGE sql
    AS $$
delete from  tbl_categoria 
where cod_categoria = pcod_categoria;
$$;


ALTER PROCEDURE public.prc_categoria_delete(IN pcod_categoria integer) OWNER TO postgres;

--
-- Name: prc_categoria_insert(integer, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_categoria_insert(IN pcod_categoria integer, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_categoria(cod_categoria,
						  descripcion, 
						  activo,
						  creado_por,
						  fecha_creacion   
						 ) 
values (pcod_categoria,
		pdescripcion,
		pactivo,
		pcreado_por,
		pfecha_creacion
		)
$$;


ALTER PROCEDURE public.prc_categoria_insert(IN pcod_categoria integer, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_categoria_update(integer, integer, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_categoria_update(IN pid_categoria integer, IN pcod_categoria integer, IN pdescripcion character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_categoria set
cod_categoria = pcod_categoria,
descripcion = pdescripcion,
activo = pactivo,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_categoria = pcod_categoria
and id_categoria = pid_categoria
$$;


ALTER PROCEDURE public.prc_categoria_update(IN pid_categoria integer, IN pcod_categoria integer, IN pdescripcion character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_centro_costo_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_centro_costo_delete(IN pcod_centro_costo character varying)
    LANGUAGE sql
    AS $$
DELETE FROM TBL_CENTRO_COSTO
	where cod_centro_costo = pcod_centro_costo;
$$;


ALTER PROCEDURE public.prc_centro_costo_delete(IN pcod_centro_costo character varying) OWNER TO postgres;

--
-- Name: prc_centro_costo_insert(character varying, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_centro_costo_insert(IN pcod_centro_costo character varying, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_centro_costo(
	cod_centro_costo,
    descripcion,
	activo,
    creado_por,
    fecha_creacion
    
)
values(
	pcod_centro_costo,
    pdescripcion,
	pactivo,
    pcreado_por,
    pfecha_creacion
    
)
$$;


ALTER PROCEDURE public.prc_centro_costo_insert(IN pcod_centro_costo character varying, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_centro_costo_update(character varying, character varying, character varying, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_centro_costo_update(IN pcod_centro_costo character varying, IN pdescripcion character varying, IN pactivo character varying, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_centro_costo set
	descripcion			= pdescripcion,
	activo				= pactivo,
    modificado_por		= pmodificado_por,
    fecha_modificacion	= pfecha_modificacion
    where cod_centro_costo	= pcod_centro_costo;
$$;


ALTER PROCEDURE public.prc_centro_costo_update(IN pcod_centro_costo character varying, IN pdescripcion character varying, IN pactivo character varying, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_correlativo_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_correlativo_delete(IN pid_correlativo integer)
    LANGUAGE sql
    AS $$
delete from tbl_correlativo
where id_correlativo		= pid_correlativo	
$$;


ALTER PROCEDURE public.prc_correlativo_delete(IN pid_correlativo integer) OWNER TO postgres;

--
-- Name: prc_correlativo_insert(integer, character varying, character varying, character varying, character varying, numeric, numeric, numeric, date, character, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_correlativo_insert(IN pid_pos integer, IN pcai character varying, IN psucursal_sar character varying, IN pterminal_sar character varying, IN ptipo_documento_sar character varying, IN pcorrelativo_inicial numeric, IN pcorrelativo_final numeric, IN pcorrelativo_actual numeric, IN pfecha_vencimiento date, IN pactivo character, IN psiguiente character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_correlativo(
	id_pos,
    cai,
    sucursal_sar,
    terminal_sar,
    tipo_documento_sar,
    correlativo_inicial,
    correlativo_final,
    correlativo_actual,
    fecha_vencimiento,
	activo,
	siguiente,
    creado_por,
    fecha_creacion
    
)
values(
	pid_pos,
    pcai,
    psucursal_sar,
    pterminal_sar,
    ptipo_documento_sar,
    pcorrelativo_inicial,
    pcorrelativo_final,
    pcorrelativo_actual,
    pfecha_vencimiento,
	pactivo,
	psiguiente,
    pcreado_por,
    pfecha_creacion
)

$$;


ALTER PROCEDURE public.prc_correlativo_insert(IN pid_pos integer, IN pcai character varying, IN psucursal_sar character varying, IN pterminal_sar character varying, IN ptipo_documento_sar character varying, IN pcorrelativo_inicial numeric, IN pcorrelativo_final numeric, IN pcorrelativo_actual numeric, IN pfecha_vencimiento date, IN pactivo character, IN psiguiente character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_correlativo_update(integer, integer, character varying, character varying, character varying, character varying, numeric, numeric, numeric, date, character, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_correlativo_update(IN pid_correlativo integer, IN pid_pos integer, IN pcai character varying, IN psucursal_sar character varying, IN pterminal_sar character varying, IN ptipo_documento_sar character varying, IN pcorrelativo_inicial numeric, IN pcorrelativo_final numeric, IN pcorrelativo_actual numeric, IN pfecha_vencimiento date, IN pactivo character, IN psiguiente character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_correlativo set
	cai					= pcai,
	id_pos				= pid_pos,
    sucursal_sar		= psucursal_sar,
    terminal_sar		= pterminal_sar,
    tipo_documento_sar	= ptipo_documento_sar,
    correlativo_inicial	= pcorrelativo_inicial,
    correlativo_final	= pcorrelativo_final,
    correlativo_actual	= pcorrelativo_actual,
    fecha_vencimiento	= pfecha_vencimiento,
	activo				= pactivo,
	siguiente			= psiguiente,
    modificado_por		= pmodificado_por,
    fecha_modificacion	= pfecha_modificacion
    
where id_correlativo		= pid_correlativo	
$$;


ALTER PROCEDURE public.prc_correlativo_update(IN pid_correlativo integer, IN pid_pos integer, IN pcai character varying, IN psucursal_sar character varying, IN pterminal_sar character varying, IN ptipo_documento_sar character varying, IN pcorrelativo_inicial numeric, IN pcorrelativo_final numeric, IN pcorrelativo_actual numeric, IN pfecha_vencimiento date, IN pactivo character, IN psiguiente character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_descuento_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_descuento_delete(IN pcod_descuento integer)
    LANGUAGE sql
    AS $$
delete from  tbl_descuento 
where cod_descuento = pcod_descuento
$$;


ALTER PROCEDURE public.prc_descuento_delete(IN pcod_descuento integer) OWNER TO postgres;

--
-- Name: prc_descuento_insert(integer, character varying, numeric, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_descuento_insert(IN pcod_descuento integer, IN pdescripcion character varying, IN pporcentaje numeric, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_descuento(cod_descuento ,
						  descripcion ,
						  porcentaje,
						  activo ,
						  creado_por ,
						  fecha_creacion 
						  
						 ) 
						 values (pcod_descuento ,    
								 pdescripcion , 
								 pporcentaje,  
								 pactivo,
								 pcreado_por,    
								 pfecha_creacion
								 
								)
$$;


ALTER PROCEDURE public.prc_descuento_insert(IN pcod_descuento integer, IN pdescripcion character varying, IN pporcentaje numeric, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_descuento_update(integer, character varying, numeric, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_descuento_update(IN pcod_descuento integer, IN pdescripcion character varying, IN pporcentaje numeric, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_descuento set
descripcion = pdescripcion,
porcentaje = pporcentaje,
activo = pactivo,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_descuento = pcod_descuento
$$;


ALTER PROCEDURE public.prc_descuento_update(IN pcod_descuento integer, IN pdescripcion character varying, IN pporcentaje numeric, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_empresa_insert(character varying, character varying, character varying, character varying, character varying, bytea, bytea, bytea, bytea, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_empresa_insert(IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 bytea, IN plogo2 bytea, IN plogo3 bytea, IN plogo4 bytea, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_empresa(descripcion, 
						  direccion,
						  telefono,
						  correo,
						  rtn,
						  logo1,
						  logo2,
						  logo3,
						  logo4,
						  creado_por,
						  fecha_creacion   
						 ) 
	values (pdescripcion, 
		  pdireccion,
		  ptelefono,
		  pcorreo,
		  prtn,
		  plogo1,
		  plogo2,
		  plogo3,
		  plogo4,
		  pcreado_por,
		  pfecha_creacion
			)
$$;


ALTER PROCEDURE public.prc_empresa_insert(IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 bytea, IN plogo2 bytea, IN plogo3 bytea, IN plogo4 bytea, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_empresa_insert(character varying, character varying, character varying, character varying, character varying, text, text, text, text, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_empresa_insert(IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 text, IN plogo2 text, IN plogo3 text, IN plogo4 text, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_empresa(descripcion, 
						  direccion,
						  telefono,
						  correo,
						  rtn,
						  logo1,
						  logo2,
						  logo3,
						  logo4,
						  creado_por,
						  fecha_creacion   
						 ) 
	values (pdescripcion, 
		  pdireccion,
		  ptelefono,
		  pcorreo,
		  prtn,
		  plogo1,
		  plogo2,
		  plogo3,
		  plogo4,
		  pcreado_por,
		  pfecha_creacion
			)
$$;


ALTER PROCEDURE public.prc_empresa_insert(IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 text, IN plogo2 text, IN plogo3 text, IN plogo4 text, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_empresa_update(integer, character varying, character varying, character varying, character varying, character varying, bytea, bytea, bytea, bytea, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_empresa_update(IN pid_empresa integer, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 bytea, IN plogo2 bytea, IN plogo3 bytea, IN plogo4 bytea, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_empresa set

descripcion = pdescripcion,
direccion = pdireccion,
telefono = ptelefono,
correo = pcorreo,
rtn = prtn,
logo1 = plogo1,
logo2 = plogo2,
logo3 = plogo3,
logo4 = plogo4,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where id_empresa = pid_empresa
$$;


ALTER PROCEDURE public.prc_empresa_update(IN pid_empresa integer, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 bytea, IN plogo2 bytea, IN plogo3 bytea, IN plogo4 bytea, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_empresa_update(integer, character varying, character varying, character varying, character varying, character varying, text, text, text, text, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_empresa_update(IN pid_empresa integer, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 text, IN plogo2 text, IN plogo3 text, IN plogo4 text, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_empresa set

descripcion = pdescripcion,
direccion = pdireccion,
telefono = ptelefono,
correo = pcorreo,
rtn = prtn,
logo1 = plogo1,
logo2 = plogo2,
logo3 = plogo3,
logo4 = plogo4,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where id_empresa = pid_empresa
$$;


ALTER PROCEDURE public.prc_empresa_update(IN pid_empresa integer, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcorreo character varying, IN prtn character varying, IN plogo1 text, IN plogo2 text, IN plogo3 text, IN plogo4 text, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_impuesto_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_impuesto_delete(IN pcod_impuesto integer)
    LANGUAGE sql
    AS $$
delete from  tbl_impuesto 
where cod_impuesto = pcod_impuesto
$$;


ALTER PROCEDURE public.prc_impuesto_delete(IN pcod_impuesto integer) OWNER TO postgres;

--
-- Name: prc_impuesto_insert(integer, character varying, numeric, character, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_impuesto_insert(IN pcod_impuesto integer, IN pdescripcion character varying, IN pporcentaje numeric, IN ptipo character, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_impuesto(cod_impuesto ,
						 descripcion ,
						 porcentaje,
						 tipo,
						 activo ,
						 creado_por ,
						 fecha_creacion 
						 
						) 
values (pcod_impuesto ,    
		pdescripcion , 
		pporcentaje, 
		ptipo,  
		pactivo,
		pcreado_por,    
		pfecha_creacion
		
	   )
$$;


ALTER PROCEDURE public.prc_impuesto_insert(IN pcod_impuesto integer, IN pdescripcion character varying, IN pporcentaje numeric, IN ptipo character, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_impuesto_update(integer, character varying, numeric, character, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_impuesto_update(IN pcod_impuesto integer, IN pdescripcion character varying, IN pporcentaje numeric, IN ptipo character, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_impuesto set
descripcion = pdescripcion,
porcentaje = pporcentaje,
tipo = ptipo,
activo = pactivo,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_impuesto = pcod_impuesto
$$;


ALTER PROCEDURE public.prc_impuesto_update(IN pcod_impuesto integer, IN pdescripcion character varying, IN pporcentaje numeric, IN ptipo character, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_lista_materiales_delete(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_lista_materiales_delete(IN pid_articulo_padre integer, IN pid_articulo_hijo integer)
    LANGUAGE sql
    AS $$
delete from  tbl_lista_materiales 
where id_articulo_padre = pid_articulo_padre
and	id_articulo_hijo = pid_articulo_hijo
$$;


ALTER PROCEDURE public.prc_lista_materiales_delete(IN pid_articulo_padre integer, IN pid_articulo_hijo integer) OWNER TO postgres;

--
-- Name: prc_lista_materiales_insert(integer, integer, numeric, character varying, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_lista_materiales_insert(IN pid_articulo_padre integer, IN pid_articulo_hijo integer, IN pcantidad numeric, IN pcomentario character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_lista_materiales(id_articulo_padre,
						  id_articulo_hijo, 
						  cantidad,
						  comentario,
						  creado_por,
						  fecha_creacion   
						 ) 
values (pid_articulo_padre,
						  pid_articulo_hijo, 
						  pcantidad,
						  pcomentario,
						  pcreado_por,
						  pfecha_creacion 
		)
$$;


ALTER PROCEDURE public.prc_lista_materiales_insert(IN pid_articulo_padre integer, IN pid_articulo_hijo integer, IN pcantidad numeric, IN pcomentario character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_lista_materiales_update(integer, integer, numeric, character varying, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_lista_materiales_update(IN pid_articulo_padre integer, IN pid_articulo_hijo integer, IN pcantidad numeric, IN pcomentario character varying, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_lista_materiales set
	id_articulo_padre = pid_articulo_padre,
	id_articulo_hijo = pid_articulo_hijo, 
	cantidad = pcantidad,
	comentario = pcomentario,
	modificado_por = pmodificado_por,
	fecha_modificacion = pfecha_modificacion   
where id_articulo_padre = pid_articulo_padre
and id_articulo_hijo = pid_articulo_hijo
$$;


ALTER PROCEDURE public.prc_lista_materiales_update(IN pid_articulo_padre integer, IN pid_articulo_hijo integer, IN pcantidad numeric, IN pcomentario character varying, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_metodo_pago_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_metodo_pago_delete(IN pcod_metodo_pago integer)
    LANGUAGE sql
    AS $$
delete from tbl_metodo_pago
where cod_metodo_pago = pcod_metodo_pago
$$;


ALTER PROCEDURE public.prc_metodo_pago_delete(IN pcod_metodo_pago integer) OWNER TO postgres;

--
-- Name: prc_metodo_pago_insert(integer, character varying, character, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_metodo_pago_insert(IN pcod_metodo_pago integer, IN pdescripcion character varying, IN ptipo character, IN pcuenta_contable character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_metodo_pago(
	cod_metodo_pago,
    descripcion,
    tipo,
	cuenta_contable,
	activo,
    creado_por,
    fecha_creacion
    
)
values(
	pcod_metodo_pago,
    pdescripcion,
    ptipo,
	pcuenta_contable,
	pactivo,
    pcreado_por,
    pfecha_creacion
    
)
$$;


ALTER PROCEDURE public.prc_metodo_pago_insert(IN pcod_metodo_pago integer, IN pdescripcion character varying, IN ptipo character, IN pcuenta_contable character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_metodo_pago_update(integer, character varying, character, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_metodo_pago_update(IN pcod_metodo_pago integer, IN pdescripcion character varying, IN ptipo character, IN pcuenta_contable character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_metodo_pago set
	descripcion			= pdescripcion,
    tipo				= ptipo,
    cuenta_contable		= pcuenta_contable,
	activo				= pactivo,
    modificado_por		= pmodificado_por,
    fecha_modificacion	= pfecha_modificacion
    
where cod_metodo_pago = pcod_metodo_pago
$$;


ALTER PROCEDURE public.prc_metodo_pago_update(IN pcod_metodo_pago integer, IN pdescripcion character varying, IN ptipo character, IN pcuenta_contable character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_modo_pedido_delete(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_modo_pedido_delete(IN pcod_modo_pedido integer)
    LANGUAGE sql
    AS $$
delete from tbl_modo_pedido
where cod_modo_pedido = pcod_modo_pedido
$$;


ALTER PROCEDURE public.prc_modo_pedido_delete(IN pcod_modo_pedido integer) OWNER TO postgres;

--
-- Name: prc_modo_pedido_insert(integer, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_modo_pedido_insert(IN pcod_modo_pedido integer, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_modo_pedido(
	cod_modo_pedido,
    descripcion,
    activo,
    creado_por,
    fecha_creacion
    
)
values(
	pcod_modo_pedido,
    pdescripcion,
    pactivo,
    pcreado_por,
    pfecha_creacion
    
)
$$;


ALTER PROCEDURE public.prc_modo_pedido_insert(IN pcod_modo_pedido integer, IN pdescripcion character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_modo_pedido_update(integer, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_modo_pedido_update(IN pcod_modo_pedido integer, IN pdescripcion character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_modo_pedido set
	descripcion			= pdescripcion,
    activo				= pactivo,
    modificado_por		= pmodificado_por,
    fecha_modificacion	= pfecha_modificacion
    
where cod_modo_pedido = pcod_modo_pedido
$$;


ALTER PROCEDURE public.prc_modo_pedido_update(IN pcod_modo_pedido integer, IN pdescripcion character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_pos_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_pos_delete(IN pcod_pos character varying)
    LANGUAGE sql
    AS $$
delete from  tbl_pos 
where cod_pos = pcod_pos
$$;


ALTER PROCEDURE public.prc_pos_delete(IN pcod_pos character varying) OWNER TO postgres;

--
-- Name: prc_pos_insert(character varying, character varying, integer, character, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_pos_insert(IN pcod_pos character varying, IN pdescripcion character varying, IN pid_sucursal integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion date)
    LANGUAGE sql
    AS $$
insert into tbl_pos(cod_pos,
						  descripcion, 
						  id_sucursal,
						  activo,
						  creado_por,
						  fecha_creacion   
						 ) 
values (pcod_pos,
		pdescripcion,
		pid_sucursal,
		pactivo,
		pcreado_por,
		pfecha_creacion
		)
$$;


ALTER PROCEDURE public.prc_pos_insert(IN pcod_pos character varying, IN pdescripcion character varying, IN pid_sucursal integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion date) OWNER TO postgres;

--
-- Name: prc_pos_update(character varying, character varying, integer, character, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_pos_update(IN pcod_pos character varying, IN pdescripcion character varying, IN pid_sucursal integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_pos set
cod_pos = pcod_pos,
descripcion = pdescripcion,
id_sucursal = pid_sucursal,
activo = pactivo,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_pos = pcod_pos
$$;


ALTER PROCEDURE public.prc_pos_update(IN pcod_pos character varying, IN pdescripcion character varying, IN pid_sucursal integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_socio_negocio_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_socio_negocio_delete(IN pcod_socio_negocio character varying)
    LANGUAGE sql
    AS $$
delete from  tbl_socio_negocio
where cod_socio_negocio = pcod_socio_negocio
$$;


ALTER PROCEDURE public.prc_socio_negocio_delete(IN pcod_socio_negocio character varying) OWNER TO postgres;

--
-- Name: prc_socio_negocio_insert(character varying, character, character varying, character varying, character varying, character varying, character varying, character varying, numeric, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_socio_negocio_insert(IN pcod_socio_negocio character varying, IN ptipo character, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcontacto character varying, IN pcorreo character varying, IN prtn character varying, IN pbalance numeric, IN pcuenta_contable character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_socio_negocio (
	cod_socio_negocio,
	tipo,
	descripcion,
	direccion,
	telefono,
	contacto,
	correo,
	rtn,
	balance,
	cuenta_contable,
	activo,
	creado_por,
	fecha_creacion
)
values (
	 pcod_socio_negocio,
	 ptipo,
	 pdescripcion,
	 pdireccion,
	 ptelefono,
	 pcontacto,
	 pcorreo,
	 prtn,
	 pbalance,
	 pcuenta_contable,
	 pactivo,
	 pcreado_por,
	 pfecha_creacion
)
    

$$;


ALTER PROCEDURE public.prc_socio_negocio_insert(IN pcod_socio_negocio character varying, IN ptipo character, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcontacto character varying, IN pcorreo character varying, IN prtn character varying, IN pbalance numeric, IN pcuenta_contable character varying, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_socio_negocio_update(character varying, character, character varying, character varying, character varying, character varying, character varying, character varying, numeric, character varying, character, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_socio_negocio_update(IN pcod_socio_negocio character varying, IN ptipo character, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcontacto character varying, IN pcorreo character varying, IN prtn character varying, IN pbalance numeric, IN pcuenta_contable character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_socio_negocio set
	cod_socio_negocio = pcod_socio_negocio,
	tipo = ptipo,
	descripcion = pdescripcion,
	direccion = pdireccion,
	telefono = ptelefono,
	contacto = pcontacto,
	correo = pcorreo,
	rtn = prtn,
	balance = pbalance,
	cuenta_contable = pcuenta_contable,
	activo = pactivo,
	modificado_por = pmodificado_por,
	fecha_modificacion = pfecha_modificacion
    
where cod_socio_negocio = pcod_socio_negocio
$$;


ALTER PROCEDURE public.prc_socio_negocio_update(IN pcod_socio_negocio character varying, IN ptipo character, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN pcontacto character varying, IN pcorreo character varying, IN prtn character varying, IN pbalance numeric, IN pcuenta_contable character varying, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_sucursal_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_sucursal_delete(IN pcod_sucursal character varying)
    LANGUAGE sql
    AS $$
delete from  tbl_sucursal
where cod_sucursal = pcod_sucursal
$$;


ALTER PROCEDURE public.prc_sucursal_delete(IN pcod_sucursal character varying) OWNER TO postgres;

--
-- Name: prc_sucursal_insert(character varying, character varying, character varying, character varying, character varying, integer, integer, character, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_sucursal_insert(IN pcod_sucursal character varying, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN prtn character varying, IN pid_centro_costo integer, IN pid_mapa integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion date)
    LANGUAGE sql
    AS $$
insert into tbl_sucursal(cod_sucursal,
						  descripcion, 
						  direccion,
						  telefono,
						  rtn,
						  id_centro_costo,
						  id_mapa,
						  activo,
						  creado_por,
						  fecha_creacion   
						 ) 
values (pcod_sucursal,
	  pdescripcion, 
	  pdireccion,
	  ptelefono,
	  prtn,
	  pid_centro_costo,
	  pid_mapa,
	  pactivo,
	  pcreado_por,
	  pfecha_creacion
		)
$$;


ALTER PROCEDURE public.prc_sucursal_insert(IN pcod_sucursal character varying, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN prtn character varying, IN pid_centro_costo integer, IN pid_mapa integer, IN pactivo character, IN pcreado_por character varying, IN pfecha_creacion date) OWNER TO postgres;

--
-- Name: prc_sucursal_update(character varying, character varying, character varying, character varying, character varying, integer, integer, character, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_sucursal_update(IN pcod_sucursal character varying, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN prtn character varying, IN pid_centro_costo integer, IN pid_mapa integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_sucursal set
cod_sucursal = pcod_sucursal,
descripcion = pdescripcion,
direccion = pdireccion,
telefono = ptelefono,
rtn = prtn,
id_centro_costo = pid_centro_costo,
id_mapa = pid_mapa,
activo = pactivo,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_sucursal = pcod_sucursal
$$;


ALTER PROCEDURE public.prc_sucursal_update(IN pcod_sucursal character varying, IN pdescripcion character varying, IN pdireccion character varying, IN ptelefono character varying, IN prtn character varying, IN pid_centro_costo integer, IN pid_mapa integer, IN pactivo character, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_unidad_medida_delete(character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_unidad_medida_delete(IN pcod_unidad_medida character varying)
    LANGUAGE sql
    AS $$
delete from  tbl_unidades_medida 
where cod_unidad_medida = pcod_unidad_medida
$$;


ALTER PROCEDURE public.prc_unidad_medida_delete(IN pcod_unidad_medida character varying) OWNER TO postgres;

--
-- Name: prc_unidad_medida_insert(character varying, character varying, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_unidad_medida_insert(IN pcod_unidad_medida character varying, IN pdescripcion character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone)
    LANGUAGE sql
    AS $$
insert into tbl_unidades_medida(cod_unidad_medida,
						  descripcion, 
						  creado_por,
						  fecha_creacion   
						 ) 
values (pcod_unidad_medida,
		pdescripcion,
		pcreado_por,
		pfecha_creacion
		)
$$;


ALTER PROCEDURE public.prc_unidad_medida_insert(IN pcod_unidad_medida character varying, IN pdescripcion character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: prc_unidad_medida_update(character varying, character varying, character varying, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_unidad_medida_update(IN pcod_unidad_medida character varying, IN pdescripcion character varying, IN pmodificado_por character varying, IN pfecha_modificacion date)
    LANGUAGE sql
    AS $$
update tbl_unidades_medida set
cod_unidad_medida = pcod_unidad_medida,
descripcion = pdescripcion,
modificado_por = pmodificado_por,
fecha_modificacion = pfecha_modificacion

where cod_unidad_medida = pcod_unidad_medida
$$;


ALTER PROCEDURE public.prc_unidad_medida_update(IN pcod_unidad_medida character varying, IN pdescripcion character varying, IN pmodificado_por character varying, IN pfecha_modificacion date) OWNER TO postgres;

--
-- Name: prc_venta_delete(bigint, bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_delete(IN psecuencia_enc bigint, IN psecuencia_det bigint)
    LANGUAGE sql
    AS $$
delete from tbl_venta_detalle where secuencia_det=psecuencia_det;
delete from tbl_venta_encabezado where secuencia_enc=psecuencia_enc;
$$;


ALTER PROCEDURE public.prc_venta_delete(IN psecuencia_enc bigint, IN psecuencia_det bigint) OWNER TO postgres;

--
-- Name: prc_venta_deta_desc_insert(bigint, integer, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_deta_desc_insert(IN psecuencia_det bigint, IN pid_articulo integer, IN pid_descuento integer, IN pmonto numeric)
    LANGUAGE sql
    AS $$
insert into tbl_venta_detalle_desc(
	secuencia_det ,
	id_articulo ,
	id_descuento ,
	monto 
	) 
values (
	psecuencia_det ,
	pid_articulo ,
	pid_descuento ,
	pmonto 
	)
$$;


ALTER PROCEDURE public.prc_venta_deta_desc_insert(IN psecuencia_det bigint, IN pid_articulo integer, IN pid_descuento integer, IN pmonto numeric) OWNER TO postgres;

--
-- Name: prc_venta_deta_insert(bigint, bigint, integer, integer, numeric, integer, integer, numeric, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_deta_insert(IN psecuencia_det bigint, IN psecuencia_enc bigint, IN pid_articulo integer, IN pid_modo_pedido integer, IN pprecio numeric, IN pcantidad integer, IN pid_impuesto integer, IN ptotal_impuesto numeric, IN ptotal numeric)
    LANGUAGE sql
    AS $$
insert into tbl_venta_detalle(
	secuencia_det,
	secuencia_enc ,
	id_articulo ,
	id_modo_pedido ,
	precio ,
	cantidad ,
	id_impuesto ,
	total_impuesto ,
	total  
	) 
values (
	psecuencia_det,
	psecuencia_enc ,
	pid_articulo ,
	pid_modo_pedido ,
	pprecio ,
	pcantidad ,
	pid_impuesto ,
	ptotal_impuesto ,
	ptotal   
	)
$$;


ALTER PROCEDURE public.prc_venta_deta_insert(IN psecuencia_det bigint, IN psecuencia_enc bigint, IN pid_articulo integer, IN pid_modo_pedido integer, IN pprecio numeric, IN pcantidad integer, IN pid_impuesto integer, IN ptotal_impuesto numeric, IN ptotal numeric) OWNER TO postgres;

--
-- Name: prc_venta_deta_pago_insert(bigint, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_deta_pago_insert(IN psecuencia_enc bigint, IN pid_metodo_pago integer, IN pmonto numeric)
    LANGUAGE sql
    AS $$
insert into tbl_venta_detalle_pago(
	secuencia_enc ,
	id_metodo_pago ,
	monto 
	) 
values (
	psecuencia_enc ,
	pid_metodo_pago ,
	pmonto 
	)
$$;


ALTER PROCEDURE public.prc_venta_deta_pago_insert(IN psecuencia_enc bigint, IN pid_metodo_pago integer, IN pmonto numeric) OWNER TO postgres;

--
-- Name: prc_venta_deta_promo_insert(bigint, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_deta_promo_insert(IN psecuencia_det bigint, IN pid_articulo integer, IN pid_promo integer)
    LANGUAGE sql
    AS $$
insert into tbl_venta_detalle_promo(
	secuencia_det ,
	id_articulo ,
	id_promo 
	) 
values (
	psecuencia_det ,
	pid_articulo ,
	pid_promo 
	)
$$;


ALTER PROCEDURE public.prc_venta_deta_promo_insert(IN psecuencia_det bigint, IN pid_articulo integer, IN pid_promo integer) OWNER TO postgres;

--
-- Name: prc_venta_enca_insert(bigint, integer, character varying, date, integer, numeric, numeric, numeric, numeric, numeric, numeric, character varying, integer, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.prc_venta_enca_insert(IN psecuencia_enc bigint, IN pid_sucursal integer, IN pcod_sucursal character varying, IN pfecha date, IN pnumero_cuenta integer, IN pventa_grabada_15 numeric, IN pventa_grabada_18 numeric, IN pventa_exenta numeric, IN pimpuesto_15 numeric, IN pimpuesto_18 numeric, IN pventa_total numeric, IN pcai character varying, IN pcorrelativo integer, IN prtn character varying, IN pnombre_cliente character varying)
    LANGUAGE sql
    AS $$
insert into tbl_venta_encabezado(
	secuencia_enc,
	id_sucursal ,
	cod_sucursal ,
	fecha ,
	numero_cuenta ,
	venta_grabada_15 ,
	venta_grabada_18 ,
	venta_exenta ,
	impuesto_15 ,
	impuesto_18 ,
	venta_total ,
	cai ,
	correlativo ,
	rtn ,
	nombre_cliente   
	) 
values (
	psecuencia_enc,
	pid_sucursal ,
	pcod_sucursal ,
	pfecha ,
	pnumero_cuenta ,
	pventa_grabada_15 ,
	pventa_grabada_18 ,
	pventa_exenta ,
	pimpuesto_15 ,
	pimpuesto_18 ,
	pventa_total ,
	pcai ,
	pcorrelativo ,
	prtn ,
	pnombre_cliente   
	)
$$;


ALTER PROCEDURE public.prc_venta_enca_insert(IN psecuencia_enc bigint, IN pid_sucursal integer, IN pcod_sucursal character varying, IN pfecha date, IN pnumero_cuenta integer, IN pventa_grabada_15 numeric, IN pventa_grabada_18 numeric, IN pventa_exenta numeric, IN pimpuesto_15 numeric, IN pimpuesto_18 numeric, IN pventa_total numeric, IN pcai character varying, IN pcorrelativo integer, IN prtn character varying, IN pnombre_cliente character varying) OWNER TO postgres;

--
-- Name: update_usuario(character varying, character varying, character varying, character varying, bigint, timestamp without time zone, bigint, bigint, date, character varying, character varying, timestamp without time zone, character varying, timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_usuario(IN pusuario character varying, IN pnombre_usuario character varying, IN pestado_usuario character varying, IN pcontrasena character varying, IN pid_rol bigint, IN pfecha_ultima_conexion timestamp without time zone, IN ppreguntas_contestadas bigint, IN pprimer_ingreso bigint, IN pfecha_vencimiento date, IN pcorreo_electronico character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone)
    LANGUAGE sql
    AS $$
update tbl_ms_usuario set
    
    NOMBRE_USUARIO  = pNOMBRE_USUARIO,
    ESTADO_USUARIO = pESTADO_USUARIO ,
    CONTRASENA = pCONTRASENA ,
    ID_ROL = pID_ROL ,
    FECHA_ULTIMA_CONEXION = pFECHA_ULTIMA_CONEXION ,
    PREGUNTAS_CONTESTADAS = pPREGUNTAS_CONTESTADAS,
    PRIMER_INGRESO = pPRIMER_INGRESO ,
    FECHA_VENCIMIENTO = pFECHA_VENCIMIENTO,
    CORREO_ELECTRONICO = pCORREO_ELECTRONICO ,
    CREADO_POR = pCREADO_POR ,
    FECHA_CREACION = pFECHA_CREACION ,
    MODIFICADO_POR = pMODIFICADO_POR,
    FECHA_MODIFICACION  = pFECHA_MODIFICACION
	where USUARIO = pUSUARIO
$$;


ALTER PROCEDURE public.update_usuario(IN pusuario character varying, IN pnombre_usuario character varying, IN pestado_usuario character varying, IN pcontrasena character varying, IN pid_rol bigint, IN pfecha_ultima_conexion timestamp without time zone, IN ppreguntas_contestadas bigint, IN pprimer_ingreso bigint, IN pfecha_vencimiento date, IN pcorreo_electronico character varying, IN pcreado_por character varying, IN pfecha_creacion timestamp without time zone, IN pmodificado_por character varying, IN pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: d_delete_estado(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_estado(p_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM 
  seguridad.tbl_ms_usuario_estado 
WHERE 
  id = p_id
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_estado(p_id integer) OWNER TO postgres;

--
-- Name: d_delete_objeto(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_objeto(p_id_objeto integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
 DELETE FROM 
  seguridad.tbl_ms_objetos 
WHERE 
  id_objeto = p_id_objeto
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_objeto(p_id_objeto integer) OWNER TO postgres;

--
-- Name: d_delete_parametro(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_parametro(pparametro integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  seguridad.tbl_ms_parametros
WHERE 
  id_parametro = pparametro
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_parametro(pparametro integer) OWNER TO postgres;

--
-- Name: d_delete_permisos(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_permisos(p_id_permiso integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  seguridad.tbl_ms_permisos 
WHERE 
  id_permiso = p_id_permiso
;
return true; 
END;
$$;


ALTER FUNCTION seguridad.d_delete_permisos(p_id_permiso integer) OWNER TO postgres;

--
-- Name: d_delete_pregunta(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_pregunta(pid_pregunta integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  seguridad.tbl_ms_preguntas
WHERE 
  id_pregunta = pid_pregunta
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_pregunta(pid_pregunta integer) OWNER TO postgres;

--
-- Name: d_delete_preguntas_usuario(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_preguntas_usuario(p_id_preguntas_usuario integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  seguridad.tbl_ms_preguntas_usuario 
WHERE 
  id_preguntas_usuario = p_id_preguntas_usuario
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_preguntas_usuario(p_id_preguntas_usuario integer) OWNER TO postgres;

--
-- Name: d_delete_rol(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_rol(p_id_rol integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
DELETE FROM 
  seguridad.tbl_ms_roles 
WHERE 
  id_rol = p_id_rol
;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_rol(p_id_rol integer) OWNER TO postgres;

--
-- Name: d_delete_usuario(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.d_delete_usuario(pid_usuario integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

declare vusuario varchar;
BEGIN
	select usuario into vusuario from seguridad.tbl_ms_usuario where id_usuario=pid_usuario;
	if vusuario <> 'SYSTEMUSER' then
		DELETE FROM 
		  seguridad.tbl_ms_usuario
		WHERE 
		  id_usuario = pid_usuario
		;
	end if;
return true;
END;
$$;


ALTER FUNCTION seguridad.d_delete_usuario(pid_usuario integer) OWNER TO postgres;

--
-- Name: fcn_respaldo_log_insert(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.fcn_respaldo_log_insert(pruta character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare vexiste integer =0;

BEGIN
	select count(*) into vexiste from seguridad.tbl_respaldo_log where ruta = pruta;
	
	if vexiste = 0 then
	  INSERT INTO 
		seguridad.tbl_respaldo_log
	  (
		ruta
	  )
	  VALUES (
		pruta
	  );
	  
	  end if;
  
END;
$$;


ALTER FUNCTION seguridad.fcn_respaldo_log_insert(pruta character varying) OWNER TO postgres;

--
-- Name: fcn_tgr_objeto_new_insert(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.fcn_tgr_objeto_new_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

DECLARE f record;

begin
	
	for f in select 	id_rol
				from 	seguridad.tbl_ms_roles	
	loop
		
		perform seguridad.sp_insert_permisos(false::boolean, false::boolean, false::boolean, false::boolean, NULL::varchar, NULL::date, f.id_rol::integer, new.id_objeto::integer);
	end loop;
	
	RETURN NEW;
end;
$$;


ALTER FUNCTION seguridad.fcn_tgr_objeto_new_insert() OWNER TO postgres;

--
-- Name: fcn_tgr_rol_new_insert(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.fcn_tgr_rol_new_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

DECLARE f record;
declare vboolean boolean;

begin
	
	for f in select 	id_objeto
				from 	seguridad.tbl_ms_objetos	
	loop
		
		perform seguridad.sp_insert_permisos(false::boolean, false::boolean, false::boolean, false::boolean, new.creado_por::varchar, new.fecha_creacion::date, new.id_rol::integer, f.id_objeto::integer);
	end loop;
	
	RETURN NEW;
end;
$$;


ALTER FUNCTION seguridad.fcn_tgr_rol_new_insert() OWNER TO postgres;

--
-- Name: fcn_update_password(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.fcn_update_password() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

DECLARE vHist integer;
DECLARE vHistDel integer;

begin
	select count(*) into vHist from seguridad.tbl_ms_hist_contrasena where id_usuario=old.id_usuario;

	
	if vHist = 10 then
		select min(id_hist) into vHistDel from seguridad.tbl_ms_hist_contrasena where id_usuario=old.id_usuario;
		delete from seguridad.TBL_MS_HIST_CONTRASENA where id_usuario=old.id_usuario and ID_HIST=vHistDel;
	end if;
	if new.contrasena <> old.contrasena then
		insert into seguridad.TBL_MS_HIST_CONTRASENA(id_usuario, contrasena) values(old.id_usuario, old.CONTRASENA);
	end if;
	RETURN NEW;
end;
$$;


ALTER FUNCTION seguridad.fcn_update_password() OWNER TO postgres;

--
-- Name: ft_actualiza_estado_usuario(integer, integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualiza_estado_usuario(p_id integer, p_id_estado integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  seguridad.tbl_ms_usuario 
SET 
  estado_usuario = p_id_estado
WHERE 
  id_usuario = p_id
;
return true;
END;
$$;


ALTER FUNCTION seguridad.ft_actualiza_estado_usuario(p_id integer, p_id_estado integer) OWNER TO postgres;

--
-- Name: ft_actualizar_objetos(integer, character varying, character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_objetos(pid_objeto integer, pobjeto character varying, pdescripcion character varying, ptipo_objeto character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

UPDATE 
  seguridad.tbl_ms_objetos
SET 
  objeto = pobjeto,
  descripcion = pdescripcion,
  tipo_objeto = ptipo_objeto
WHERE 
  id_objeto = pid_objeto
; 
RETURN TRUE;
END
$$;


ALTER FUNCTION seguridad.ft_actualizar_objetos(pid_objeto integer, pobjeto character varying, pdescripcion character varying, ptipo_objeto character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_parametros(integer, character varying, character varying, character varying, timestamp without time zone); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_parametros(pid_parametro integer, pparametro character varying, pvalor character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

UPDATE 
  seguridad.tbl_ms_parametros
SET 
  parametro = pparametro,
  valor = pvalor,
  modificado_por = pmodificado_por,
  fecha_modificacion = pfecha_modificacion
WHERE 
  id_parametro = pid_parametro
; 
RETURN TRUE;
END
$$;


ALTER FUNCTION seguridad.ft_actualizar_parametros(pid_parametro integer, pparametro character varying, pvalor character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: ft_actualizar_permiso(integer, integer, integer, boolean, boolean, boolean, boolean, character varying, date); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_permiso(p_id_permiso integer, p_id_rol integer, p_id_objeto integer, p_permiso_insercion boolean, p_permiso_eliminacion boolean, p_permiso_actualizacion boolean, p_permiso_consultar boolean, p_modificado_por character varying, p_fecha_modificacion date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE 
  seguridad.tbl_ms_permisos 
SET 
  id_rol = p_id_rol,
  id_objeto = p_id_objeto,
  permiso_insercion = p_permiso_insercion,
  permiso_eliminacion = p_permiso_eliminacion,
  permiso_actualizacion = p_permiso_actualizacion,
  permiso_consultar = p_permiso_consultar,
  modificado_por = p_modificado_por,
  fecha_modificacion = p_fecha_modificacion
WHERE 
  id_permiso = p_id_permiso
;
return true;
END;
$$;


ALTER FUNCTION seguridad.ft_actualizar_permiso(p_id_permiso integer, p_id_rol integer, p_id_objeto integer, p_permiso_insercion boolean, p_permiso_eliminacion boolean, p_permiso_actualizacion boolean, p_permiso_consultar boolean, p_modificado_por character varying, p_fecha_modificacion date) OWNER TO postgres;

--
-- Name: ft_actualizar_pregunta(integer, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_pregunta(p_id_pregunta integer, p_pregunta character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
  UPDATE 
  seguridad.tbl_ms_preguntas
SET 
  pregunta = p_pregunta
WHERE 
  id_pregunta = p_id_pregunta
;
return true;
END;
$$;


ALTER FUNCTION seguridad.ft_actualizar_pregunta(p_id_pregunta integer, p_pregunta character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_preguntas_usuario(integer, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_preguntas_usuario(p_id_preguntas_usuario integer, p_respuesta character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN
  UPDATE 
  seguridad.tbl_ms_preguntas_usuario 
SET 
  respuesta = p_respuesta
WHERE 
  id_preguntas_usuario = p_id_preguntas_usuario
;
return true;
END;
$$;


ALTER FUNCTION seguridad.ft_actualizar_preguntas_usuario(p_id_preguntas_usuario integer, p_respuesta character varying) OWNER TO postgres;

--
-- Name: ft_actualizar_rol(integer, character varying, character varying, character varying, date); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_rol(pid_rol integer, prol character varying, pdescripcion character varying, pmodificado_por character varying, pfecha_modificacion date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

BEGIN

UPDATE 
  seguridad.tbl_ms_roles
SET 
  rol = prol,
  descripcion = pdescripcion,
  modificado_por = pmodificado_por,
  fecha_modificacion = pfecha_modificacion
WHERE 
  id_rol = pid_rol
; 
RETURN TRUE;
END
$$;


ALTER FUNCTION seguridad.ft_actualizar_rol(pid_rol integer, prol character varying, pdescripcion character varying, pmodificado_por character varying, pfecha_modificacion date) OWNER TO postgres;

--
-- Name: ft_actualizar_usuario(integer, character varying, integer, integer, character varying, character varying, timestamp without time zone); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_actualizar_usuario(pid_usuario integer, pnombre_usuario character varying, pestado_usuario integer, pid_rol integer, pcorreo_electronico character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

UPDATE 
  seguridad.tbl_ms_usuario 
SET 
  nombre_usuario = pnombre_usuario,
  estado_usuario = pestado_usuario,
  id_rol = pid_rol,
  correo_electronico = pcorreo_electronico,
  modificado_por = pmodificado_por,
  fecha_modificacion = pfecha_modificacion
WHERE 
  id_usuario = pid_usuario
; 
RETURN TRUE;
END
$$;


ALTER FUNCTION seguridad.ft_actualizar_usuario(pid_usuario integer, pnombre_usuario character varying, pestado_usuario integer, pid_rol integer, pcorreo_electronico character varying, pmodificado_por character varying, pfecha_modificacion timestamp without time zone) OWNER TO postgres;

--
-- Name: ft_camb_contra_registro(character varying, character varying, integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_camb_contra_registro(v_pass1 character varying, v_pass2 character varying, v_usuario integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE 
--v_pass_antigua VARCHAR(50);
BEGIN
	
	IF(v_pass1 && v_pass2)  THEN
    -- Registrar nueva contraseña y guardar en el historial.
    INSERT INTO 
                  seguridad.tbl_ms_hist_contrasena
                (
                  id_usuario,
                  contrasena,
                  fecha
                )
                  VALUES (
                    v_usuario,
                    v_pass1,
                    now()
                );
                
    		UPDATE 
              seguridad.tbl_ms_usuario 
            SET 
              contrasena = v_pass1
            WHERE 
              id_usuario = v_usuario;
      
    return 'La contraseña ha sido actualizada correctamente';
    ELSE
    return 'Las contraseñas no coinciden!';
    END IF ;
		
END;
$$;


ALTER FUNCTION seguridad.ft_camb_contra_registro(v_pass1 character varying, v_pass2 character varying, v_usuario integer) OWNER TO postgres;

--
-- Name: ft_desbloqueo(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_desbloqueo(p_usuario character varying) RETURNS TABLE(msg character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
v_usuario RECORD;
msg VARCHAR = 'Usuario o Contraseña incorrecto';
v_id_estado_bloqueado INT;

BEGIN

v_id_estado_bloqueado= (SELECT id FROM seguridad.tbl_ms_usuario_estado WHERE descripcion='Bloqueado' LIMIT 1);

IF(SELECT count(*) FROM seguridad.tbl_ms_usuario WHERE usuario= p_usuario LIMIT 1)=0 THEN
msg='El usuario ingresado no existe!';
RETURN QUERY select 0,'-'::VARCHAR,msg, false,false;
END IF;

SELECT   
estado_usuario INTO v_usuario 
FROM seguridad.tbl_ms_usuario 
WHERE usuario= p_usuario ;
          
    IF v_usuario.estado_usuario=v_id_estado_bloqueado THEN
	msg= 'Su usuario se encuentra bloqueado';
	RETURN QUERY select msg;
	Else
	msg= 'Su usuario no se encuentra bloqueado';
	--Retornamos mensaje al usuario indicando su estado de bloqueado
    return query select msg;  
    END IF;
    
END;
$$;


ALTER FUNCTION seguridad.ft_desbloqueo(p_usuario character varying) OWNER TO postgres;

--
-- Name: ft_getall_permisos_por_usuario(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_getall_permisos_por_usuario(pusuario character varying) RETURNS TABLE(id_permiso integer, id_rol integer, rol character varying, descripcion_rol character varying, id_objeto integer, objeto character varying, descripcion_objeto character varying, permiso_insercion boolean, permiso_eliminacion boolean, permiso_actualizacion boolean, permiso_consultar boolean)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY

	select a.id_permiso
			,a.id_rol
			,c.rol
			,c.descripcion descripcion_rol
			,a.id_objeto
			,b.objeto
			,b.descripcion descripcion_objeto
			,a.permiso_insercion
			,a.permiso_eliminacion
			,a.permiso_actualizacion
			,a.permiso_consultar
	from seguridad.tbl_ms_permisos a 
	inner join seguridad.tbl_ms_objetos b on a.id_objeto=b.id_objeto
	inner join seguridad.tbl_ms_roles c on a.id_rol=c.id_rol
	inner join seguridad.tbl_ms_usuario d on d.id_rol=c.id_rol
	where d.usuario=pusuario;

END;
$$;


ALTER FUNCTION seguridad.ft_getall_permisos_por_usuario(pusuario character varying) OWNER TO postgres;

--
-- Name: ft_getone_bitacora(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_getone_bitacora(v_id_bitacora integer DEFAULT 0) RETURNS TABLE(id_bitacora integer, fecha timestamp without time zone, nombre_usuario character varying, objeto character varying, accion character varying, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select a.id_bitacora, a.fecha , b.nombre_usuario, c.objeto, a.accion , a.descripcion   from 
 seguridad.tbl_ms_bitacora a 
left join seguridad.tbl_ms_usuario b ON a.id_usuario = b.id_usuario
left join seguridad.tbl_ms_objetos c ON a.id_objeto = c.id_objeto
where a.id_bitacora = v_id_bitacora;
END;
$$;


ALTER FUNCTION seguridad.ft_getone_bitacora(v_id_bitacora integer) OWNER TO postgres;

--
-- Name: ft_getone_contrasena(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_getone_contrasena(v_id_hist integer DEFAULT 0) RETURNS TABLE(id_hist integer, nombre_usuario character varying, contrasena character varying, fecha timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY

SELECT 
a.id_hist,
b.nombre_usuario,
a.contrasena,
a.fecha
FROM seguridad.tbl_ms_hist_contrasena a
left join seguridad.tbl_ms_usuario b on a.id_usuario =b.id_usuario
where a.id_hist = v_id_hist;
END;
$$;


ALTER FUNCTION seguridad.ft_getone_contrasena(v_id_hist integer) OWNER TO postgres;

--
-- Name: ft_getone_permiso(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_getone_permiso(v_id_permiso integer DEFAULT 0) RETURNS TABLE(id_permiso integer, rol character varying, objeto character varying, permiso_insercion boolean, permiso_eliminacion boolean, permiso_actualizacion boolean, permiso_consultar boolean, creado_por character varying, modificado_por character varying, fecha_creacion date, fecha_modificacion date)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY

SELECT 
a.id_permiso, 
b.rol, 
c.objeto, 
a.permiso_insercion, 
a.permiso_eliminacion, 
a.permiso_actualizacion, 
a.permiso_consultar, 
a.creado_por,
a.modificado_por,  
a.fecha_creacion, 
a.fecha_modificacion 
FROM seguridad.tbl_ms_permisos a
left join seguridad.tbl_ms_roles b ON a.id_rol = b.id_rol
left join seguridad.tbl_ms_objetos c ON a.id_objeto = c.id_objeto
where a.id_permiso = v_id_permiso;

END;
$$;


ALTER FUNCTION seguridad.ft_getone_permiso(v_id_permiso integer) OWNER TO postgres;

--
-- Name: ft_getone_pregunta_usuario(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_getone_pregunta_usuario(v_id_preguntas_usuario integer DEFAULT 0) RETURNS TABLE(id_preguntas_usuario integer, nombre_usuario character varying, pregunta character varying, respuesta character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select 
a.id_preguntas_usuario,
b.nombre_usuario,
c.pregunta,
a.respuesta
from seguridad.tbl_ms_preguntas_usuario a
left join seguridad.tbl_ms_usuario b on a.id_usuario = b.id_usuario
left join seguridad.tbl_ms_preguntas c on a.id_pregunta =c.id_pregunta
where a.id_preguntas_usuario = v_id_preguntas_usuario;
END;
$$;


ALTER FUNCTION seguridad.ft_getone_pregunta_usuario(v_id_preguntas_usuario integer) OWNER TO postgres;

--
-- Name: ft_insert_autoregistro(character varying, character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_insert_autoregistro(v_nombre_usuario character varying, v_email character varying, v_pass character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

INSERT INTO 
  seguridad.tbl_ms_usuario
(
  usuurio,
  nombre_usuario,
  estado_usuario,
  contrasena,
  id_rol,
  correo_electronico,
  creado_por
)
VALUES (
  v_usaurio,
  v_nombre_usuario,
  1,
  v_contrasena,
  5,
  v_correo_electronico,
  'AUTOREGISTRO'
);
END;
$$;


ALTER FUNCTION seguridad.ft_insert_autoregistro(v_nombre_usuario character varying, v_email character varying, v_pass character varying) OWNER TO postgres;

--
-- Name: ft_insert_autoregistro(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_insert_autoregistro(v_usuario character varying, v_nombre_usuario character varying, v_correo_electronico character varying, v_contrasena character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

INSERT INTO 
  seguridad.tbl_ms_usuario
(
  usuario,
  nombre_usuario,
  estado_usuario,
  contrasena,
  id_rol,
  correo_electronico,
  creado_por
)
VALUES (
  v_usuario,
  v_nombre_usuario,
  1,
  v_contrasena,
  5,
  v_correo_electronico,
  'AUTOREGISTRO'
);
END;
$$;


ALTER FUNCTION seguridad.ft_insert_autoregistro(v_usuario character varying, v_nombre_usuario character varying, v_correo_electronico character varying, v_contrasena character varying) OWNER TO postgres;

--
-- Name: ft_login(character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_login(p_user character varying, p_pass character varying) RETURNS TABLE(usuario_id integer, nombre character varying, msg character varying, login boolean, primer_login boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
v_usuario RECORD;
permitir_login BOOLEAN = false;
msg VARCHAR = 'Usuario o Contraseña incorrecto';
v_intentos_permitidos VARCHAR;
v_intentos_fallidos_nuevo INT;
v_id_estado_bloqueado INT;
v_id_estado_inactivo INT; --quita
BEGIN
	
	v_id_estado_bloqueado= (SELECT id FROM seguridad.tbl_ms_usuario_estado WHERE descripcion='BLOQUEADO' LIMIT 1);
    
    --quita
    v_id_estado_inactivo= (SELECT id FROM seguridad.tbl_ms_usuario_estado WHERE descripcion='INACTIVO' LIMIT 1);
    
	IF(SELECT count(*) FROM seguridad.tbl_ms_usuario WHERE usuario= p_user LIMIT 1)=0 THEN
    msg='El usuario ingresado no existe!';
    RETURN QUERY select 0,'-'::VARCHAR,msg, false,false;
    
    END IF;

    SELECT   
          id_usuario as id,
          nombre_usuario as nombre,
          estado_usuario as estado,
          contrasena as contrasena,
          id_rol as rol,
          primer_ingreso as primer_ingreso,
          intentos_login as intentos_login INTO v_usuario 
 	FROM seguridad.tbl_ms_usuario WHERE usuario= p_user;
    
	  v_intentos_permitidos = (SELECT seguridad.ft_obtener_parametro('ADMIN_INTENTOS'));
    --comienza esto
        IF v_usuario.estado=v_id_estado_inactivo THEN
     msg= 'Su usuario se encuentra inactivo, por favor comuniquese con el administrador!';
    -- Retornamos mensaje al usuario indicando su estado de bloqueado
    return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    
    IF (v_usuario.rol=2) THEN
     msg= 'Comuniquese con el administrador para que su rol sea asignado!';
    return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    --termina esto
    
    IF v_usuario.intentos_login=v_intentos_permitidos::INT OR v_usuario.estado=v_id_estado_bloqueado THEN
    --Bloquear al Usuario
    msg= 'Su usuario se encuentra bloqueado, por favor comuniquese con el administrador!';
    -- Retornamos mensaje al usuario indicando su estado de bloqueado
    return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    -- validar proceso de login
	--Validar Contraseña
    IF(p_pass=v_usuario.contrasena)THEN
    -- contraseña correcta - VALIDAR ESTADO
    
    UPDATE 
      seguridad.tbl_ms_usuario 
    SET 
      intentos_login = 0,
	  fecha_ultima_conexion= NOW()
    WHERE 
      id_usuario = v_usuario.id;
      
    return query select v_usuario.id,v_usuario.nombre::VARCHAR,'DATOS CORRECTOS'::VARCHAR, true,v_usuario.primer_ingreso::BOOLEAN;
    
    ELSE  
    -- Ingresar intento fallido
    v_intentos_fallidos_nuevo=v_usuario.intentos_login+1;
    
    UPDATE 
      seguridad.tbl_ms_usuario 
    SET 
      intentos_login = v_intentos_fallidos_nuevo
    WHERE 
      id_usuario = v_usuario.id;
      
          IF(v_intentos_fallidos_nuevo=v_intentos_permitidos::INT) THEN
          --BLOQUEAR USUARIO
          UPDATE 
            seguridad.tbl_ms_usuario 
          SET 
            estado_usuario = v_id_estado_bloqueado
          WHERE 
            id_usuario = v_usuario.id;
            msg='Su usuario ha sido bloquedo por el maximo de intentos!';
            return query select v_usuario.id,v_usuario.nombre::VARCHAR,msg, false,false;
            ELSE
            return query select v_usuario.id,v_usuario.nombre::VARCHAR,'Usuario o contraseña incorrectos'::VARCHAR, false,false;
          END IF;
    
    END IF;
        
    END IF;
    
    END IF;
        
    END IF;
END;
$$;


ALTER FUNCTION seguridad.ft_login(p_user character varying, p_pass character varying) OWNER TO postgres;

--
-- Name: ft_obtener_parametro(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_obtener_parametro(p_parametro character varying) RETURNS SETOF character varying
    LANGUAGE plpgsql
    AS $$
BEGIN

RETURN QUERY (SELECT 
  valor
FROM 
  seguridad.tbl_ms_parametros 
WHERE parametro = p_parametro);

END;
$$;


ALTER FUNCTION seguridad.ft_obtener_parametro(p_parametro character varying) OWNER TO postgres;

--
-- Name: ft_obtener_preguntas_primer_login(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_obtener_preguntas_primer_login() RETURNS TABLE(id integer, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
-- v_preguntas int;
BEGIN

	--v_preguntas = (SELECT seguridad.ft_obtener_parametro('admin_preguntas'))::INT;
RETURN QUERY
SELECT 
  id_pregunta,
  pregunta
FROM 
  seguridad.tbl_ms_preguntas ;

END;
$$;


ALTER FUNCTION seguridad.ft_obtener_preguntas_primer_login() OWNER TO postgres;

--
-- Name: ft_select_bitacora(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_bitacora() RETURNS TABLE(id_bitacora integer, fecha timestamp without time zone, nombre_usuario character varying, objeto character varying, accion character varying, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select a.id_bitacora, a.fecha , b.nombre_usuario, c.objeto, a.accion , a.descripcion   from 
 seguridad.tbl_ms_bitacora a 
left join seguridad.tbl_ms_usuario b ON a.id_usuario = b.id_usuario
left join seguridad.tbl_ms_objetos c ON a.id_objeto = c.id_objeto
ORDER BY id_bitacora asc;
END;
$$;


ALTER FUNCTION seguridad.ft_select_bitacora() OWNER TO postgres;

--
-- Name: ft_select_estado(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_estado() RETURNS TABLE(id integer, descripcion character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT * 
FROM seguridad.tbl_ms_usuario_estado ;
END;
$$;


ALTER FUNCTION seguridad.ft_select_estado() OWNER TO postgres;

--
-- Name: ft_select_estados(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_estados() RETURNS TABLE(id_estado integer, estado character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT 
  id as id_estado,
  descripcion AS des
FROM 
  seguridad.tbl_ms_usuario_estado ;
  
END;
$$;


ALTER FUNCTION seguridad.ft_select_estados() OWNER TO postgres;

--
-- Name: ft_select_hist_contrasena(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_hist_contrasena() RETURNS TABLE(id_hist integer, nombre_usuario character varying, contrasena character varying, fecha timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY

SELECT 
a.id_hist,
b.nombre_usuario,
a.contrasena,
a.fecha
FROM seguridad.tbl_ms_hist_contrasena a
left join seguridad.tbl_ms_usuario b on a.id_usuario =b.id_usuario;

END;
$$;


ALTER FUNCTION seguridad.ft_select_hist_contrasena() OWNER TO postgres;

--
-- Name: ft_select_objetos(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_objetos() RETURNS TABLE(id_objeto integer, objeto character varying, descripcion character varying, tipo_objeto character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select * from 
 seguridad.tbl_ms_objetos
 ORDER BY id_objeto asc;

END;
$$;


ALTER FUNCTION seguridad.ft_select_objetos() OWNER TO postgres;

--
-- Name: ft_select_parametros(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_parametros() RETURNS TABLE(id_parametro integer, parametro character varying, valor character varying, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone)
    LANGUAGE plpgsql
    AS $$

BEGIN
return QUERY
SELECT * FROM 
  seguridad.tbl_ms_parametros 
    ORDER BY id_parametro asc;
END;
$$;


ALTER FUNCTION seguridad.ft_select_parametros() OWNER TO postgres;

--
-- Name: ft_select_permisos(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_permisos() RETURNS TABLE(id_permiso integer, rol character varying, objeto character varying, permiso_insercion boolean, permiso_eliminacion boolean, permiso_actualizacion boolean, permiso_consultar boolean, creado_por character varying, modificado_por character varying, fecha_creacion character varying, fecha_modificacion character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY

SELECT 
a.id_permiso, 
b.rol, 
c.objeto, 
a.permiso_insercion, 
a.permiso_eliminacion, 
a.permiso_actualizacion, 
a.permiso_consultar, 
a.creado_por,
a.modificado_por,  
a.fecha_creacion::VARCHAR, 
a.fecha_modificacion::VARCHAR 
FROM seguridad.tbl_ms_permisos a
left join seguridad.tbl_ms_roles b ON a.id_rol = b.id_rol
left join seguridad.tbl_ms_objetos c ON a.id_objeto = c.id_objeto
  ORDER BY a.id_permiso asc;
END;
$$;


ALTER FUNCTION seguridad.ft_select_permisos() OWNER TO postgres;

--
-- Name: ft_select_preguntas(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_preguntas() RETURNS TABLE(id_pregunta integer, pregunta character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
SELECT *
FROM seguridad.tbl_ms_preguntas;


END;
$$;


ALTER FUNCTION seguridad.ft_select_preguntas() OWNER TO postgres;

--
-- Name: ft_select_preguntas_usuario(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_preguntas_usuario() RETURNS TABLE(id_preguntas_usuario integer, nombre_usuario character varying, pregunta character varying, respuesta character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
select 
a.id_preguntas_usuario,
b.nombre_usuario,
c.pregunta,
a.respuesta
from seguridad.tbl_ms_preguntas_usuario a
left join seguridad.tbl_ms_usuario b on a.id_usuario = b.id_usuario
left join seguridad.tbl_ms_preguntas c on a.id_pregunta =c.id_pregunta
  ORDER BY a.id_preguntas_usuario asc;
END;
$$;


ALTER FUNCTION seguridad.ft_select_preguntas_usuario() OWNER TO postgres;

--
-- Name: ft_select_roles(); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_roles() RETURNS TABLE(id_rol integer, rol character varying, descripcion character varying, creado_por character varying, fecha_creacion character varying, modificado_por character varying, fecha_modificacion character varying)
    LANGUAGE plpgsql
    AS $$

BEGIN
RETURN QUERY

select 

a.id_rol,
a.rol,
a.descripcion,
a.creado_por,
a.fecha_creacion::VARCHAR,
a.modificado_por,
a.fecha_modificacion::VARCHAR
from seguridad.tbl_ms_roles a;
  
END;
$$;


ALTER FUNCTION seguridad.ft_select_roles() OWNER TO postgres;

--
-- Name: ft_select_usuarios(integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_select_usuarios(v_id_usuario integer DEFAULT 0) RETURNS TABLE(id_usuario integer, usuario character varying, nombre_usuario character varying, estado_usuario integer, estado character varying, contrasena character varying, id_rol integer, fecha_ultima_conexion timestamp without time zone, preguntas_contestadas integer, primer_ingreso integer, v_fecha_vencimiento date, correo_electronico character varying, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone, rol_usuario character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
IF v_id_usuario=0 THEN
return QUERY
    SELECT 
      u.id_usuario,
      u.usuario,
      u.nombre_usuario,
      u.estado_usuario,
      uestado.descripcion as estado,
      u.contrasena,
      u.id_rol,
      u.fecha_ultima_conexion,
      u.preguntas_contestadas,
      u.primer_ingreso,
      u.fecha_vencimiento,
      u.correo_electronico,
      u.creado_por,
      u.fecha_creacion,
      u.modificado_por,
      u.fecha_modificacion,
      rol.descripcion as rolusuario
    FROM seguridad.tbl_ms_usuario u
    LEFT JOIN seguridad.tbl_ms_roles rol
    ON rol.id_rol=u.id_rol
    LEFT JOIN seguridad.tbl_ms_usuario_estado uestado
    ON uestado.id=u.estado_usuario
      ORDER BY u.id_usuario asc;
ELSE
  return QUERY
  SELECT 
  u.id_usuario,
   u.usuario,
   u.nombre_usuario,
    u.estado_usuario,
    uestado.descripcion as estado,
    u.contrasena,
   u.id_rol,
   u.fecha_ultima_conexion,
   u.preguntas_contestadas,
    u.primer_ingreso,
    u.fecha_vencimiento,
    u.correo_electronico,
    u.creado_por,
    u.fecha_creacion,
    u.modificado_por,
    u.fecha_modificacion,
    rol.descripcion as rol_usuario
  FROM seguridad.tbl_ms_usuario u
  LEFT JOIN seguridad.tbl_ms_roles rol
  ON rol.id_rol=u.id_rol
  LEFT JOIN seguridad.tbl_ms_usuario_estado uestado
  ON uestado.id=u.estado_usuario
  WHERE u.id_usuario=v_id_usuario;
END IF;
END;
$$;


ALTER FUNCTION seguridad.ft_select_usuarios(v_id_usuario integer) OWNER TO postgres;

--
-- Name: ft_validate_current_password(integer, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_validate_current_password(p_id integer, p_pass character varying) RETURNS TABLE(usuario_id integer, nombre character varying, msg character varying, login boolean, primer_login boolean)
    LANGUAGE plpgsql
    AS $$

DECLARE
v_usuario RECORD;
permitir_login BOOLEAN = false;
msg VARCHAR = 'Usuario o Contraseña incorrecto';
v_intentos_permitidos VARCHAR;
v_intentos_fallidos_nuevo INT;
v_id_estado_bloqueado INT;
v_id_estado_inactivo INT; --quita
BEGIN
	
	v_id_estado_bloqueado= (SELECT id FROM seguridad.tbl_ms_usuario_estado WHERE descripcion='Bloqueado' LIMIT 1);
    
    --quita
    v_id_estado_inactivo= (SELECT id FROM seguridad.tbl_ms_usuario_estado WHERE descripcion='INACTIVO' LIMIT 1);
    
	IF(SELECT count(*) FROM seguridad.tbl_ms_usuario WHERE id_usuario= p_id LIMIT 1)=0 THEN
    msg='El usuario ingresado no existe!';
    RETURN QUERY select 0,'-'::VARCHAR,msg, false,false;
    
    END IF;

    SELECT   
          id_usuario as id,
          nombre_usuario as nombre,
          estado_usuario as estado,
          contrasena as contrasena,
          id_rol as rol,
          primer_ingreso as primer_ingreso,
          intentos_login as intentos_login INTO v_usuario 
 	FROM seguridad.tbl_ms_usuario WHERE id_usuario= p_id;
    
	  v_intentos_permitidos = (SELECT seguridad.ft_obtener_parametro('ADMIN_INTENTOS'));
    --comienza esto
        IF v_usuario.estado=v_id_estado_inactivo THEN
     msg= 'Su usuario se encuentra inactivo, por favor comuniquese con el administrador!';
    -- Retornamos mensaje al usuario indicando su estado de bloqueado
    return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    
    IF (v_usuario.rol=5) THEN
     msg= 'Comuniquese con el administrador para que su rol sea asignado!';
    return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    --termina esto
    
    IF v_usuario.intentos_login=v_intentos_permitidos::INT OR v_usuario.estado=v_id_estado_bloqueado THEN
		--Bloquear al Usuario
		msg= 'Su usuario se encuentra bloqueado, por favor comuniquese con el administrador!';
		-- Retornamos mensaje al usuario indicando su estado de bloqueado
		return query select 0,''::VARCHAR,msg, false,false;
    ELSE
    -- validar proceso de login
	--Validar Contraseña
    IF(p_pass=v_usuario.contrasena)THEN
    -- contraseña correcta - VALIDAR ESTADO
    
    
      
    return query select v_usuario.id,v_usuario.nombre::VARCHAR,'DATOS CORRECTOS'::VARCHAR, true,v_usuario.primer_ingreso::BOOLEAN;
    
    ELSE  
    -- Ingresar intento fallido
    v_intentos_fallidos_nuevo=v_usuario.intentos_login+1;
    
   
      
          IF(v_intentos_fallidos_nuevo=v_intentos_permitidos::INT) THEN
          --BLOQUEAR USUARIO
          
            return query select v_usuario.id,v_usuario.nombre::VARCHAR,msg, false,false;
            ELSE
            return query select v_usuario.id,v_usuario.nombre::VARCHAR,'Usuario o contraseña incorrectos'::VARCHAR, false,false;
          END IF;
    
    END IF;
        
    END IF;
    
    END IF;
        
    END IF;
END;
$$;


ALTER FUNCTION seguridad.ft_validate_current_password(p_id integer, p_pass character varying) OWNER TO postgres;

--
-- Name: ft_validate_pin(integer, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.ft_validate_pin(pid_usuario integer, ppin character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

DECLARE
v_count integer = 0;
BEGIN
	select count(*) into v_count from seguridad.tbl_ms_usuario where id_usuario=pid_usuario and pin=ppin;
	if v_count = 0 then
		return false;
	else 
		return true;
	end if;
END;
$$;


ALTER FUNCTION seguridad.ft_validate_pin(pid_usuario integer, ppin character varying) OWNER TO postgres;

--
-- Name: get_one_usuario(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.get_one_usuario(v_usuario character varying) RETURNS TABLE(id_usuario integer, usuario character varying, nombre_usuario character varying, estado_usuario integer, estado character varying, contrasena character varying, id_rol integer, fecha_ultima_conexion timestamp without time zone, preguntas_contestadas integer, primer_ingreso integer, fecha_vencimiento date, correo_electronico character varying, creado_por character varying, fecha_creacion timestamp without time zone, modificado_por character varying, fecha_modificacion timestamp without time zone, rolusuario character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
 return QUERY
    SELECT 
      a.id_usuario,
      a.usuario,
      a.nombre_usuario,
      a.estado_usuario,
      c.descripcion as estado,
      a.contrasena,
      a.id_rol,
      a.fecha_ultima_conexion,
      a.preguntas_contestadas,
      a.primer_ingreso,
      a.fecha_vencimiento,
      a.correo_electronico,
      a.creado_por,
      a.fecha_creacion,
      a.modificado_por,
      a.fecha_modificacion,
      b.descripcion as rolusuario
    FROM seguridad.tbl_ms_usuario a
    LEFT JOIN seguridad.tbl_ms_roles b ON a.id_rol=b.id_rol
    LEFT JOIN seguridad.tbl_ms_usuario_estado c ON a.estado_usuario=c.id
    WHERE a.usuario = v_usuario
      ORDER BY a.id_usuario asc;
END;
$$;


ALTER FUNCTION seguridad.get_one_usuario(v_usuario character varying) OWNER TO postgres;

--
-- Name: sp_bitacora(character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_bitacora(v_accion character varying, v_descripcion character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
 INSERT INTO 
  seguridad.tbl_ms_bitacora
(
  accion,
  descripcion
)
VALUES (
  v_accion,
  v_descripcion
);
END;
$$;


ALTER FUNCTION seguridad.sp_bitacora(v_accion character varying, v_descripcion character varying) OWNER TO postgres;

--
-- Name: sp_insert_estado_usuario(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_estado_usuario(v_descripcion character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  seguridad.tbl_ms_usuario_estado
(
  descripcion
)
VALUES (
v_descripcion
);
END;
$$;


ALTER FUNCTION seguridad.sp_insert_estado_usuario(v_descripcion character varying) OWNER TO postgres;

--
-- Name: sp_insert_hist_contrasena(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_hist_contrasena(v_contrasena character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

  INSERT INTO 
    seguridad.tbl_ms_hist_contrasena
  (
    contrasena
  )
  VALUES (
    v_contrasena
  );
  
END;
$$;


ALTER FUNCTION seguridad.sp_insert_hist_contrasena(v_contrasena character varying) OWNER TO postgres;

--
-- Name: sp_insert_objetos(character varying, character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_objetos(v_objeto character varying, v_descripcion character varying, v_tipo_objeto character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
INSERT INTO 
  seguridad.tbl_ms_objetos
(
  objeto,
  descripcion,
  tipo_objeto
)
VALUES (
  v_objeto,
  v_descripcion,
  v_tipo_objeto
);
END;
$$;


ALTER FUNCTION seguridad.sp_insert_objetos(v_objeto character varying, v_descripcion character varying, v_tipo_objeto character varying) OWNER TO postgres;

--
-- Name: sp_insert_parametros(character varying, character varying, character varying, timestamp without time zone); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_parametros(v_parametro character varying, v_valor character varying, v_creado_por character varying, v_fecha_creacion timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
 INSERT INTO 
  seguridad.tbl_ms_parametros
(
  parametro,
  valor,
  creado_por,
  fecha_creacion
)
VALUES (
  v_parametro,
  v_valor,
  v_creado_por,
  v_fecha_creacion
);

END;
$$;


ALTER FUNCTION seguridad.sp_insert_parametros(v_parametro character varying, v_valor character varying, v_creado_por character varying, v_fecha_creacion timestamp without time zone) OWNER TO postgres;

--
-- Name: sp_insert_permisos(boolean, boolean, boolean, boolean, character varying, date, integer, integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_permisos(v_permiso_insercion boolean, v_permiso_eliminacion boolean, v_permiso_actualizacion boolean, v_permiso_consultar boolean, v_creado_por character varying, v_fecha_creacion date, v_id_rol integer, v_id_objeto integer) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
INSERT INTO 
  seguridad.tbl_ms_permisos
(
  id_rol,
  id_objeto,
  permiso_insercion,
  permiso_eliminacion,
  permiso_actualizacion,
  permiso_consultar,
  creado_por,
 fecha_creacion
)
VALUES (
  v_id_rol,
  v_id_objeto,
v_permiso_insercion,
  v_permiso_eliminacion,
  v_permiso_actualizacion,
  v_permiso_consultar,
  v_creado_por,
v_fecha_creacion
);
END;
$$;


ALTER FUNCTION seguridad.sp_insert_permisos(v_permiso_insercion boolean, v_permiso_eliminacion boolean, v_permiso_actualizacion boolean, v_permiso_consultar boolean, v_creado_por character varying, v_fecha_creacion date, v_id_rol integer, v_id_objeto integer) OWNER TO postgres;

--
-- Name: sp_insert_pregunta(character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_pregunta(vp_pregunta character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

  INSERT INTO 
    seguridad.tbl_ms_preguntas
  (
    pregunta
  )
  VALUES (
    vp_pregunta
  );
  
END;
$$;


ALTER FUNCTION seguridad.sp_insert_pregunta(vp_pregunta character varying) OWNER TO postgres;

--
-- Name: sp_insert_preguntas_usuario(integer, integer, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_preguntas_usuario(pid_usuario integer, pid_pregunta integer, prespuesta character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN
	
	delete from seguridad.tbl_ms_preguntas_usuario where id_usuario=pid_usuario and id_pregunta=pid_pregunta;

  INSERT INTO 
    seguridad.tbl_ms_preguntas_usuario
  (
    id_usuario,
	  id_pregunta,
	  respuesta
  )
  VALUES (
    pid_usuario,
	  pid_pregunta,
	  prespuesta
  );
  
END;
$$;


ALTER FUNCTION seguridad.sp_insert_preguntas_usuario(pid_usuario integer, pid_pregunta integer, prespuesta character varying) OWNER TO postgres;

--
-- Name: sp_insert_rol(character varying, character varying, character varying, date); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_rol(v_rol character varying, v_descripcion character varying, v_creado_por character varying, v_fecha_creacion date) RETURNS void
    LANGUAGE plpgsql
    AS $$

BEGIN

insert into seguridad.tbl_ms_roles(
rol,
descripcion,
creado_por,
fecha_creacion
)
values (
v_rol,
v_descripcion,
v_creado_por,
v_fecha_creacion
);

END;
$$;


ALTER FUNCTION seguridad.sp_insert_rol(v_rol character varying, v_descripcion character varying, v_creado_por character varying, v_fecha_creacion date) OWNER TO postgres;

--
-- Name: sp_insert_usuario(character varying, character varying, integer, integer, character varying, character varying); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_insert_usuario(v_nombre_usuario character varying, v_pass character varying, v_id_rol integer, v_estado integer, v_email character varying, v_creado_por character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN

IF (v_estado is NULL) THEN 
v_estado=1;
END IF;
IF (v_id_rol is NULL) THEN 
v_id_rol=5;
END IF;
IF (v_creado_por is NULL) THEN 
v_creado_por=v_nombre_usuario;
END IF;

INSERT INTO 
  seguridad.tbl_ms_usuario
(
  nombre_usuario,
  estado_usuario,
  contrasena,
  id_rol,
  correo_electronico,
  creado_por
)
VALUES (
  v_nombre_usuario,
  v_estado,
  v_pass,
  v_id_rol,
  v_email,
  v_creado_por
);
END;
$$;


ALTER FUNCTION seguridad.sp_insert_usuario(v_nombre_usuario character varying, v_pass character varying, v_id_rol integer, v_estado integer, v_email character varying, v_creado_por character varying) OWNER TO postgres;

--
-- Name: sp_registrar_cambio_pass(character varying, character varying, integer); Type: FUNCTION; Schema: seguridad; Owner: postgres
--

CREATE FUNCTION seguridad.sp_registrar_cambio_pass(v_pass1 character varying, v_pass2 character varying, v_uduario integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE 
--v_pass_antigua VARCHAR(50);
BEGIN
	
	IF(v_pass1 = v_pass2)  THEN
    -- Registrar nueva contraseña y guardar en el historial.
    INSERT INTO 
                  seguridad.tbl_ms_hist_contrasena
                (
                  id_usuario,
                  contrasena,
                  fecha
                )
                  VALUES (
                    v_uduario,
                    (
                     SELECT *
                     FROM tbl_ms_usuario 
                     WHERE id_usuario=v_uduario
                     ),
                    now()
                );
                
    		UPDATE 
              seguridad.tbl_ms_usuario 
            SET 
              contrasena = v_pass1
            WHERE 
              id_usuario = v_uduario;
      
    return 'La contraseña ha sido actualizada';
    ELSE
    return 'Las contraseñas no coinciden!';
    --Retornar mensaje de contraseñas no coinciden.
    END IF ;
		
END;
$$;


ALTER FUNCTION seguridad.sp_registrar_cambio_pass(v_pass1 character varying, v_pass2 character varying, v_uduario integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_catalogo_cuenta; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_catalogo_cuenta (
    id_cuenta integer NOT NULL,
    id_usuario integer,
    codigo_cuenta character varying(20),
    nombre_cuenta character varying(60),
    id_categoria integer,
    id_destino_cuenta integer,
    saldo numeric(15,2) DEFAULT 0
);


ALTER TABLE contabilidad.tbl_catalogo_cuenta OWNER TO postgres;

--
-- Name: tbl_catalogo_cuenta_id_cuenta_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_catalogo_cuenta_id_cuenta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_catalogo_cuenta_id_cuenta_seq OWNER TO postgres;

--
-- Name: tbl_catalogo_cuenta_id_cuenta_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_catalogo_cuenta_id_cuenta_seq OWNED BY contabilidad.tbl_catalogo_cuenta.id_cuenta;


--
-- Name: tbl_categoria; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_categoria (
    id_categoria integer NOT NULL,
    nombre_categoria character varying(40)
);


ALTER TABLE contabilidad.tbl_categoria OWNER TO postgres;

--
-- Name: tbl_categoria_id_categoria_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_categoria_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_categoria_id_categoria_seq OWNER TO postgres;

--
-- Name: tbl_categoria_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_categoria_id_categoria_seq OWNED BY contabilidad.tbl_categoria.id_categoria;


--
-- Name: tbl_destino_cuenta; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_destino_cuenta (
    id_destino_cuenta integer NOT NULL,
    id_cuenta integer,
    id_informe_financiero integer
);


ALTER TABLE contabilidad.tbl_destino_cuenta OWNER TO postgres;

--
-- Name: tbl_destino_cuenta_id_destino_cuenta_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_destino_cuenta_id_destino_cuenta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_destino_cuenta_id_destino_cuenta_seq OWNER TO postgres;

--
-- Name: tbl_destino_cuenta_id_destino_cuenta_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_destino_cuenta_id_destino_cuenta_seq OWNED BY contabilidad.tbl_destino_cuenta.id_destino_cuenta;


--
-- Name: tbl_estado; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_estado (
    id_estado integer NOT NULL,
    tipo_estado character varying(40)
);


ALTER TABLE contabilidad.tbl_estado OWNER TO postgres;

--
-- Name: tbl_estado_id_estado_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_estado_id_estado_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_estado_id_estado_seq OWNER TO postgres;

--
-- Name: tbl_estado_id_estado_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_estado_id_estado_seq OWNED BY contabilidad.tbl_estado.id_estado;


--
-- Name: tbl_informe_financiero; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_informe_financiero (
    id_informe_financiero integer NOT NULL,
    descripcion character varying(40)
);


ALTER TABLE contabilidad.tbl_informe_financiero OWNER TO postgres;

--
-- Name: tbl_informe_financiero_id_informe_financiero_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_informe_financiero_id_informe_financiero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_informe_financiero_id_informe_financiero_seq OWNER TO postgres;

--
-- Name: tbl_informe_financiero_id_informe_financiero_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_informe_financiero_id_informe_financiero_seq OWNED BY contabilidad.tbl_informe_financiero.id_informe_financiero;


--
-- Name: tbl_libro_diario_id_libro_diario_deta_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_libro_diario_id_libro_diario_deta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_libro_diario_id_libro_diario_deta_seq OWNER TO postgres;

--
-- Name: tbl_libro_diario_detalle; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_libro_diario_detalle (
    id_libro_diario_deta bigint DEFAULT nextval('contabilidad.tbl_libro_diario_id_libro_diario_deta_seq'::regclass) NOT NULL,
    id_libro_diario_enca bigint NOT NULL,
    id_subcuenta integer,
    monto_debe numeric(15,2),
    monto_haber numeric(15,2),
    sinopsis character varying(100),
    id_sucursal integer,
    id_centro_costo integer
);


ALTER TABLE contabilidad.tbl_libro_diario_detalle OWNER TO postgres;

--
-- Name: tbl_libro_diario_encabezado; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_libro_diario_encabezado (
    id_libro_diario_enca bigint NOT NULL,
    id_estado integer DEFAULT 2 NOT NULL,
    descripcion character varying(100),
    fecha date,
    id_usuario integer,
    id_periodo_contable integer
);


ALTER TABLE contabilidad.tbl_libro_diario_encabezado OWNER TO postgres;

--
-- Name: tbl_libro_diario_id_libro_diario_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_libro_diario_id_libro_diario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_libro_diario_id_libro_diario_seq OWNER TO postgres;

--
-- Name: tbl_libro_mayor; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_libro_mayor (
    id_libro_mayor integer NOT NULL,
    id_periodo_contable integer,
    descripcion character varying,
    fecha date,
    id_cuenta integer,
    id_subcuenta integer,
    monto_debe numeric(15,2),
    monto_haber numeric(15,2),
    saldo numeric(15,2)
);


ALTER TABLE contabilidad.tbl_libro_mayor OWNER TO postgres;

--
-- Name: tbl_libro_mayor_id_libro_mayor_deta_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_libro_mayor_id_libro_mayor_deta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_libro_mayor_id_libro_mayor_deta_seq OWNER TO postgres;

--
-- Name: tbl_libro_mayor_id_libro_mayor_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_libro_mayor_id_libro_mayor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_libro_mayor_id_libro_mayor_seq OWNER TO postgres;

--
-- Name: tbl_libro_mayor_id_libro_mayor_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_libro_mayor_id_libro_mayor_seq OWNED BY contabilidad.tbl_libro_mayor.id_libro_mayor;


--
-- Name: tbl_periodo_contable; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_periodo_contable (
    id_periodo_contable integer NOT NULL,
    descripcion_periodo character varying(50),
    fecha_inicial date,
    fecha_final date,
    fecha_creacion date,
    id_usuario integer,
    tipo_periodo character(1),
    estado_periodo character(1)
);


ALTER TABLE contabilidad.tbl_periodo_contable OWNER TO postgres;

--
-- Name: tbl_periodo_contable_id_periodo_contable_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_periodo_contable_id_periodo_contable_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_periodo_contable_id_periodo_contable_seq OWNER TO postgres;

--
-- Name: tbl_periodo_contable_id_periodo_contable_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_periodo_contable_id_periodo_contable_seq OWNED BY contabilidad.tbl_periodo_contable.id_periodo_contable;


--
-- Name: tbl_subcuenta; Type: TABLE; Schema: contabilidad; Owner: postgres
--

CREATE TABLE contabilidad.tbl_subcuenta (
    id_subcuenta integer NOT NULL,
    id_cuenta integer,
    nombre_subcuenta character varying(100),
    saldo numeric(15,2) DEFAULT 0
);


ALTER TABLE contabilidad.tbl_subcuenta OWNER TO postgres;

--
-- Name: tbl_subcuenta_id_subcuenta_seq; Type: SEQUENCE; Schema: contabilidad; Owner: postgres
--

CREATE SEQUENCE contabilidad.tbl_subcuenta_id_subcuenta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contabilidad.tbl_subcuenta_id_subcuenta_seq OWNER TO postgres;

--
-- Name: tbl_subcuenta_id_subcuenta_seq; Type: SEQUENCE OWNED BY; Schema: contabilidad; Owner: postgres
--

ALTER SEQUENCE contabilidad.tbl_subcuenta_id_subcuenta_seq OWNED BY contabilidad.tbl_subcuenta.id_subcuenta;


--
-- Name: json_venta_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.json_venta_detalle (
    detalle_pago jsonb
);


ALTER TABLE public.json_venta_detalle OWNER TO postgres;

--
-- Name: my_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.my_table (
    entrada integer,
    salida integer,
    jsonfile json
);


ALTER TABLE public.my_table OWNER TO postgres;

--
-- Name: tbl_articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_articulo (
    id_articulo integer NOT NULL,
    cod_articulo character varying(16) NOT NULL,
    tipo character(1),
    descripcion character varying(100) NOT NULL,
    descripcion_corta character varying(32) NOT NULL,
    id_impuesto integer NOT NULL,
    id_categoria integer NOT NULL,
    precio numeric(16,2),
    inventario_minimo numeric(16,2) DEFAULT 0,
    inventario_maximo numeric(16,2) DEFAULT 0,
    codigo_barra character varying(32),
    id_unidad_medida integer,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_articulo OWNER TO postgres;

--
-- Name: tbl_articulo_bodega; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_articulo_bodega (
    secuencia_art_bod bigint NOT NULL,
    id_centro_costo integer NOT NULL,
    id_articulo integer NOT NULL,
    en_mano numeric(16,3) DEFAULT 0,
    minimo numeric(16,3) DEFAULT 0,
    maximo numeric(16,3) DEFAULT 0,
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date,
    precio numeric(16,2) DEFAULT 0
);


ALTER TABLE public.tbl_articulo_bodega OWNER TO postgres;

--
-- Name: tbl_articulo_bodega_secuencia_art_bod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_articulo_bodega ALTER COLUMN secuencia_art_bod ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_articulo_bodega_secuencia_art_bod_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_articulo_id_articulo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_articulo ALTER COLUMN id_articulo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_articulo_id_articulo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_categoria (
    id_categoria integer NOT NULL,
    cod_categoria integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date
);


ALTER TABLE public.tbl_categoria OWNER TO postgres;

--
-- Name: tbl_categoria_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_categoria ALTER COLUMN id_categoria ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_categoria_id_categoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_centro_costo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_centro_costo (
    id_centro_costo integer NOT NULL,
    cod_centro_costo character varying(32) NOT NULL,
    descripcion character varying(32) NOT NULL,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_centro_costo OWNER TO postgres;

--
-- Name: tbl_centro_costo_id_centro_costo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_centro_costo ALTER COLUMN id_centro_costo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_centro_costo_id_centro_costo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_compras_det; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_compras_det (
    secuencia_det bigint NOT NULL,
    secuencia_enc bigint NOT NULL,
    id_articulo integer NOT NULL,
    id_unidad_medida integer,
    cantidad numeric(16,0),
    precio_unit numeric(16,3),
    id_impuesto integer,
    monto_impuesto numeric(16,3),
    monto_total numeric(16,3)
);


ALTER TABLE public.tbl_compras_det OWNER TO postgres;

--
-- Name: tbl_compras_det_secuencia_det_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_compras_det ALTER COLUMN secuencia_det ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_compras_det_secuencia_det_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_compras_enc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_compras_enc (
    secuencia_enc bigint NOT NULL,
    id_socio_negocio integer,
    fecha date,
    referencia character varying(100),
    monto_total numeric(16,3),
    monto_impuesto_total numeric(16,3),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date,
    id_usuario integer,
    id_centro_costo integer,
    estado character(1) DEFAULT 1
);


ALTER TABLE public.tbl_compras_enc OWNER TO postgres;

--
-- Name: tbl_compras_enc_secuencia_enc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_compras_enc_secuencia_enc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_compras_enc_secuencia_enc_seq OWNER TO postgres;

--
-- Name: tbl_correlativo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_correlativo (
    id_correlativo integer NOT NULL,
    id_pos integer NOT NULL,
    cai character varying(50),
    sucursal_sar character varying(3),
    terminal_sar character varying(3),
    tipo_documento_sar character varying(2),
    correlativo_inicial integer,
    correlativo_final integer,
    correlativo_actual integer,
    fecha_vencimiento date,
    activo character(1),
    siguiente character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_correlativo OWNER TO postgres;

--
-- Name: tbl_correlativo_id_correlativo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_correlativo ALTER COLUMN id_correlativo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_correlativo_id_correlativo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_descuento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_descuento (
    id_descuento integer NOT NULL,
    cod_descuento integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    porcentaje numeric(16,3) NOT NULL,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_descuento OWNER TO postgres;

--
-- Name: tbl_descuento_id_descuento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_descuento ALTER COLUMN id_descuento ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_descuento_id_descuento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_empresa (
    id_empresa integer NOT NULL,
    descripcion character varying(150) NOT NULL,
    direccion character varying(32),
    telefono character varying(16),
    correo character varying(100),
    rtn character varying(32),
    logo1 text,
    logo2 text,
    logo3 text,
    logo4 text,
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_empresa OWNER TO postgres;

--
-- Name: tbl_empresa_id_empresa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_empresa ALTER COLUMN id_empresa ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_empresa_id_empresa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_impuesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_impuesto (
    id_impuesto integer NOT NULL,
    cod_impuesto integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    porcentaje numeric(16,3) NOT NULL,
    tipo character(1) NOT NULL,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_impuesto OWNER TO postgres;

--
-- Name: tbl_impuesto_id_impuesto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_impuesto ALTER COLUMN id_impuesto ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_impuesto_id_impuesto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_lista_materiales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_lista_materiales (
    id_articulo_padre integer NOT NULL,
    id_articulo_hijo integer NOT NULL,
    cantidad numeric(16,3) NOT NULL,
    comentario character varying(100),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_lista_materiales OWNER TO postgres;

--
-- Name: tbl_mapa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_mapa (
    id_mapa integer NOT NULL,
    cod_mapa integer NOT NULL,
    descripcion character varying(100),
    res_x integer,
    rex_y integer,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_mapa OWNER TO postgres;

--
-- Name: tbl_mapa_id_mapa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_mapa ALTER COLUMN id_mapa ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_mapa_id_mapa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_mesas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_mesas (
    id_mesa integer NOT NULL,
    cod_mesa integer NOT NULL,
    id_mapa integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    pos_x integer,
    pos_y integer,
    estado character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_mesas OWNER TO postgres;

--
-- Name: tbl_mesas_id_mesa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_mesas ALTER COLUMN id_mesa ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_mesas_id_mesa_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_metodo_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_metodo_pago (
    id_metodo_pago integer NOT NULL,
    cod_metodo_pago integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    tipo character(1),
    cuenta_contable character varying(32),
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_metodo_pago OWNER TO postgres;

--
-- Name: tbl_metodo_pago_id_metodo_pago_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_metodo_pago ALTER COLUMN id_metodo_pago ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_metodo_pago_id_metodo_pago_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_modo_pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_modo_pedido (
    id_modo_pedido integer NOT NULL,
    cod_modo_pedido integer NOT NULL,
    descripcion character varying(32) NOT NULL,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date
);


ALTER TABLE public.tbl_modo_pedido OWNER TO postgres;

--
-- Name: tbl_modo_pedido_id_modo_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_modo_pedido ALTER COLUMN id_modo_pedido ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_modo_pedido_id_modo_pedido_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_movimiento_det; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_movimiento_det (
    secuencia_det bigint NOT NULL,
    secuencia_enc bigint NOT NULL,
    id_articulo integer NOT NULL,
    id_unidad_medida integer,
    cantidad numeric(16,0),
    precio_unit numeric(16,3),
    id_impuesto integer,
    monto_impuesto numeric(16,3),
    monto_total numeric(16,3)
);


ALTER TABLE public.tbl_movimiento_det OWNER TO postgres;

--
-- Name: tbl_movimiento_det_secuencia_det_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_movimiento_det ALTER COLUMN secuencia_det ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_movimiento_det_secuencia_det_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_movimiento_enc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_movimiento_enc (
    secuencia_enc bigint NOT NULL,
    tipo character varying(2),
    fecha date,
    id_socio_negocio integer,
    monto_total numeric(16,3),
    monto_impuesto_total numeric(16,3),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date,
    id_usuario integer,
    id_centro_costo integer,
    estado character(1),
    referencia character varying(150)
);


ALTER TABLE public.tbl_movimiento_enc OWNER TO postgres;

--
-- Name: tbl_movimiento_enc_secuencia_enc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_movimiento_enc ALTER COLUMN secuencia_enc ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_movimiento_enc_secuencia_enc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_ms_hist_constrasena; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_ms_hist_constrasena (
    id_hist bigint NOT NULL,
    id_usuario bigint NOT NULL,
    contrasena character varying(65535)
);


ALTER TABLE public.tbl_ms_hist_constrasena OWNER TO postgres;

--
-- Name: tbl_ms_hist_constrasena_id_hist_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_ms_hist_constrasena_id_hist_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_ms_hist_constrasena_id_hist_seq OWNER TO postgres;

--
-- Name: tbl_ms_hist_constrasena_id_hist_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_ms_hist_constrasena_id_hist_seq OWNED BY public.tbl_ms_hist_constrasena.id_hist;


--
-- Name: tbl_ms_hist_constrasena_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_ms_hist_constrasena_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_ms_hist_constrasena_id_usuario_seq OWNER TO postgres;

--
-- Name: tbl_ms_hist_constrasena_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_ms_hist_constrasena_id_usuario_seq OWNED BY public.tbl_ms_hist_constrasena.id_usuario;


--
-- Name: tbl_ms_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_ms_roles (
    id_rol bigint NOT NULL,
    rol character varying(30) NOT NULL,
    descripcion character varying(100) NOT NULL,
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_ms_roles OWNER TO postgres;

--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_ms_roles_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_ms_roles_id_rol_seq OWNER TO postgres;

--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_ms_roles_id_rol_seq OWNED BY public.tbl_ms_roles.id_rol;


--
-- Name: tbl_ms_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_ms_usuario (
    id_usuario bigint NOT NULL,
    usuario character varying(15),
    nombre_usuario character varying(100),
    estado_usuario character varying(100),
    contrasena character varying(65535),
    id_rol bigint,
    fecha_ultima_conexion timestamp without time zone,
    preguntas_contestadas bigint,
    primer_ingreso bigint,
    fecha_vencimiento date,
    correo_electronico character varying(50),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_ms_usuario OWNER TO postgres;

--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_ms_usuario_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_ms_usuario_id_usuario_seq OWNER TO postgres;

--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_ms_usuario_id_usuario_seq OWNED BY public.tbl_ms_usuario.id_usuario;


--
-- Name: tbl_pos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_pos (
    id_pos integer NOT NULL,
    cod_pos character varying(32) NOT NULL,
    descripcion character varying(32) NOT NULL,
    id_sucursal integer,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_pos OWNER TO postgres;

--
-- Name: tbl_pos_id_pos_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_pos ALTER COLUMN id_pos ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_pos_id_pos_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_promo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_promo (
    id_promo integer NOT NULL,
    cod_promo integer NOT NULL,
    desc_promo character varying(25) NOT NULL,
    precio numeric(16,0),
    id_categoria integer,
    valida_hasta date,
    estado character(1),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date
);


ALTER TABLE public.tbl_promo OWNER TO postgres;

--
-- Name: tbl_promo_id_promo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_promo ALTER COLUMN id_promo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_promo_id_promo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_promo_lista; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_promo_lista (
    id_promo integer NOT NULL,
    id_articulo integer NOT NULL
);


ALTER TABLE public.tbl_promo_lista OWNER TO postgres;

--
-- Name: tbl_socio_negocio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_socio_negocio (
    id_socio_negocio integer NOT NULL,
    cod_socio_negocio character varying(32) NOT NULL,
    tipo character(1) NOT NULL,
    descripcion character varying(100) NOT NULL,
    direccion character varying(32),
    telefono character varying(32),
    contacto character varying(100),
    correo character varying(32),
    rtn character varying(32),
    balance numeric(16,0),
    cuenta_contable character varying(32),
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_socio_negocio OWNER TO postgres;

--
-- Name: tbl_socio_negocio_id_socio_negocio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_socio_negocio ALTER COLUMN id_socio_negocio ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_socio_negocio_id_socio_negocio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_sucursal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_sucursal (
    id_sucursal integer NOT NULL,
    cod_sucursal character varying(32) NOT NULL,
    descripcion character varying(32) NOT NULL,
    direccion character varying(32),
    telefono character varying(16),
    rtn character varying(32),
    id_centro_costo integer,
    id_mapa integer,
    activo character(1),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_sucursal OWNER TO postgres;

--
-- Name: tbl_sucursal_id_sucursal_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_sucursal ALTER COLUMN id_sucursal ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_sucursal_id_sucursal_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_unidades_medida; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_unidades_medida (
    id_unidad_medida integer NOT NULL,
    cod_unidad_medida character varying(15) NOT NULL,
    descripcion character varying(32) NOT NULL,
    creado_por character varying(15),
    fecha_creacion timestamp without time zone,
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.tbl_unidades_medida OWNER TO postgres;

--
-- Name: tbl_unidades_medida_id_unidad_medida_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_unidades_medida ALTER COLUMN id_unidad_medida ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_unidades_medida_id_unidad_medida_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_venta_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_venta_detalle (
    secuencia_det bigint NOT NULL,
    secuencia_enc bigint NOT NULL,
    id_articulo integer NOT NULL,
    id_modo_pedido integer,
    precio numeric(16,2) DEFAULT 0,
    cantidad numeric(16,0) DEFAULT 0,
    id_impuesto integer,
    total_impuesto numeric(16,2) DEFAULT 0,
    total numeric(16,2) DEFAULT 0
);


ALTER TABLE public.tbl_venta_detalle OWNER TO postgres;

--
-- Name: tbl_venta_detalle_desc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_venta_detalle_desc (
    secuencia_desc bigint NOT NULL,
    secuencia_det bigint NOT NULL,
    id_articulo integer NOT NULL,
    id_descuento integer NOT NULL,
    monto numeric(16,2)
);


ALTER TABLE public.tbl_venta_detalle_desc OWNER TO postgres;

--
-- Name: tbl_venta_detalle_desc_secuencia_desc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_venta_detalle_desc ALTER COLUMN secuencia_desc ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_venta_detalle_desc_secuencia_desc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_venta_detalle_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_venta_detalle_pago (
    secuencia_pag bigint NOT NULL,
    secuencia_enc bigint NOT NULL,
    id_metodo_pago integer NOT NULL,
    monto numeric(16,2)
);


ALTER TABLE public.tbl_venta_detalle_pago OWNER TO postgres;

--
-- Name: tbl_venta_detalle_pago_secuencia_pag_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_venta_detalle_pago ALTER COLUMN secuencia_pag ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_venta_detalle_pago_secuencia_pag_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_venta_detalle_promo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_venta_detalle_promo (
    secuencia_promo bigint NOT NULL,
    secuencia_det bigint NOT NULL,
    id_articulo integer NOT NULL,
    id_promo integer NOT NULL
);


ALTER TABLE public.tbl_venta_detalle_promo OWNER TO postgres;

--
-- Name: tbl_venta_detalle_promo_secuencia_promo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_venta_detalle_promo ALTER COLUMN secuencia_promo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_venta_detalle_promo_secuencia_promo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_venta_detalle_secuencia_det_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_venta_detalle_secuencia_det_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_venta_detalle_secuencia_det_seq OWNER TO postgres;

--
-- Name: tbl_venta_encabezado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_venta_encabezado (
    secuencia_enc bigint NOT NULL,
    id_sucursal integer NOT NULL,
    cod_sucursal character varying(32) NOT NULL,
    fecha date,
    numero_cuenta integer NOT NULL,
    venta_grabada_15 numeric(16,2),
    venta_grabada_18 numeric(16,2),
    venta_exenta numeric(16,2),
    impuesto_15 numeric(16,2),
    impuesto_18 numeric(16,2),
    venta_total numeric(16,2),
    cai character varying(50),
    correlativo integer,
    rtn character varying(32),
    nombre_cliente character varying(100),
    id_usuario integer,
    id_pos integer,
    estado character(1) DEFAULT 1,
    no_factura character varying(30),
    fecha_limite_emision date
);


ALTER TABLE public.tbl_venta_encabezado OWNER TO postgres;

--
-- Name: tbl_venta_encabezado_secuencia_enc_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_venta_encabezado_secuencia_enc_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_venta_encabezado_secuencia_enc_seq OWNER TO postgres;

--
-- Name: tbl_ms_bitacora; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_bitacora (
    id_bitacora integer NOT NULL,
    fecha timestamp without time zone,
    id_usuario integer,
    id_objeto integer,
    accion character varying(20),
    descripcion character varying(100)
);


ALTER TABLE seguridad.tbl_ms_bitacora OWNER TO postgres;

--
-- Name: tbl_ms_bitacora_id_bitacora_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_bitacora_id_bitacora_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_bitacora_id_bitacora_seq OWNER TO postgres;

--
-- Name: tbl_ms_bitacora_id_bitacora_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_bitacora_id_bitacora_seq OWNED BY seguridad.tbl_ms_bitacora.id_bitacora;


--
-- Name: tbl_ms_hist_contrasena; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_hist_contrasena (
    id_hist integer NOT NULL,
    id_usuario integer,
    contrasena character varying NOT NULL,
    fecha timestamp(0) with time zone DEFAULT now()
);


ALTER TABLE seguridad.tbl_ms_hist_contrasena OWNER TO postgres;

--
-- Name: tbl_ms_hist_contrasena_id_hist_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_hist_contrasena_id_hist_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_hist_contrasena_id_hist_seq OWNER TO postgres;

--
-- Name: tbl_ms_hist_contrasena_id_hist_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_hist_contrasena_id_hist_seq OWNED BY seguridad.tbl_ms_hist_contrasena.id_hist;


--
-- Name: tbl_ms_historic_token; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_historic_token (
    id_token integer NOT NULL,
    status integer,
    token character varying
);


ALTER TABLE seguridad.tbl_ms_historic_token OWNER TO postgres;

--
-- Name: tbl_ms_historic_token_id_token_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_historic_token_id_token_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_historic_token_id_token_seq OWNER TO postgres;

--
-- Name: tbl_ms_historic_token_id_token_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_historic_token_id_token_seq OWNED BY seguridad.tbl_ms_historic_token.id_token;


--
-- Name: tbl_ms_historic_token_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_historic_token_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_historic_token_seq OWNER TO postgres;

--
-- Name: tbl_ms_objetos; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_objetos (
    id_objeto integer NOT NULL,
    objeto character varying(100),
    descripcion character varying(100),
    tipo_objeto character varying(15)
);


ALTER TABLE seguridad.tbl_ms_objetos OWNER TO postgres;

--
-- Name: tbl_ms_objetos_id_objeto_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_objetos_id_objeto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_objetos_id_objeto_seq OWNER TO postgres;

--
-- Name: tbl_ms_objetos_id_objeto_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_objetos_id_objeto_seq OWNED BY seguridad.tbl_ms_objetos.id_objeto;


--
-- Name: tbl_ms_parametros; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_parametros (
    id_parametro integer NOT NULL,
    parametro character varying(50),
    valor character varying(100),
    creado_por character varying(15),
    fecha_creacion timestamp(0) without time zone DEFAULT now(),
    modificado_por character varying(15),
    fecha_modificacion timestamp(0) without time zone DEFAULT now()
);


ALTER TABLE seguridad.tbl_ms_parametros OWNER TO postgres;

--
-- Name: tbl_ms_parametros_id_parametro_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_parametros_id_parametro_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_parametros_id_parametro_seq OWNER TO postgres;

--
-- Name: tbl_ms_parametros_id_parametro_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_parametros_id_parametro_seq OWNED BY seguridad.tbl_ms_parametros.id_parametro;


--
-- Name: tbl_ms_permisos; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_permisos (
    id_permiso integer NOT NULL,
    id_rol integer,
    id_objeto integer NOT NULL,
    permiso_insercion boolean,
    permiso_eliminacion boolean,
    permiso_actualizacion boolean,
    permiso_consultar boolean,
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date
);


ALTER TABLE seguridad.tbl_ms_permisos OWNER TO postgres;

--
-- Name: tbl_ms_permisos_id_permiso_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_permisos_id_permiso_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_permisos_id_permiso_seq OWNER TO postgres;

--
-- Name: tbl_ms_permisos_id_permiso_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_permisos_id_permiso_seq OWNED BY seguridad.tbl_ms_permisos.id_permiso;


--
-- Name: tbl_ms_preguntas; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_preguntas (
    id_pregunta integer NOT NULL,
    pregunta character varying(100)
);


ALTER TABLE seguridad.tbl_ms_preguntas OWNER TO postgres;

--
-- Name: tbl_ms_preguntas_id_pregunta_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_preguntas_id_pregunta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_preguntas_id_pregunta_seq OWNER TO postgres;

--
-- Name: tbl_ms_preguntas_id_pregunta_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_preguntas_id_pregunta_seq OWNED BY seguridad.tbl_ms_preguntas.id_pregunta;


--
-- Name: tbl_ms_preguntas_usuario; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_preguntas_usuario (
    id_preguntas_usuario integer NOT NULL,
    id_usuario integer,
    id_pregunta integer,
    respuesta character varying(100)
);


ALTER TABLE seguridad.tbl_ms_preguntas_usuario OWNER TO postgres;

--
-- Name: COLUMN tbl_ms_preguntas_usuario.id_usuario; Type: COMMENT; Schema: seguridad; Owner: postgres
--

COMMENT ON COLUMN seguridad.tbl_ms_preguntas_usuario.id_usuario IS 'FK  tbl_ms_usuario';


--
-- Name: COLUMN tbl_ms_preguntas_usuario.id_pregunta; Type: COMMENT; Schema: seguridad; Owner: postgres
--

COMMENT ON COLUMN seguridad.tbl_ms_preguntas_usuario.id_pregunta IS 'FK   tbl_ms_preguntas';


--
-- Name: tbl_ms_preguntas_usuario_id_preguntas_usuario_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_preguntas_usuario_id_preguntas_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_preguntas_usuario_id_preguntas_usuario_seq OWNER TO postgres;

--
-- Name: tbl_ms_preguntas_usuario_id_preguntas_usuario_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_preguntas_usuario_id_preguntas_usuario_seq OWNED BY seguridad.tbl_ms_preguntas_usuario.id_preguntas_usuario;


--
-- Name: tbl_ms_roles; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_roles (
    id_rol integer NOT NULL,
    rol character varying(30),
    descripcion character varying(100),
    creado_por character varying(15),
    fecha_creacion date,
    modificado_por character varying(15),
    fecha_modificacion date
);


ALTER TABLE seguridad.tbl_ms_roles OWNER TO postgres;

--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_roles_id_rol_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_roles_id_rol_seq OWNER TO postgres;

--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_roles_id_rol_seq OWNED BY seguridad.tbl_ms_roles.id_rol;


--
-- Name: tbl_ms_usuario; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_usuario (
    id_usuario integer NOT NULL,
    usuario character varying,
    nombre_usuario character varying(100),
    estado_usuario integer,
    contrasena character varying,
    id_rol integer,
    fecha_ultima_conexion timestamp without time zone,
    preguntas_contestadas integer,
    primer_ingreso integer DEFAULT 1,
    fecha_vencimiento date,
    correo_electronico character varying(50),
    creado_por character varying(15),
    fecha_creacion timestamp without time zone DEFAULT now(),
    modificado_por character varying(15),
    fecha_modificacion timestamp without time zone,
    intentos_login integer DEFAULT 0,
    id_sucursal integer,
    pin character varying(4)
);


ALTER TABLE seguridad.tbl_ms_usuario OWNER TO postgres;

--
-- Name: COLUMN tbl_ms_usuario.id_rol; Type: COMMENT; Schema: seguridad; Owner: postgres
--

COMMENT ON COLUMN seguridad.tbl_ms_usuario.id_rol IS 'FK roles de usuario';


--
-- Name: tbl_ms_usuario_estado; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_ms_usuario_estado (
    id integer NOT NULL,
    descripcion character varying(50)
);


ALTER TABLE seguridad.tbl_ms_usuario_estado OWNER TO postgres;

--
-- Name: tbl_ms_usuario_estado_id_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_usuario_estado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_usuario_estado_id_seq OWNER TO postgres;

--
-- Name: tbl_ms_usuario_estado_id_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_usuario_estado_id_seq OWNED BY seguridad.tbl_ms_usuario_estado.id;


--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

CREATE SEQUENCE seguridad.tbl_ms_usuario_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seguridad.tbl_ms_usuario_id_usuario_seq OWNER TO postgres;

--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: seguridad; Owner: postgres
--

ALTER SEQUENCE seguridad.tbl_ms_usuario_id_usuario_seq OWNED BY seguridad.tbl_ms_usuario.id_usuario;


--
-- Name: tbl_respaldo_log; Type: TABLE; Schema: seguridad; Owner: postgres
--

CREATE TABLE seguridad.tbl_respaldo_log (
    id_respaldo_log integer NOT NULL,
    ruta character varying(250)
);


ALTER TABLE seguridad.tbl_respaldo_log OWNER TO postgres;

--
-- Name: tbl_respaldo_log_id_respaldo_log_seq; Type: SEQUENCE; Schema: seguridad; Owner: postgres
--

ALTER TABLE seguridad.tbl_respaldo_log ALTER COLUMN id_respaldo_log ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME seguridad.tbl_respaldo_log_id_respaldo_log_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_catalogo_cuenta id_cuenta; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_catalogo_cuenta ALTER COLUMN id_cuenta SET DEFAULT nextval('contabilidad.tbl_catalogo_cuenta_id_cuenta_seq'::regclass);


--
-- Name: tbl_categoria id_categoria; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_categoria ALTER COLUMN id_categoria SET DEFAULT nextval('contabilidad.tbl_categoria_id_categoria_seq'::regclass);


--
-- Name: tbl_destino_cuenta id_destino_cuenta; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_destino_cuenta ALTER COLUMN id_destino_cuenta SET DEFAULT nextval('contabilidad.tbl_destino_cuenta_id_destino_cuenta_seq'::regclass);


--
-- Name: tbl_estado id_estado; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_estado ALTER COLUMN id_estado SET DEFAULT nextval('contabilidad.tbl_estado_id_estado_seq'::regclass);


--
-- Name: tbl_informe_financiero id_informe_financiero; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_informe_financiero ALTER COLUMN id_informe_financiero SET DEFAULT nextval('contabilidad.tbl_informe_financiero_id_informe_financiero_seq'::regclass);


--
-- Name: tbl_libro_mayor id_libro_mayor; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_mayor ALTER COLUMN id_libro_mayor SET DEFAULT nextval('contabilidad.tbl_libro_mayor_id_libro_mayor_seq'::regclass);


--
-- Name: tbl_periodo_contable id_periodo_contable; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_periodo_contable ALTER COLUMN id_periodo_contable SET DEFAULT nextval('contabilidad.tbl_periodo_contable_id_periodo_contable_seq'::regclass);


--
-- Name: tbl_subcuenta id_subcuenta; Type: DEFAULT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_subcuenta ALTER COLUMN id_subcuenta SET DEFAULT nextval('contabilidad.tbl_subcuenta_id_subcuenta_seq'::regclass);


--
-- Name: tbl_ms_hist_constrasena id_hist; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_hist_constrasena ALTER COLUMN id_hist SET DEFAULT nextval('public.tbl_ms_hist_constrasena_id_hist_seq'::regclass);


--
-- Name: tbl_ms_roles id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_roles ALTER COLUMN id_rol SET DEFAULT nextval('public.tbl_ms_roles_id_rol_seq'::regclass);


--
-- Name: tbl_ms_usuario id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_usuario ALTER COLUMN id_usuario SET DEFAULT nextval('public.tbl_ms_usuario_id_usuario_seq'::regclass);


--
-- Name: tbl_ms_bitacora id_bitacora; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_bitacora ALTER COLUMN id_bitacora SET DEFAULT nextval('seguridad.tbl_ms_bitacora_id_bitacora_seq'::regclass);


--
-- Name: tbl_ms_hist_contrasena id_hist; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_hist_contrasena ALTER COLUMN id_hist SET DEFAULT nextval('seguridad.tbl_ms_hist_contrasena_id_hist_seq'::regclass);


--
-- Name: tbl_ms_historic_token id_token; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_historic_token ALTER COLUMN id_token SET DEFAULT nextval('seguridad.tbl_ms_historic_token_id_token_seq'::regclass);


--
-- Name: tbl_ms_objetos id_objeto; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_objetos ALTER COLUMN id_objeto SET DEFAULT nextval('seguridad.tbl_ms_objetos_id_objeto_seq'::regclass);


--
-- Name: tbl_ms_parametros id_parametro; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_parametros ALTER COLUMN id_parametro SET DEFAULT nextval('seguridad.tbl_ms_parametros_id_parametro_seq'::regclass);


--
-- Name: tbl_ms_permisos id_permiso; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_permisos ALTER COLUMN id_permiso SET DEFAULT nextval('seguridad.tbl_ms_permisos_id_permiso_seq'::regclass);


--
-- Name: tbl_ms_preguntas id_pregunta; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas ALTER COLUMN id_pregunta SET DEFAULT nextval('seguridad.tbl_ms_preguntas_id_pregunta_seq'::regclass);


--
-- Name: tbl_ms_preguntas_usuario id_preguntas_usuario; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas_usuario ALTER COLUMN id_preguntas_usuario SET DEFAULT nextval('seguridad.tbl_ms_preguntas_usuario_id_preguntas_usuario_seq'::regclass);


--
-- Name: tbl_ms_roles id_rol; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_roles ALTER COLUMN id_rol SET DEFAULT nextval('seguridad.tbl_ms_roles_id_rol_seq'::regclass);


--
-- Name: tbl_ms_usuario id_usuario; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario ALTER COLUMN id_usuario SET DEFAULT nextval('seguridad.tbl_ms_usuario_id_usuario_seq'::regclass);


--
-- Name: tbl_ms_usuario_estado id; Type: DEFAULT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario_estado ALTER COLUMN id SET DEFAULT nextval('seguridad.tbl_ms_usuario_estado_id_seq'::regclass);


--
-- Data for Name: tbl_catalogo_cuenta; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_catalogo_cuenta (id_cuenta, id_usuario, codigo_cuenta, nombre_cuenta, id_categoria, id_destino_cuenta, saldo) FROM stdin;
\.
COPY contabilidad.tbl_catalogo_cuenta (id_cuenta, id_usuario, codigo_cuenta, nombre_cuenta, id_categoria, id_destino_cuenta, saldo) FROM '$$PATH$$/4200.dat';

--
-- Data for Name: tbl_categoria; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_categoria (id_categoria, nombre_categoria) FROM stdin;
\.
COPY contabilidad.tbl_categoria (id_categoria, nombre_categoria) FROM '$$PATH$$/4204.dat';

--
-- Data for Name: tbl_destino_cuenta; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_destino_cuenta (id_destino_cuenta, id_cuenta, id_informe_financiero) FROM stdin;
\.
COPY contabilidad.tbl_destino_cuenta (id_destino_cuenta, id_cuenta, id_informe_financiero) FROM '$$PATH$$/4219.dat';

--
-- Data for Name: tbl_estado; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_estado (id_estado, tipo_estado) FROM stdin;
\.
COPY contabilidad.tbl_estado (id_estado, tipo_estado) FROM '$$PATH$$/4202.dat';

--
-- Data for Name: tbl_informe_financiero; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_informe_financiero (id_informe_financiero, descripcion) FROM stdin;
\.
COPY contabilidad.tbl_informe_financiero (id_informe_financiero, descripcion) FROM '$$PATH$$/4206.dat';

--
-- Data for Name: tbl_libro_diario_detalle; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_libro_diario_detalle (id_libro_diario_deta, id_libro_diario_enca, id_subcuenta, monto_debe, monto_haber, sinopsis, id_sucursal, id_centro_costo) FROM stdin;
\.
COPY contabilidad.tbl_libro_diario_detalle (id_libro_diario_deta, id_libro_diario_enca, id_subcuenta, monto_debe, monto_haber, sinopsis, id_sucursal, id_centro_costo) FROM '$$PATH$$/4211.dat';

--
-- Data for Name: tbl_libro_diario_encabezado; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_libro_diario_encabezado (id_libro_diario_enca, id_estado, descripcion, fecha, id_usuario, id_periodo_contable) FROM stdin;
\.
COPY contabilidad.tbl_libro_diario_encabezado (id_libro_diario_enca, id_estado, descripcion, fecha, id_usuario, id_periodo_contable) FROM '$$PATH$$/4217.dat';

--
-- Data for Name: tbl_libro_mayor; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_libro_mayor (id_libro_mayor, id_periodo_contable, descripcion, fecha, id_cuenta, id_subcuenta, monto_debe, monto_haber, saldo) FROM stdin;
\.
COPY contabilidad.tbl_libro_mayor (id_libro_mayor, id_periodo_contable, descripcion, fecha, id_cuenta, id_subcuenta, monto_debe, monto_haber, saldo) FROM '$$PATH$$/4222.dat';

--
-- Data for Name: tbl_periodo_contable; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_periodo_contable (id_periodo_contable, descripcion_periodo, fecha_inicial, fecha_final, fecha_creacion, id_usuario, tipo_periodo, estado_periodo) FROM stdin;
\.
COPY contabilidad.tbl_periodo_contable (id_periodo_contable, descripcion_periodo, fecha_inicial, fecha_final, fecha_creacion, id_usuario, tipo_periodo, estado_periodo) FROM '$$PATH$$/4198.dat';

--
-- Data for Name: tbl_subcuenta; Type: TABLE DATA; Schema: contabilidad; Owner: postgres
--

COPY contabilidad.tbl_subcuenta (id_subcuenta, id_cuenta, nombre_subcuenta, saldo) FROM stdin;
\.
COPY contabilidad.tbl_subcuenta (id_subcuenta, id_cuenta, nombre_subcuenta, saldo) FROM '$$PATH$$/4208.dat';

--
-- Data for Name: json_venta_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.json_venta_detalle (detalle_pago) FROM stdin;
\.
COPY public.json_venta_detalle (detalle_pago) FROM '$$PATH$$/4220.dat';

--
-- Data for Name: my_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.my_table (entrada, salida, jsonfile) FROM stdin;
\.
COPY public.my_table (entrada, salida, jsonfile) FROM '$$PATH$$/4216.dat';

--
-- Data for Name: tbl_articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_articulo (id_articulo, cod_articulo, tipo, descripcion, descripcion_corta, id_impuesto, id_categoria, precio, inventario_minimo, inventario_maximo, codigo_barra, id_unidad_medida, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_articulo (id_articulo, cod_articulo, tipo, descripcion, descripcion_corta, id_impuesto, id_categoria, precio, inventario_minimo, inventario_maximo, codigo_barra, id_unidad_medida, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4173.dat';

--
-- Data for Name: tbl_articulo_bodega; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_articulo_bodega (secuencia_art_bod, id_centro_costo, id_articulo, en_mano, minimo, maximo, creado_por, fecha_creacion, modificado_por, fecha_modificacion, precio) FROM stdin;
\.
COPY public.tbl_articulo_bodega (secuencia_art_bod, id_centro_costo, id_articulo, en_mano, minimo, maximo, creado_por, fecha_creacion, modificado_por, fecha_modificacion, precio) FROM '$$PATH$$/4180.dat';

--
-- Data for Name: tbl_categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_categoria (id_categoria, cod_categoria, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_categoria (id_categoria, cod_categoria, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4171.dat';

--
-- Data for Name: tbl_centro_costo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_centro_costo (id_centro_costo, cod_centro_costo, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_centro_costo (id_centro_costo, cod_centro_costo, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4155.dat';

--
-- Data for Name: tbl_compras_det; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_compras_det (secuencia_det, secuencia_enc, id_articulo, id_unidad_medida, cantidad, precio_unit, id_impuesto, monto_impuesto, monto_total) FROM stdin;
\.
COPY public.tbl_compras_det (secuencia_det, secuencia_enc, id_articulo, id_unidad_medida, cantidad, precio_unit, id_impuesto, monto_impuesto, monto_total) FROM '$$PATH$$/4178.dat';

--
-- Data for Name: tbl_compras_enc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_compras_enc (secuencia_enc, id_socio_negocio, fecha, referencia, monto_total, monto_impuesto_total, creado_por, fecha_creacion, modificado_por, fecha_modificacion, id_usuario, id_centro_costo, estado) FROM stdin;
\.
COPY public.tbl_compras_enc (secuencia_enc, id_socio_negocio, fecha, referencia, monto_total, monto_impuesto_total, creado_por, fecha_creacion, modificado_por, fecha_modificacion, id_usuario, id_centro_costo, estado) FROM '$$PATH$$/4177.dat';

--
-- Data for Name: tbl_correlativo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_correlativo (id_correlativo, id_pos, cai, sucursal_sar, terminal_sar, tipo_documento_sar, correlativo_inicial, correlativo_final, correlativo_actual, fecha_vencimiento, activo, siguiente, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_correlativo (id_correlativo, id_pos, cai, sucursal_sar, terminal_sar, tipo_documento_sar, correlativo_inicial, correlativo_final, correlativo_actual, fecha_vencimiento, activo, siguiente, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4165.dat';

--
-- Data for Name: tbl_descuento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_descuento (id_descuento, cod_descuento, descripcion, porcentaje, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_descuento (id_descuento, cod_descuento, descripcion, porcentaje, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4167.dat';

--
-- Data for Name: tbl_empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_empresa (id_empresa, descripcion, direccion, telefono, correo, rtn, logo1, logo2, logo3, logo4, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_empresa (id_empresa, descripcion, direccion, telefono, correo, rtn, logo1, logo2, logo3, logo4, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4225.dat';

--
-- Data for Name: tbl_impuesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_impuesto (id_impuesto, cod_impuesto, descripcion, porcentaje, tipo, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_impuesto (id_impuesto, cod_impuesto, descripcion, porcentaje, tipo, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4169.dat';

--
-- Data for Name: tbl_lista_materiales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_lista_materiales (id_articulo_padre, id_articulo_hijo, cantidad, comentario, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_lista_materiales (id_articulo_padre, id_articulo_hijo, cantidad, comentario, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4185.dat';

--
-- Data for Name: tbl_mapa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_mapa (id_mapa, cod_mapa, descripcion, res_x, rex_y, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_mapa (id_mapa, cod_mapa, descripcion, res_x, rex_y, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4157.dat';

--
-- Data for Name: tbl_mesas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_mesas (id_mesa, cod_mesa, id_mapa, descripcion, pos_x, pos_y, estado, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_mesas (id_mesa, cod_mesa, id_mapa, descripcion, pos_x, pos_y, estado, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4159.dat';

--
-- Data for Name: tbl_metodo_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_metodo_pago (id_metodo_pago, cod_metodo_pago, descripcion, tipo, cuenta_contable, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_metodo_pago (id_metodo_pago, cod_metodo_pago, descripcion, tipo, cuenta_contable, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4153.dat';

--
-- Data for Name: tbl_modo_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_modo_pedido (id_modo_pedido, cod_modo_pedido, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_modo_pedido (id_modo_pedido, cod_modo_pedido, descripcion, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4151.dat';

--
-- Data for Name: tbl_movimiento_det; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_movimiento_det (secuencia_det, secuencia_enc, id_articulo, id_unidad_medida, cantidad, precio_unit, id_impuesto, monto_impuesto, monto_total) FROM stdin;
\.
COPY public.tbl_movimiento_det (secuencia_det, secuencia_enc, id_articulo, id_unidad_medida, cantidad, precio_unit, id_impuesto, monto_impuesto, monto_total) FROM '$$PATH$$/4184.dat';

--
-- Data for Name: tbl_movimiento_enc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_movimiento_enc (secuencia_enc, tipo, fecha, id_socio_negocio, monto_total, monto_impuesto_total, creado_por, fecha_creacion, modificado_por, fecha_modificacion, id_usuario, id_centro_costo, estado, referencia) FROM stdin;
\.
COPY public.tbl_movimiento_enc (secuencia_enc, tipo, fecha, id_socio_negocio, monto_total, monto_impuesto_total, creado_por, fecha_creacion, modificado_por, fecha_modificacion, id_usuario, id_centro_costo, estado, referencia) FROM '$$PATH$$/4182.dat';

--
-- Data for Name: tbl_ms_hist_constrasena; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_ms_hist_constrasena (id_hist, id_usuario, contrasena) FROM stdin;
\.
COPY public.tbl_ms_hist_constrasena (id_hist, id_usuario, contrasena) FROM '$$PATH$$/4126.dat';

--
-- Data for Name: tbl_ms_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_ms_roles (id_rol, rol, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_ms_roles (id_rol, rol, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4121.dat';

--
-- Data for Name: tbl_ms_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_ms_usuario (id_usuario, usuario, nombre_usuario, estado_usuario, contrasena, id_rol, fecha_ultima_conexion, preguntas_contestadas, primer_ingreso, fecha_vencimiento, correo_electronico, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_ms_usuario (id_usuario, usuario, nombre_usuario, estado_usuario, contrasena, id_rol, fecha_ultima_conexion, preguntas_contestadas, primer_ingreso, fecha_vencimiento, correo_electronico, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4123.dat';

--
-- Data for Name: tbl_pos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_pos (id_pos, cod_pos, descripcion, id_sucursal, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_pos (id_pos, cod_pos, descripcion, id_sucursal, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4163.dat';

--
-- Data for Name: tbl_promo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_promo (id_promo, cod_promo, desc_promo, precio, id_categoria, valida_hasta, estado, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_promo (id_promo, cod_promo, desc_promo, precio, id_categoria, valida_hasta, estado, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4175.dat';

--
-- Data for Name: tbl_promo_lista; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_promo_lista (id_promo, id_articulo) FROM stdin;
\.
COPY public.tbl_promo_lista (id_promo, id_articulo) FROM '$$PATH$$/4176.dat';

--
-- Data for Name: tbl_socio_negocio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_socio_negocio (id_socio_negocio, cod_socio_negocio, tipo, descripcion, direccion, telefono, contacto, correo, rtn, balance, cuenta_contable, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_socio_negocio (id_socio_negocio, cod_socio_negocio, tipo, descripcion, direccion, telefono, contacto, correo, rtn, balance, cuenta_contable, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4149.dat';

--
-- Data for Name: tbl_sucursal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_sucursal (id_sucursal, cod_sucursal, descripcion, direccion, telefono, rtn, id_centro_costo, id_mapa, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_sucursal (id_sucursal, cod_sucursal, descripcion, direccion, telefono, rtn, id_centro_costo, id_mapa, activo, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4161.dat';

--
-- Data for Name: tbl_unidades_medida; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_unidades_medida (id_unidad_medida, cod_unidad_medida, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY public.tbl_unidades_medida (id_unidad_medida, cod_unidad_medida, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4147.dat';

--
-- Data for Name: tbl_venta_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_venta_detalle (secuencia_det, secuencia_enc, id_articulo, id_modo_pedido, precio, cantidad, id_impuesto, total_impuesto, total) FROM stdin;
\.
COPY public.tbl_venta_detalle (secuencia_det, secuencia_enc, id_articulo, id_modo_pedido, precio, cantidad, id_impuesto, total_impuesto, total) FROM '$$PATH$$/4189.dat';

--
-- Data for Name: tbl_venta_detalle_desc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_venta_detalle_desc (secuencia_desc, secuencia_det, id_articulo, id_descuento, monto) FROM stdin;
\.
COPY public.tbl_venta_detalle_desc (secuencia_desc, secuencia_det, id_articulo, id_descuento, monto) FROM '$$PATH$$/4193.dat';

--
-- Data for Name: tbl_venta_detalle_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_venta_detalle_pago (secuencia_pag, secuencia_enc, id_metodo_pago, monto) FROM stdin;
\.
COPY public.tbl_venta_detalle_pago (secuencia_pag, secuencia_enc, id_metodo_pago, monto) FROM '$$PATH$$/4188.dat';

--
-- Data for Name: tbl_venta_detalle_promo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_venta_detalle_promo (secuencia_promo, secuencia_det, id_articulo, id_promo) FROM stdin;
\.
COPY public.tbl_venta_detalle_promo (secuencia_promo, secuencia_det, id_articulo, id_promo) FROM '$$PATH$$/4191.dat';

--
-- Data for Name: tbl_venta_encabezado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_venta_encabezado (secuencia_enc, id_sucursal, cod_sucursal, fecha, numero_cuenta, venta_grabada_15, venta_grabada_18, venta_exenta, impuesto_15, impuesto_18, venta_total, cai, correlativo, rtn, nombre_cliente, id_usuario, id_pos, estado, no_factura, fecha_limite_emision) FROM stdin;
\.
COPY public.tbl_venta_encabezado (secuencia_enc, id_sucursal, cod_sucursal, fecha, numero_cuenta, venta_grabada_15, venta_grabada_18, venta_exenta, impuesto_15, impuesto_18, venta_total, cai, correlativo, rtn, nombre_cliente, id_usuario, id_pos, estado, no_factura, fecha_limite_emision) FROM '$$PATH$$/4186.dat';

--
-- Data for Name: tbl_ms_bitacora; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_bitacora (id_bitacora, fecha, id_usuario, id_objeto, accion, descripcion) FROM stdin;
\.
COPY seguridad.tbl_ms_bitacora (id_bitacora, fecha, id_usuario, id_objeto, accion, descripcion) FROM '$$PATH$$/4132.dat';

--
-- Data for Name: tbl_ms_hist_contrasena; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_hist_contrasena (id_hist, id_usuario, contrasena, fecha) FROM stdin;
\.
COPY seguridad.tbl_ms_hist_contrasena (id_hist, id_usuario, contrasena, fecha) FROM '$$PATH$$/4134.dat';

--
-- Data for Name: tbl_ms_historic_token; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_historic_token (id_token, status, token) FROM stdin;
\.
COPY seguridad.tbl_ms_historic_token (id_token, status, token) FROM '$$PATH$$/4196.dat';

--
-- Data for Name: tbl_ms_objetos; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_objetos (id_objeto, objeto, descripcion, tipo_objeto) FROM stdin;
\.
COPY seguridad.tbl_ms_objetos (id_objeto, objeto, descripcion, tipo_objeto) FROM '$$PATH$$/4136.dat';

--
-- Data for Name: tbl_ms_parametros; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_parametros (id_parametro, parametro, valor, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY seguridad.tbl_ms_parametros (id_parametro, parametro, valor, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4140.dat';

--
-- Data for Name: tbl_ms_permisos; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_permisos (id_permiso, id_rol, id_objeto, permiso_insercion, permiso_eliminacion, permiso_actualizacion, permiso_consultar, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY seguridad.tbl_ms_permisos (id_permiso, id_rol, id_objeto, permiso_insercion, permiso_eliminacion, permiso_actualizacion, permiso_consultar, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4144.dat';

--
-- Data for Name: tbl_ms_preguntas; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_preguntas (id_pregunta, pregunta) FROM stdin;
\.
COPY seguridad.tbl_ms_preguntas (id_pregunta, pregunta) FROM '$$PATH$$/4130.dat';

--
-- Data for Name: tbl_ms_preguntas_usuario; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_preguntas_usuario (id_preguntas_usuario, id_usuario, id_pregunta, respuesta) FROM stdin;
\.
COPY seguridad.tbl_ms_preguntas_usuario (id_preguntas_usuario, id_usuario, id_pregunta, respuesta) FROM '$$PATH$$/4146.dat';

--
-- Data for Name: tbl_ms_roles; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_roles (id_rol, rol, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM stdin;
\.
COPY seguridad.tbl_ms_roles (id_rol, rol, descripcion, creado_por, fecha_creacion, modificado_por, fecha_modificacion) FROM '$$PATH$$/4138.dat';

--
-- Data for Name: tbl_ms_usuario; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_usuario (id_usuario, usuario, nombre_usuario, estado_usuario, contrasena, id_rol, fecha_ultima_conexion, preguntas_contestadas, primer_ingreso, fecha_vencimiento, correo_electronico, creado_por, fecha_creacion, modificado_por, fecha_modificacion, intentos_login, id_sucursal, pin) FROM stdin;
\.
COPY seguridad.tbl_ms_usuario (id_usuario, usuario, nombre_usuario, estado_usuario, contrasena, id_rol, fecha_ultima_conexion, preguntas_contestadas, primer_ingreso, fecha_vencimiento, correo_electronico, creado_por, fecha_creacion, modificado_por, fecha_modificacion, intentos_login, id_sucursal, pin) FROM '$$PATH$$/4128.dat';

--
-- Data for Name: tbl_ms_usuario_estado; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_ms_usuario_estado (id, descripcion) FROM stdin;
\.
COPY seguridad.tbl_ms_usuario_estado (id, descripcion) FROM '$$PATH$$/4142.dat';

--
-- Data for Name: tbl_respaldo_log; Type: TABLE DATA; Schema: seguridad; Owner: postgres
--

COPY seguridad.tbl_respaldo_log (id_respaldo_log, ruta) FROM stdin;
\.
COPY seguridad.tbl_respaldo_log (id_respaldo_log, ruta) FROM '$$PATH$$/4227.dat';

--
-- Name: tbl_catalogo_cuenta_id_cuenta_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_catalogo_cuenta_id_cuenta_seq', 156, true);


--
-- Name: tbl_categoria_id_categoria_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_categoria_id_categoria_seq', 50, true);


--
-- Name: tbl_destino_cuenta_id_destino_cuenta_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_destino_cuenta_id_destino_cuenta_seq', 30, true);


--
-- Name: tbl_estado_id_estado_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_estado_id_estado_seq', 9, true);


--
-- Name: tbl_informe_financiero_id_informe_financiero_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_informe_financiero_id_informe_financiero_seq', 16, true);


--
-- Name: tbl_libro_diario_id_libro_diario_deta_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_libro_diario_id_libro_diario_deta_seq', 310, true);


--
-- Name: tbl_libro_diario_id_libro_diario_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_libro_diario_id_libro_diario_seq', 333, true);


--
-- Name: tbl_libro_mayor_id_libro_mayor_deta_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_libro_mayor_id_libro_mayor_deta_seq', 1, false);


--
-- Name: tbl_libro_mayor_id_libro_mayor_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_libro_mayor_id_libro_mayor_seq', 104, true);


--
-- Name: tbl_periodo_contable_id_periodo_contable_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_periodo_contable_id_periodo_contable_seq', 47, true);


--
-- Name: tbl_subcuenta_id_subcuenta_seq; Type: SEQUENCE SET; Schema: contabilidad; Owner: postgres
--

SELECT pg_catalog.setval('contabilidad.tbl_subcuenta_id_subcuenta_seq', 57, true);


--
-- Name: tbl_articulo_bodega_secuencia_art_bod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_articulo_bodega_secuencia_art_bod_seq', 92, true);


--
-- Name: tbl_articulo_id_articulo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_articulo_id_articulo_seq', 51, true);


--
-- Name: tbl_categoria_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_categoria_id_categoria_seq', 104, true);


--
-- Name: tbl_centro_costo_id_centro_costo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_centro_costo_id_centro_costo_seq', 10, true);


--
-- Name: tbl_compras_det_secuencia_det_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_compras_det_secuencia_det_seq', 269, true);


--
-- Name: tbl_compras_enc_secuencia_enc_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_compras_enc_secuencia_enc_seq', 363, true);


--
-- Name: tbl_correlativo_id_correlativo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_correlativo_id_correlativo_seq', 16, true);


--
-- Name: tbl_descuento_id_descuento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_descuento_id_descuento_seq', 22, true);


--
-- Name: tbl_empresa_id_empresa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_empresa_id_empresa_seq', 9, true);


--
-- Name: tbl_impuesto_id_impuesto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_impuesto_id_impuesto_seq', 15, true);


--
-- Name: tbl_mapa_id_mapa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_mapa_id_mapa_seq', 1, false);


--
-- Name: tbl_mesas_id_mesa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_mesas_id_mesa_seq', 1, false);


--
-- Name: tbl_metodo_pago_id_metodo_pago_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_metodo_pago_id_metodo_pago_seq', 13, true);


--
-- Name: tbl_modo_pedido_id_modo_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_modo_pedido_id_modo_pedido_seq', 9, true);


--
-- Name: tbl_movimiento_det_secuencia_det_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_movimiento_det_secuencia_det_seq', 1, false);


--
-- Name: tbl_movimiento_enc_secuencia_enc_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_movimiento_enc_secuencia_enc_seq', 1, false);


--
-- Name: tbl_ms_hist_constrasena_id_hist_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_ms_hist_constrasena_id_hist_seq', 15, true);


--
-- Name: tbl_ms_hist_constrasena_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_ms_hist_constrasena_id_usuario_seq', 1, false);


--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_ms_roles_id_rol_seq', 1, true);


--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_ms_usuario_id_usuario_seq', 1, true);


--
-- Name: tbl_pos_id_pos_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_pos_id_pos_seq', 16, true);


--
-- Name: tbl_promo_id_promo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_promo_id_promo_seq', 1, false);


--
-- Name: tbl_socio_negocio_id_socio_negocio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_socio_negocio_id_socio_negocio_seq', 53, true);


--
-- Name: tbl_sucursal_id_sucursal_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_sucursal_id_sucursal_seq', 36, true);


--
-- Name: tbl_unidades_medida_id_unidad_medida_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_unidades_medida_id_unidad_medida_seq', 23, true);


--
-- Name: tbl_venta_detalle_desc_secuencia_desc_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_venta_detalle_desc_secuencia_desc_seq', 180, true);


--
-- Name: tbl_venta_detalle_pago_secuencia_pag_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_venta_detalle_pago_secuencia_pag_seq', 279, true);


--
-- Name: tbl_venta_detalle_promo_secuencia_promo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_venta_detalle_promo_secuencia_promo_seq', 325, true);


--
-- Name: tbl_venta_detalle_secuencia_det_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_venta_detalle_secuencia_det_seq', 1147, true);


--
-- Name: tbl_venta_encabezado_secuencia_enc_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_venta_encabezado_secuencia_enc_seq', 3533, true);


--
-- Name: tbl_ms_bitacora_id_bitacora_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_bitacora_id_bitacora_seq', 8706, true);


--
-- Name: tbl_ms_hist_contrasena_id_hist_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_hist_contrasena_id_hist_seq', 133, true);


--
-- Name: tbl_ms_historic_token_id_token_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_historic_token_id_token_seq', 186, true);


--
-- Name: tbl_ms_historic_token_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_historic_token_seq', 1, false);


--
-- Name: tbl_ms_objetos_id_objeto_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_objetos_id_objeto_seq', 80, true);


--
-- Name: tbl_ms_parametros_id_parametro_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_parametros_id_parametro_seq', 45, true);


--
-- Name: tbl_ms_permisos_id_permiso_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_permisos_id_permiso_seq', 518, true);


--
-- Name: tbl_ms_preguntas_id_pregunta_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_preguntas_id_pregunta_seq', 136, true);


--
-- Name: tbl_ms_preguntas_usuario_id_preguntas_usuario_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_preguntas_usuario_id_preguntas_usuario_seq', 129, true);


--
-- Name: tbl_ms_roles_id_rol_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_roles_id_rol_seq', 29, true);


--
-- Name: tbl_ms_usuario_estado_id_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_usuario_estado_id_seq', 12, true);


--
-- Name: tbl_ms_usuario_id_usuario_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_ms_usuario_id_usuario_seq', 246, true);


--
-- Name: tbl_respaldo_log_id_respaldo_log_seq; Type: SEQUENCE SET; Schema: seguridad; Owner: postgres
--

SELECT pg_catalog.setval('seguridad.tbl_respaldo_log_id_respaldo_log_seq', 2, true);


--
-- Name: tbl_categoria idx_tbl_categoria_nombre_categoria; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_categoria
    ADD CONSTRAINT idx_tbl_categoria_nombre_categoria UNIQUE (nombre_categoria);


--
-- Name: tbl_catalogo_cuenta tbl_catalogo_cuenta_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_catalogo_cuenta
    ADD CONSTRAINT tbl_catalogo_cuenta_pkey PRIMARY KEY (id_cuenta);


--
-- Name: tbl_categoria tbl_categoria_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_categoria
    ADD CONSTRAINT tbl_categoria_pkey PRIMARY KEY (id_categoria);


--
-- Name: tbl_destino_cuenta tbl_destino_cuenta_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_destino_cuenta
    ADD CONSTRAINT tbl_destino_cuenta_pkey PRIMARY KEY (id_destino_cuenta);


--
-- Name: tbl_estado tbl_estado_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_estado
    ADD CONSTRAINT tbl_estado_pkey PRIMARY KEY (id_estado);


--
-- Name: tbl_informe_financiero tbl_informe_financiero_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_informe_financiero
    ADD CONSTRAINT tbl_informe_financiero_pkey PRIMARY KEY (id_informe_financiero);


--
-- Name: tbl_libro_diario_encabezado tbl_libro_diario_encabezado_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_encabezado
    ADD CONSTRAINT tbl_libro_diario_encabezado_pkey PRIMARY KEY (id_libro_diario_enca);


--
-- Name: tbl_libro_diario_detalle tbl_libro_diario_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_detalle
    ADD CONSTRAINT tbl_libro_diario_pkey PRIMARY KEY (id_libro_diario_deta);


--
-- Name: tbl_libro_mayor tbl_libro_mayor_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_mayor
    ADD CONSTRAINT tbl_libro_mayor_pkey PRIMARY KEY (id_libro_mayor);


--
-- Name: tbl_periodo_contable tbl_periodo_contable_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_periodo_contable
    ADD CONSTRAINT tbl_periodo_contable_pkey PRIMARY KEY (id_periodo_contable);


--
-- Name: tbl_subcuenta tbl_subcuenta_pkey; Type: CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_subcuenta
    ADD CONSTRAINT tbl_subcuenta_pkey PRIMARY KEY (id_subcuenta);


--
-- Name: tbl_articulo_bodega tbl_articulo_bodega_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo_bodega
    ADD CONSTRAINT tbl_articulo_bodega_pkey PRIMARY KEY (secuencia_art_bod, id_centro_costo, id_articulo);


--
-- Name: tbl_articulo tbl_articulo_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo
    ADD CONSTRAINT tbl_articulo_cod_unico UNIQUE (cod_articulo);


--
-- Name: tbl_articulo tbl_articulo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo
    ADD CONSTRAINT tbl_articulo_pkey PRIMARY KEY (id_articulo);


--
-- Name: tbl_categoria tbl_categoria_cod_categoria_unica; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_categoria
    ADD CONSTRAINT tbl_categoria_cod_categoria_unica UNIQUE (cod_categoria);


--
-- Name: tbl_categoria tbl_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_categoria
    ADD CONSTRAINT tbl_categoria_pkey PRIMARY KEY (id_categoria);


--
-- Name: tbl_centro_costo tbl_centro_costo_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_centro_costo
    ADD CONSTRAINT tbl_centro_costo_cod_unico UNIQUE (cod_centro_costo);


--
-- Name: tbl_centro_costo tbl_centro_costo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_centro_costo
    ADD CONSTRAINT tbl_centro_costo_pkey PRIMARY KEY (id_centro_costo);


--
-- Name: tbl_compras_det tbl_compras_det_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_det
    ADD CONSTRAINT tbl_compras_det_pkey PRIMARY KEY (secuencia_det);


--
-- Name: tbl_compras_enc tbl_compras_enc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_enc
    ADD CONSTRAINT tbl_compras_enc_pkey PRIMARY KEY (secuencia_enc);


--
-- Name: tbl_correlativo tbl_correlativo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_correlativo
    ADD CONSTRAINT tbl_correlativo_pkey PRIMARY KEY (id_correlativo);


--
-- Name: tbl_descuento tbl_descuento_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_descuento
    ADD CONSTRAINT tbl_descuento_cod_unico UNIQUE (cod_descuento);


--
-- Name: tbl_descuento tbl_descuento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_descuento
    ADD CONSTRAINT tbl_descuento_pkey PRIMARY KEY (id_descuento);


--
-- Name: tbl_empresa tbl_empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_empresa
    ADD CONSTRAINT tbl_empresa_pkey PRIMARY KEY (id_empresa);


--
-- Name: tbl_impuesto tbl_impuesto_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_impuesto
    ADD CONSTRAINT tbl_impuesto_cod_unico UNIQUE (cod_impuesto);


--
-- Name: tbl_impuesto tbl_impuesto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_impuesto
    ADD CONSTRAINT tbl_impuesto_pkey PRIMARY KEY (id_impuesto);


--
-- Name: tbl_lista_materiales tbl_lista_materiales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_lista_materiales
    ADD CONSTRAINT tbl_lista_materiales_pkey PRIMARY KEY (id_articulo_padre, id_articulo_hijo);


--
-- Name: tbl_mapa tbl_mapa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_mapa
    ADD CONSTRAINT tbl_mapa_pkey PRIMARY KEY (id_mapa);


--
-- Name: tbl_mesas tbl_mesas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_mesas
    ADD CONSTRAINT tbl_mesas_pkey PRIMARY KEY (id_mesa);


--
-- Name: tbl_metodo_pago tbl_metodo_pago_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_metodo_pago
    ADD CONSTRAINT tbl_metodo_pago_cod_unico UNIQUE (cod_metodo_pago);


--
-- Name: tbl_metodo_pago tbl_metodo_pago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_metodo_pago
    ADD CONSTRAINT tbl_metodo_pago_pkey PRIMARY KEY (id_metodo_pago);


--
-- Name: tbl_modo_pedido tbl_modo_pedido_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_modo_pedido
    ADD CONSTRAINT tbl_modo_pedido_cod_unico UNIQUE (cod_modo_pedido);


--
-- Name: tbl_modo_pedido tbl_modo_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_modo_pedido
    ADD CONSTRAINT tbl_modo_pedido_pkey PRIMARY KEY (id_modo_pedido);


--
-- Name: tbl_movimiento_det tbl_movimiento_det_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_det
    ADD CONSTRAINT tbl_movimiento_det_pkey PRIMARY KEY (secuencia_det);


--
-- Name: tbl_movimiento_enc tbl_movimiento_enc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_enc
    ADD CONSTRAINT tbl_movimiento_enc_pkey PRIMARY KEY (secuencia_enc);


--
-- Name: tbl_ms_hist_constrasena tbl_ms_hist_constrasena_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_hist_constrasena
    ADD CONSTRAINT tbl_ms_hist_constrasena_pkey PRIMARY KEY (id_hist);


--
-- Name: tbl_ms_roles tbl_ms_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_roles
    ADD CONSTRAINT tbl_ms_roles_pkey PRIMARY KEY (id_rol);


--
-- Name: tbl_ms_usuario tbl_ms_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_usuario
    ADD CONSTRAINT tbl_ms_usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: tbl_pos tbl_pos_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_pos
    ADD CONSTRAINT tbl_pos_cod_unico UNIQUE (cod_pos);


--
-- Name: tbl_pos tbl_pos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_pos
    ADD CONSTRAINT tbl_pos_pkey PRIMARY KEY (id_pos);


--
-- Name: tbl_promo_lista tbl_promo_lista_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_promo_lista
    ADD CONSTRAINT tbl_promo_lista_pkey PRIMARY KEY (id_articulo, id_promo);


--
-- Name: tbl_promo tbl_promo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_promo
    ADD CONSTRAINT tbl_promo_pkey PRIMARY KEY (id_promo);


--
-- Name: tbl_socio_negocio tbl_socio_negocio_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_socio_negocio
    ADD CONSTRAINT tbl_socio_negocio_cod_unico UNIQUE (cod_socio_negocio);


--
-- Name: tbl_socio_negocio tbl_socio_negocio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_socio_negocio
    ADD CONSTRAINT tbl_socio_negocio_pkey PRIMARY KEY (id_socio_negocio);


--
-- Name: tbl_sucursal tbl_sucursal_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_sucursal
    ADD CONSTRAINT tbl_sucursal_cod_unico UNIQUE (cod_sucursal);


--
-- Name: tbl_sucursal tbl_sucursal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_sucursal
    ADD CONSTRAINT tbl_sucursal_pkey PRIMARY KEY (id_sucursal);


--
-- Name: tbl_unidades_medida tbl_unidades_medida_cod_unico; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_unidades_medida
    ADD CONSTRAINT tbl_unidades_medida_cod_unico UNIQUE (cod_unidad_medida);


--
-- Name: tbl_unidades_medida tbl_unidades_medida_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_unidades_medida
    ADD CONSTRAINT tbl_unidades_medida_pkey PRIMARY KEY (id_unidad_medida);


--
-- Name: tbl_venta_detalle_pago tbl_venta_detalle_pago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_pago
    ADD CONSTRAINT tbl_venta_detalle_pago_pkey PRIMARY KEY (secuencia_pag);


--
-- Name: tbl_venta_detalle tbl_venta_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle
    ADD CONSTRAINT tbl_venta_detalle_pkey PRIMARY KEY (secuencia_det);


--
-- Name: tbl_venta_encabezado tbl_venta_encabezado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_encabezado
    ADD CONSTRAINT tbl_venta_encabezado_pkey PRIMARY KEY (secuencia_enc);


--
-- Name: tbl_ms_bitacora tbl_ms_bitacora_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_bitacora
    ADD CONSTRAINT tbl_ms_bitacora_pkey PRIMARY KEY (id_bitacora);


--
-- Name: tbl_ms_hist_contrasena tbl_ms_hist_contrasena_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_hist_contrasena
    ADD CONSTRAINT tbl_ms_hist_contrasena_pkey PRIMARY KEY (id_hist);


--
-- Name: tbl_ms_historic_token tbl_ms_historic_token_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_historic_token
    ADD CONSTRAINT tbl_ms_historic_token_pkey PRIMARY KEY (id_token);


--
-- Name: tbl_ms_objetos tbl_ms_objetos_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_objetos
    ADD CONSTRAINT tbl_ms_objetos_pkey PRIMARY KEY (id_objeto);


--
-- Name: tbl_ms_parametros tbl_ms_parametros_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_parametros
    ADD CONSTRAINT tbl_ms_parametros_pkey PRIMARY KEY (id_parametro);


--
-- Name: tbl_ms_permisos tbl_ms_permisos_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_permisos
    ADD CONSTRAINT tbl_ms_permisos_pkey PRIMARY KEY (id_permiso);


--
-- Name: tbl_ms_preguntas tbl_ms_preguntas_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas
    ADD CONSTRAINT tbl_ms_preguntas_pkey PRIMARY KEY (id_pregunta);


--
-- Name: tbl_ms_preguntas_usuario tbl_ms_preguntas_usuario_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas_usuario
    ADD CONSTRAINT tbl_ms_preguntas_usuario_pkey PRIMARY KEY (id_preguntas_usuario);


--
-- Name: tbl_ms_roles tbl_ms_roles_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_roles
    ADD CONSTRAINT tbl_ms_roles_pkey PRIMARY KEY (id_rol);


--
-- Name: tbl_ms_usuario_estado tbl_ms_usuario_estado_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario_estado
    ADD CONSTRAINT tbl_ms_usuario_estado_pkey PRIMARY KEY (id);


--
-- Name: tbl_ms_usuario tbl_ms_usuario_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario
    ADD CONSTRAINT tbl_ms_usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: tbl_respaldo_log tbl_respaldo_log_pkey; Type: CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_respaldo_log
    ADD CONSTRAINT tbl_respaldo_log_pkey PRIMARY KEY (id_respaldo_log);


--
-- Name: Idx_tbl_informe_financiero_descripcion; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX "Idx_tbl_informe_financiero_descripcion" ON contabilidad.tbl_informe_financiero USING btree (descripcion);


--
-- Name: Idx_tbl_subcuenta_nombre; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX "Idx_tbl_subcuenta_nombre" ON contabilidad.tbl_subcuenta USING btree (nombre_subcuenta);


--
-- Name: idx_estado_tipo_estado; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX idx_estado_tipo_estado ON contabilidad.tbl_estado USING btree (tipo_estado);


--
-- Name: idx_libro_encabezado_id; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX idx_libro_encabezado_id ON contabilidad.tbl_libro_diario_encabezado USING btree (id_libro_diario_enca);


--
-- Name: idx_tbl_catalogo_cuenta_codigo; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_catalogo_cuenta_codigo ON contabilidad.tbl_catalogo_cuenta USING btree (codigo_cuenta);


--
-- Name: idx_tbl_categoria_nombre; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_categoria_nombre ON contabilidad.tbl_categoria USING btree (nombre_categoria);


--
-- Name: idx_tbl_libro_mayor_ip_periodo_contable; Type: INDEX; Schema: contabilidad; Owner: postgres
--

CREATE INDEX idx_tbl_libro_mayor_ip_periodo_contable ON contabilidad.tbl_libro_mayor USING btree (id_periodo_contable);


--
-- Name: idx_cod_suc_fecha_tbl_venta_encabezado; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cod_suc_fecha_tbl_venta_encabezado ON public.tbl_venta_encabezado USING btree (cod_sucursal, fecha);


--
-- Name: idx_secuencia_det_tbl_venta_detalle_desc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secuencia_det_tbl_venta_detalle_desc ON public.tbl_venta_detalle_desc USING btree (secuencia_det);


--
-- Name: idx_secuencia_det_tbl_venta_detalle_promo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secuencia_det_tbl_venta_detalle_promo ON public.tbl_venta_detalle_promo USING btree (secuencia_det);


--
-- Name: idx_secuencia_enc_tbl_venta_detalle; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secuencia_enc_tbl_venta_detalle ON public.tbl_venta_detalle USING btree (secuencia_enc);


--
-- Name: idx_secuencia_enc_tbl_venta_detalle_pago; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secuencia_enc_tbl_venta_detalle_pago ON public.tbl_venta_detalle_pago USING btree (secuencia_enc);


--
-- Name: idx_objeto_objeto; Type: INDEX; Schema: seguridad; Owner: postgres
--

CREATE UNIQUE INDEX idx_objeto_objeto ON seguridad.tbl_ms_objetos USING btree (objeto);


--
-- Name: idx_tbl_ms_parametros_parametro; Type: INDEX; Schema: seguridad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_ms_parametros_parametro ON seguridad.tbl_ms_parametros USING btree (parametro);


--
-- Name: idx_tbl_ms_preguntas_pregunta; Type: INDEX; Schema: seguridad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_ms_preguntas_pregunta ON seguridad.tbl_ms_preguntas USING btree (pregunta);


--
-- Name: idx_tbl_ms_roles_rol; Type: INDEX; Schema: seguridad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_ms_roles_rol ON seguridad.tbl_ms_roles USING btree (rol);


--
-- Name: idx_tbl_ms_usuario_usuario; Type: INDEX; Schema: seguridad; Owner: postgres
--

CREATE UNIQUE INDEX idx_tbl_ms_usuario_usuario ON seguridad.tbl_ms_usuario USING btree (usuario);


--
-- Name: tbl_libro_diario_detalle tgr_saldo_subcuenta_update; Type: TRIGGER; Schema: contabilidad; Owner: postgres
--

CREATE TRIGGER tgr_saldo_subcuenta_update BEFORE INSERT OR UPDATE ON contabilidad.tbl_libro_diario_detalle FOR EACH ROW EXECUTE FUNCTION contabilidad.fcn_saldo_subcuenta_update();


--
-- Name: tbl_compras_det tgr_actualiza_en_mano_compras; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_actualiza_en_mano_compras AFTER INSERT OR UPDATE ON public.tbl_compras_det FOR EACH ROW EXECUTE FUNCTION public.fcn_tgr_actualiza_en_mano_compras();


--
-- Name: tbl_venta_detalle tgr_actualiza_en_mano_ventas; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_actualiza_en_mano_ventas AFTER INSERT OR UPDATE ON public.tbl_venta_detalle FOR EACH ROW EXECUTE FUNCTION public.fcn_tgr_actualiza_en_mano_ventas();


--
-- Name: tbl_articulo tgr_articulo_bodega_new_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_articulo_bodega_new_insert AFTER INSERT OR UPDATE ON public.tbl_articulo FOR EACH ROW EXECUTE FUNCTION public.fcn_tgr_articulo_bodega_new_insert();


--
-- Name: tbl_ms_hist_constrasena tgr_update_contrasena; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_update_contrasena BEFORE UPDATE ON public.tbl_ms_hist_constrasena FOR EACH ROW EXECUTE FUNCTION seguridad.fcn_update_password();


--
-- Name: tbl_ms_usuario tgr_update_contrasena; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_update_contrasena BEFORE INSERT OR UPDATE ON public.tbl_ms_usuario FOR EACH ROW EXECUTE FUNCTION public.fcn_update_password();


--
-- Name: tbl_ms_hist_constrasena tgr_update_password; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tgr_update_password BEFORE UPDATE ON public.tbl_ms_hist_constrasena FOR EACH ROW EXECUTE FUNCTION public.fcn_update_password();


--
-- Name: tbl_ms_objetos tgr_objeto_new_insert; Type: TRIGGER; Schema: seguridad; Owner: postgres
--

CREATE TRIGGER tgr_objeto_new_insert AFTER INSERT ON seguridad.tbl_ms_objetos FOR EACH ROW EXECUTE FUNCTION seguridad.fcn_tgr_objeto_new_insert();


--
-- Name: tbl_ms_roles tgr_rol_new_insert; Type: TRIGGER; Schema: seguridad; Owner: postgres
--

CREATE TRIGGER tgr_rol_new_insert AFTER INSERT ON seguridad.tbl_ms_roles FOR EACH ROW EXECUTE FUNCTION seguridad.fcn_tgr_rol_new_insert();


--
-- Name: tbl_ms_usuario tgr_update_contrasena; Type: TRIGGER; Schema: seguridad; Owner: postgres
--

CREATE TRIGGER tgr_update_contrasena BEFORE INSERT OR UPDATE ON seguridad.tbl_ms_usuario FOR EACH ROW EXECUTE FUNCTION seguridad.fcn_update_password();


--
-- Name: tbl_ms_hist_contrasena tgr_update_password; Type: TRIGGER; Schema: seguridad; Owner: postgres
--

CREATE TRIGGER tgr_update_password BEFORE UPDATE ON seguridad.tbl_ms_hist_contrasena FOR EACH ROW EXECUTE FUNCTION seguridad.fcn_update_password();


--
-- Name: tbl_catalogo_cuenta tbl_catalogo_cuenta_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_catalogo_cuenta
    ADD CONSTRAINT tbl_catalogo_cuenta_fk FOREIGN KEY (id_categoria) REFERENCES contabilidad.tbl_categoria(id_categoria) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_catalogo_cuenta tbl_catalogo_cuenta_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_catalogo_cuenta
    ADD CONSTRAINT tbl_catalogo_cuenta_fk1 FOREIGN KEY (id_destino_cuenta) REFERENCES contabilidad.tbl_destino_cuenta(id_destino_cuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_destino_cuenta tbl_destino_cuenta_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_destino_cuenta
    ADD CONSTRAINT tbl_destino_cuenta_fk FOREIGN KEY (id_informe_financiero) REFERENCES contabilidad.tbl_informe_financiero(id_informe_financiero) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbl_destino_cuenta tbl_destino_cuenta_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_destino_cuenta
    ADD CONSTRAINT tbl_destino_cuenta_fk1 FOREIGN KEY (id_cuenta) REFERENCES contabilidad.tbl_catalogo_cuenta(id_cuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_diario_detalle tbl_libro_diario_detalle_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_detalle
    ADD CONSTRAINT tbl_libro_diario_detalle_fk FOREIGN KEY (id_libro_diario_enca) REFERENCES contabilidad.tbl_libro_diario_encabezado(id_libro_diario_enca) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_diario_detalle tbl_libro_diario_detalle_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_detalle
    ADD CONSTRAINT tbl_libro_diario_detalle_fk1 FOREIGN KEY (id_centro_costo) REFERENCES public.tbl_centro_costo(id_centro_costo) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_diario_detalle tbl_libro_diario_detalle_fk2; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_detalle
    ADD CONSTRAINT tbl_libro_diario_detalle_fk2 FOREIGN KEY (id_sucursal) REFERENCES public.tbl_sucursal(id_sucursal);


--
-- Name: tbl_libro_diario_encabezado tbl_libro_diario_encabezado_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_encabezado
    ADD CONSTRAINT tbl_libro_diario_encabezado_fk FOREIGN KEY (id_estado) REFERENCES contabilidad.tbl_estado(id_estado) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_diario_encabezado tbl_libro_diario_encabezado_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_encabezado
    ADD CONSTRAINT tbl_libro_diario_encabezado_fk1 FOREIGN KEY (id_periodo_contable) REFERENCES contabilidad.tbl_periodo_contable(id_periodo_contable) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_diario_detalle tbl_libro_diario_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_diario_detalle
    ADD CONSTRAINT tbl_libro_diario_fk1 FOREIGN KEY (id_subcuenta) REFERENCES contabilidad.tbl_subcuenta(id_subcuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_mayor tbl_libro_mayor_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_mayor
    ADD CONSTRAINT tbl_libro_mayor_fk FOREIGN KEY (id_cuenta) REFERENCES contabilidad.tbl_catalogo_cuenta(id_cuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_mayor tbl_libro_mayor_fk1; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_mayor
    ADD CONSTRAINT tbl_libro_mayor_fk1 FOREIGN KEY (id_periodo_contable) REFERENCES contabilidad.tbl_periodo_contable(id_periodo_contable) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_libro_mayor tbl_libro_mayor_fk2; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_libro_mayor
    ADD CONSTRAINT tbl_libro_mayor_fk2 FOREIGN KEY (id_subcuenta) REFERENCES contabilidad.tbl_subcuenta(id_subcuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_subcuenta tbl_subcuenta_fk; Type: FK CONSTRAINT; Schema: contabilidad; Owner: postgres
--

ALTER TABLE ONLY contabilidad.tbl_subcuenta
    ADD CONSTRAINT tbl_subcuenta_fk FOREIGN KEY (id_cuenta) REFERENCES contabilidad.tbl_catalogo_cuenta(id_cuenta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_articulo_bodega tbl_articulo_bodega_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo_bodega
    ADD CONSTRAINT tbl_articulo_bodega_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_articulo_bodega tbl_articulo_bodega_id_centro_costo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo_bodega
    ADD CONSTRAINT tbl_articulo_bodega_id_centro_costo_fkey FOREIGN KEY (id_centro_costo) REFERENCES public.tbl_centro_costo(id_centro_costo);


--
-- Name: tbl_articulo tbl_articulo_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo
    ADD CONSTRAINT tbl_articulo_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.tbl_categoria(id_categoria);


--
-- Name: tbl_articulo tbl_articulo_id_impuesto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo
    ADD CONSTRAINT tbl_articulo_id_impuesto_fkey FOREIGN KEY (id_impuesto) REFERENCES public.tbl_impuesto(id_impuesto);


--
-- Name: tbl_articulo tbl_articulo_id_unidad_medida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_articulo
    ADD CONSTRAINT tbl_articulo_id_unidad_medida_fkey FOREIGN KEY (id_unidad_medida) REFERENCES public.tbl_unidades_medida(id_unidad_medida);


--
-- Name: tbl_compras_det tbl_compras_det_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_det
    ADD CONSTRAINT tbl_compras_det_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_compras_det tbl_compras_det_id_impuesto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_det
    ADD CONSTRAINT tbl_compras_det_id_impuesto_fkey FOREIGN KEY (id_impuesto) REFERENCES public.tbl_impuesto(id_impuesto);


--
-- Name: tbl_compras_det tbl_compras_det_id_unidad_medida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_det
    ADD CONSTRAINT tbl_compras_det_id_unidad_medida_fkey FOREIGN KEY (id_unidad_medida) REFERENCES public.tbl_unidades_medida(id_unidad_medida);


--
-- Name: tbl_compras_det tbl_compras_det_secuencia_enc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_det
    ADD CONSTRAINT tbl_compras_det_secuencia_enc_fkey FOREIGN KEY (secuencia_enc) REFERENCES public.tbl_compras_enc(secuencia_enc);


--
-- Name: tbl_compras_enc tbl_compras_enc_id_centro_costo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_enc
    ADD CONSTRAINT tbl_compras_enc_id_centro_costo_fkey FOREIGN KEY (id_centro_costo) REFERENCES public.tbl_centro_costo(id_centro_costo) NOT VALID;


--
-- Name: tbl_compras_enc tbl_compras_enc_id_socio_negocio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_enc
    ADD CONSTRAINT tbl_compras_enc_id_socio_negocio_fkey FOREIGN KEY (id_socio_negocio) REFERENCES public.tbl_socio_negocio(id_socio_negocio);


--
-- Name: tbl_compras_enc tbl_compras_enc_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_compras_enc
    ADD CONSTRAINT tbl_compras_enc_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) NOT VALID;


--
-- Name: tbl_lista_materiales tbl_lista_materiales_id_articulo_hijo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_lista_materiales
    ADD CONSTRAINT tbl_lista_materiales_id_articulo_hijo_fkey FOREIGN KEY (id_articulo_hijo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_lista_materiales tbl_lista_materiales_id_articulo_padre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_lista_materiales
    ADD CONSTRAINT tbl_lista_materiales_id_articulo_padre_fkey FOREIGN KEY (id_articulo_padre) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_mesas tbl_mesas_id_mapa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_mesas
    ADD CONSTRAINT tbl_mesas_id_mapa_fkey FOREIGN KEY (id_mapa) REFERENCES public.tbl_mapa(id_mapa);


--
-- Name: tbl_movimiento_det tbl_movimiento_det_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_det
    ADD CONSTRAINT tbl_movimiento_det_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_movimiento_det tbl_movimiento_det_id_impuesto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_det
    ADD CONSTRAINT tbl_movimiento_det_id_impuesto_fkey FOREIGN KEY (id_impuesto) REFERENCES public.tbl_impuesto(id_impuesto);


--
-- Name: tbl_movimiento_det tbl_movimiento_det_id_unidad_medida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_det
    ADD CONSTRAINT tbl_movimiento_det_id_unidad_medida_fkey FOREIGN KEY (id_unidad_medida) REFERENCES public.tbl_unidades_medida(id_unidad_medida);


--
-- Name: tbl_movimiento_det tbl_movimiento_det_secuencia_enc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_det
    ADD CONSTRAINT tbl_movimiento_det_secuencia_enc_fkey FOREIGN KEY (secuencia_enc) REFERENCES public.tbl_movimiento_enc(secuencia_enc);


--
-- Name: tbl_movimiento_enc tbl_movimiento_enc_id_centro_costo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_enc
    ADD CONSTRAINT tbl_movimiento_enc_id_centro_costo_fkey FOREIGN KEY (id_centro_costo) REFERENCES public.tbl_centro_costo(id_centro_costo) NOT VALID;


--
-- Name: tbl_movimiento_enc tbl_movimiento_enc_id_socio_negocio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_enc
    ADD CONSTRAINT tbl_movimiento_enc_id_socio_negocio_fkey FOREIGN KEY (id_socio_negocio) REFERENCES public.tbl_socio_negocio(id_socio_negocio);


--
-- Name: tbl_movimiento_enc tbl_movimiento_enc_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_movimiento_enc
    ADD CONSTRAINT tbl_movimiento_enc_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) NOT VALID;


--
-- Name: tbl_ms_hist_constrasena tbl_ms_hist_constrasena_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_hist_constrasena
    ADD CONSTRAINT tbl_ms_hist_constrasena_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.tbl_ms_usuario(id_usuario);


--
-- Name: tbl_ms_usuario tbl_ms_usuario_id_rol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_ms_usuario
    ADD CONSTRAINT tbl_ms_usuario_id_rol_fkey FOREIGN KEY (id_rol) REFERENCES public.tbl_ms_roles(id_rol);


--
-- Name: tbl_correlativo tbl_pos_id_correlativo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_correlativo
    ADD CONSTRAINT tbl_pos_id_correlativo_fkey FOREIGN KEY (id_pos) REFERENCES public.tbl_pos(id_pos);


--
-- Name: tbl_pos tbl_pos_id_sucursal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_pos
    ADD CONSTRAINT tbl_pos_id_sucursal_fkey FOREIGN KEY (id_sucursal) REFERENCES public.tbl_sucursal(id_sucursal);


--
-- Name: tbl_promo tbl_promo_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_promo
    ADD CONSTRAINT tbl_promo_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.tbl_categoria(id_categoria);


--
-- Name: tbl_promo_lista tbl_promo_lista_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_promo_lista
    ADD CONSTRAINT tbl_promo_lista_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_promo_lista tbl_promo_lista_id_promo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_promo_lista
    ADD CONSTRAINT tbl_promo_lista_id_promo_fkey FOREIGN KEY (id_promo) REFERENCES public.tbl_promo(id_promo);


--
-- Name: tbl_sucursal tbl_sucursal_id_centro_costo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_sucursal
    ADD CONSTRAINT tbl_sucursal_id_centro_costo_fkey FOREIGN KEY (id_centro_costo) REFERENCES public.tbl_centro_costo(id_centro_costo);


--
-- Name: tbl_sucursal tbl_sucursal_id_mapa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_sucursal
    ADD CONSTRAINT tbl_sucursal_id_mapa_fkey FOREIGN KEY (id_mapa) REFERENCES public.tbl_mapa(id_mapa);


--
-- Name: tbl_venta_detalle_desc tbl_venta_detalle_desc_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_desc
    ADD CONSTRAINT tbl_venta_detalle_desc_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_venta_detalle_desc tbl_venta_detalle_desc_secuencia_det_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_desc
    ADD CONSTRAINT tbl_venta_detalle_desc_secuencia_det_fkey FOREIGN KEY (secuencia_det) REFERENCES public.tbl_venta_detalle(secuencia_det);


--
-- Name: tbl_venta_detalle tbl_venta_detalle_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle
    ADD CONSTRAINT tbl_venta_detalle_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_venta_detalle tbl_venta_detalle_id_impuesto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle
    ADD CONSTRAINT tbl_venta_detalle_id_impuesto_fkey FOREIGN KEY (id_impuesto) REFERENCES public.tbl_impuesto(id_impuesto);


--
-- Name: tbl_venta_detalle tbl_venta_detalle_id_modo_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle
    ADD CONSTRAINT tbl_venta_detalle_id_modo_pedido_fkey FOREIGN KEY (id_modo_pedido) REFERENCES public.tbl_modo_pedido(id_modo_pedido);


--
-- Name: tbl_venta_detalle_pago tbl_venta_detalle_pago_id_metodo_pago_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_pago
    ADD CONSTRAINT tbl_venta_detalle_pago_id_metodo_pago_fkey FOREIGN KEY (id_metodo_pago) REFERENCES public.tbl_metodo_pago(id_metodo_pago);


--
-- Name: tbl_venta_detalle_pago tbl_venta_detalle_pago_secuencia_enc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_pago
    ADD CONSTRAINT tbl_venta_detalle_pago_secuencia_enc_fkey FOREIGN KEY (secuencia_enc) REFERENCES public.tbl_venta_encabezado(secuencia_enc);


--
-- Name: tbl_venta_detalle_promo tbl_venta_detalle_promo_id_articulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_promo
    ADD CONSTRAINT tbl_venta_detalle_promo_id_articulo_fkey FOREIGN KEY (id_articulo) REFERENCES public.tbl_articulo(id_articulo);


--
-- Name: tbl_venta_detalle_promo tbl_venta_detalle_promo_secuencia_det_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle_promo
    ADD CONSTRAINT tbl_venta_detalle_promo_secuencia_det_fkey FOREIGN KEY (secuencia_det) REFERENCES public.tbl_venta_detalle(secuencia_det);


--
-- Name: tbl_venta_detalle tbl_venta_detalle_secuencia_enc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_detalle
    ADD CONSTRAINT tbl_venta_detalle_secuencia_enc_fkey FOREIGN KEY (secuencia_enc) REFERENCES public.tbl_venta_encabezado(secuencia_enc);


--
-- Name: tbl_venta_encabezado tbl_venta_encabezado_id_pos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_encabezado
    ADD CONSTRAINT tbl_venta_encabezado_id_pos_fkey FOREIGN KEY (id_pos) REFERENCES public.tbl_pos(id_pos) NOT VALID;


--
-- Name: tbl_venta_encabezado tbl_venta_encabezado_id_sucursal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_encabezado
    ADD CONSTRAINT tbl_venta_encabezado_id_sucursal_fkey FOREIGN KEY (id_sucursal) REFERENCES public.tbl_sucursal(id_sucursal);


--
-- Name: tbl_venta_encabezado tbl_venta_encabezado_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_venta_encabezado
    ADD CONSTRAINT tbl_venta_encabezado_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) NOT VALID;


--
-- Name: tbl_ms_bitacora tbl_ms_bitacora_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_bitacora
    ADD CONSTRAINT tbl_ms_bitacora_fk FOREIGN KEY (id_objeto) REFERENCES seguridad.tbl_ms_objetos(id_objeto) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_hist_contrasena tbl_ms_hist_contrasena_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_hist_contrasena
    ADD CONSTRAINT tbl_ms_hist_contrasena_fk FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_permisos tbl_ms_permisos_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_permisos
    ADD CONSTRAINT tbl_ms_permisos_fk FOREIGN KEY (id_rol) REFERENCES seguridad.tbl_ms_roles(id_rol) ON UPDATE CASCADE ON DELETE RESTRICT NOT VALID;


--
-- Name: tbl_ms_permisos tbl_ms_permisos_fk1; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_permisos
    ADD CONSTRAINT tbl_ms_permisos_fk1 FOREIGN KEY (id_objeto) REFERENCES seguridad.tbl_ms_objetos(id_objeto) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_preguntas_usuario tbl_ms_preguntas_usuario_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas_usuario
    ADD CONSTRAINT tbl_ms_preguntas_usuario_fk FOREIGN KEY (id_pregunta) REFERENCES seguridad.tbl_ms_preguntas(id_pregunta) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_preguntas_usuario tbl_ms_preguntas_usuario_fk1; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_preguntas_usuario
    ADD CONSTRAINT tbl_ms_preguntas_usuario_fk1 FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_usuario tbl_ms_usuario_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario
    ADD CONSTRAINT tbl_ms_usuario_fk FOREIGN KEY (estado_usuario) REFERENCES seguridad.tbl_ms_usuario_estado(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tbl_ms_bitacora tbl_ms_usuario_fk; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_bitacora
    ADD CONSTRAINT tbl_ms_usuario_fk FOREIGN KEY (id_usuario) REFERENCES seguridad.tbl_ms_usuario(id_usuario) NOT VALID;


--
-- Name: tbl_ms_usuario tbl_ms_usuario_fk1; Type: FK CONSTRAINT; Schema: seguridad; Owner: postgres
--

ALTER TABLE ONLY seguridad.tbl_ms_usuario
    ADD CONSTRAINT tbl_ms_usuario_fk1 FOREIGN KEY (id_rol) REFERENCES seguridad.tbl_ms_roles(id_rol) NOT VALID;


--
-- Name: SCHEMA seguridad; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA seguridad TO PUBLIC;


--
-- PostgreSQL database dump complete
--

